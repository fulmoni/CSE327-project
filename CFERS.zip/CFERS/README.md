# Campus Facility and Equipment Reservation System (CFERS)

### CSE327 Software Engineering | North South University
* **Course:** CSE327 Software Engineering
* **Department:** Department of Electrical & Computer Engineering (ECE)
* **Institution:** North South University (NSU)
* **Semester:** Fall 2026
* **Architecture:** Enterprise Web Application with 6 Gang of Four (GoF) Design Patterns

---

## Project Group Metadata

* **Group Name:** Group [Number]
* **Project Title:** Campus Facility and Equipment Reservation System (CFERS)

| Serial | Project Member Name | Student ID | Department | Institutional Email |
| :---: | :--- | :---: | :---: | :--- |
| 1 | [Member 1 Full Name] | 2XXXXXXX | ECE | member1@northsouth.edu |
| 2 | [Member 2 Full Name] | 2XXXXXXX | ECE | member2@northsouth.edu |
| 3 | [Member 3 Full Name] | 2XXXXXXX | ECE | member3@northsouth.edu |
| 4 | [Member 4 Full Name] | 2XXXXXXX | ECE | member4@northsouth.edu |

---

## 1. Quick Start Instructions

This project runs directly in any modern web browser with **zero external dependencies**:
* **Launch:** Double-click [`Launch_CFERS.bat`](file:///C:/Users/User/Desktop/Software%20Project/CFERS/Launch_CFERS.bat) or open [`index.html`](file:///C:/Users/User/Desktop/Software%20Project/CFERS/index.html) in Google Chrome or Microsoft Edge.
* **No Build Step Required:** Vanilla ECMAScript modules with native HTML5, CSS3, and browser `localStorage`. No Node.js, npm, webpack, or backend servers required.
* **Database State:** State is persisted automatically across browser reloads via `DatabaseManager` in `localStorage`.
* **State Reset:** Click **"Reset Database"** in the top navigation bar to restore clean default campus facilities, accounts, and assignments.

---

## 2. Institutional Authentication & Role Matrix

CFERS enforces strict perimeter security: unauthenticated visitors are contained at the institutional login gateway and cannot inspect internal campus resources until authenticated.

| Role | Default User | Institutional Email | Password | Scope & System Permissions |
| :--- | :--- | :--- | :--- | :--- |
| **Student** | Student 1 | `student1@northsouth.edu` | `password123` | Single workstation seat booking in labs, hardware kits, decorator add-ons, personal vouchers, quota limit of 3 concurrent active/pending bookings. Cannot book seminar halls or whole labs. |
| **Faculty** | Faculty 1 | `faculty1@northsouth.edu` | `password123` | Whole lab room reservations, multi-seat workstation stacks, seminar halls, priority queue placement, makeup session booking, department schedule view. |
| **Officer** | Officer 1 | `officer1@northsouth.edu` | `password123` | Exclusive facility jurisdiction (e.g. Officer 1 manages Computer Lab 1). Facility-specific Approval Desk, maintenance toggles, department master schedule. |
| **Admin** | Admin 1 | `admin@northsouth.edu` | `password123` | Central administrator authority. 1-to-1 Officer jurisdiction mapping, user registration approval gate, facility registration/decommissioning, cryptographic audit log inspection, JSON database engine. |

*(Additional seed credentials: Student 2 `student2@northsouth.edu`, Faculty 2 `faculty2@northsouth.edu`, Officer 2 `officer2@northsouth.edu`, Officer 3 `officer3@northsouth.edu`).*

---

## 3. The 6 Gang of Four (GoF) Design Patterns

CFERS faithfully implements **six (6) classic Design Patterns** directly from the CSE327 syllabus:

| # | Design Pattern | Classification | Source File | Real-World Implementation in CFERS |
| :---: | :--- | :--- | :--- | :--- |
| 1 | **Singleton** | Creational | [src/patterns/singleton.js](file:///C:/Users/User/Desktop/Software%20Project/CFERS/src/patterns/singleton.js) | `DatabaseManager`: Single global coordination point guaranteeing atomic reads/writes, transactional JSON persistence, schema migrations, and audit trails in browser `localStorage`. |
| 2 | **Factory Method** | Creational | [src/patterns/factory.js](file:///C:/Users/User/Desktop/Software%20Project/CFERS/src/patterns/factory.js) | `AssetFactory`: Polymorphic facility instantiation (`LabRoom`, `SeminarHall`, `HardwareKit`) registered dynamically with extensible type mappings when Administrators register new campus assets. |
| 3 | **Strategy** | Behavioral | [src/patterns/strategy.js](file:///C:/Users/User/Desktop/Software%20Project/CFERS/src/patterns/strategy.js) | `AllocationStrategy`: Pluggable arbitration algorithms (`FCFSStrategy` vs. `FacultyPriorityStrategy`) sorting and scheduling the Approval Desk queue in real time. |
| 4 | **Observer** | Behavioral | [src/patterns/observer.js](file:///C:/Users/User/Desktop/Software%20Project/CFERS/src/patterns/observer.js) | `BookingSubject`: Decouples booking lifecycle events from UI side-effects, broadcasting notifications to `ToastNotificationObserver` and `AuditLogObserver`. |
| 5 | **Decorator** | Structural | [src/patterns/decorator.js](file:///C:/Users/User/Desktop/Software%20Project/CFERS/src/patterns/decorator.js) | `ReservationDecorator`: Dynamically chains optional hardware and service add-ons (`ProjectorDecorator` +$45, `UPSBackupDecorator` +$25, `LabAssistantDecorator` +$60, `GigabitNetworkDecorator` +$35) onto `BaseReservation`. |
| 6 | **Proxy** | Structural | [src/patterns/proxy.js](file:///C:/Users/User/Desktop/Software%20Project/CFERS/src/patterns/proxy.js) | `SecureBookingProxy`: Protection proxy intercepting facility operations to enforce Role-Based Access Control (RBAC), multi-seat collision detection, student scope boundaries, jurisdiction mapping, and audit logging. |

---

## 4. Core Features & System Capabilities

### A. Institutional Registration Approval Gate
* **No Direct Login After Signup:** When new students or faculty register via self-service signup, accounts receive `status: "PENDING_APPROVAL"`. Direct authentication is blocked with `[ERR_ACCOUNT_PENDING]`.
* **Admin Review Desk:** The Admin Console displays a real-time pending approvals alert banner, dynamic applicant cards, and filter badges in the User Directory.
* **One-Click Activation:** Administrators review applicant credentials (Name, Email, Role, Department, NSU ID) and click `Approve Account` or `Reject`.
* **Zero Session Leak:** Password hashes are evaluated before status verification to prevent account enumeration timing leaks.

### B. Interactive Lab Workstation Seat Grid
* **Live Visual Floorplan:** 35 interactive workstation pods (`WS-01` to `WS-35`) dynamically rendered for Computer Labs.
* **Real-Time State Legend:** Color-coded status swatches for Available, Selected, and Occupied pods.
* **Stackable Multi-Seat Selection (Faculty & Admin):**
  * Click individual pods to stack multiple seats (`WS-01, WS-02, WS-03`).
  * Bulk actions: `Select All Seats (Whole Lab)` or `Select All Available (N)`.
  * Targeted unselect: Clicking an individual seat from a bulk selection deselects only that seat without clearing the remaining group.
  * Status badge updates dynamically (`Whole Lab`, `Selected: N Workstations`, `Assigned: WS-01`).
* **Student Single-Seat Isolation:** Students are strictly restricted to 1 workstation seat (radio selection). Bulk selection and whole-room reservations remain locked.

### C. Responsive Landscape Modal Architecture
* **2-Column Ergonomic Form:** Transformed from a tall single-column form (1218px) into an executive landscape layout (579px height, max-width 1060px) fitting standard laptop and desktop screens without vertical overflow.
* **Left Column:** Side-by-side date and time window pickers, academic purpose input, 2x2 touch-friendly amenity cards, itemized cost breakdown, and anchored action buttons.
* **Right Column:** Houses the 35-seat workstation pod map for Computer Labs, or an Institutional Facility Briefing card (specifications, location, assigned officer, departmental policies) for Seminar Rooms and Hardware Kits.
* **Mobile Fluid Collapse:** Gracefully stacks into a single fluid column on screens under 860px with internal smooth scrolling (`overflow-y: auto`, `overflow-x: hidden`).

### D. 1-to-1 Injective Officer Jurisdiction Policy
* **Exclusive Management:** Each campus facility is assigned to at most one Officer, and each Officer manages exactly one facility.
* **Unassigned Facility Guard:** Facilities without an assigned Officer are locked from reservations until an Administrator assigns jurisdiction.
* **Offline Maintenance Controls:** Assigned Officers can pause facility bookings for repairs and diagnostics, automatically blocking new reservations with `[ERR_FACILITY_OFFLINE]`.

### E. Department Master Schedule & Conflict Arbitration
* Real-time grid displaying bookings across all facilities and time windows (08:00 AM to 06:00 PM).
* Comma-separated multi-seat collision detection preventing overlapping seat bookings in the same time window.
* Toggleable arbitration between First-Come-First-Served (FCFS) and Faculty Priority.

### F. Official Digital Reservation Receipts
* Full institutional reservation receipts with unique QR verification markers, cryptographic hashes, itemized add-on breakdowns, reviewing officer approvals, and print-ready stylesheets.

### G. Raw Relational JSON Database Engine & Audit Logs
* View, export, and import raw JSON tables (`assets.json`, `users.json`, `reservations.json`, `assignments.json`, `audit_logs.json`) directly in the browser (RFC 8259 compliant).
* Complete audit logging of logins, booking status changes, user registrations, and security violations.

---

## 5. Directory Structure

```
CFERS/
├── index.html                   # Main application interface & responsive layout
├── Launch_CFERS.bat             # 1-click Windows desktop launcher
├── README.md                    # System documentation & architectural reference
├── data/                        # Initial relational seed datasets (JSON)
│   ├── assets.json              # Campus labs, seminar halls, hardware kits
│   ├── users.json               # Seed student, faculty, officer, and admin accounts
│   ├── reservations.json        # Seed campus bookings & active sessions
│   ├── assignments.json         # 1-to-1 Officer jurisdiction mappings
│   └── audit_logs.json          # System event logs & security trails
├── styles/
│   └── main.css                 # NSU design system, landscape modal & floorplan styles
└── src/
    ├── app.js                   # Application coordinator, DOM handlers & UI workflows
    └── patterns/                # The 6 Gang of Four (GoF) Design Pattern Implementations
        ├── singleton.js         # DatabaseManager (Singleton Pattern)
        ├── factory.js           # AssetFactory (Factory Method Pattern)
        ├── strategy.js          # AllocationStrategy: FCFS vs. Faculty Priority (Strategy Pattern)
        ├── observer.js          # BookingSubject & Observers (Observer Pattern)
        ├── decorator.js         # ReservationDecorator & Add-on Wrappers (Decorator Pattern)
        └── proxy.js             # SecureBookingProxy & Protection Proxy (Proxy Pattern)
```

---

## 6. Compliance & Standards

* **Course Syllabus:** Fully satisfies all requirements for CSE327 Software Engineering at North South University.
* **Code Standards:** Clean separation of concerns, zero external libraries, modular ECMAScript architecture, WCAG accessible contrast ratios, and human-crafted responsive layouts.
