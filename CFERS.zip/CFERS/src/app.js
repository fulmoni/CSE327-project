/**
 * CFERS Application Coordinator (app.js)
 * Strict Role-Based Access Control (RBAC), JSON Relational Database Engine,
 * and 6 Gang of Four Design Patterns Implementation.
 */

document.addEventListener("DOMContentLoaded", () => {
  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // DOM Elements (declared first)
  const sidebarUserWidget = document.getElementById("sidebar-user-widget");
  const userAvatarInitials = document.getElementById("user-avatar-initials");
  const userDisplayNameText = document.getElementById("user-display-name-text");
  const userDisplayRoleBadge = document.getElementById("user-display-role-badge");
  const userRolePermissionsDesc = document.getElementById("user-role-permissions-desc");
  const btnOpenAuthModal = document.getElementById("btn-open-auth-modal");
  const btnSignOut = document.getElementById("btn-sign-out");

  // Navigation Items
  const navTabCatalog = document.getElementById("nav-tab-catalog");
  const navTabMyBookings = document.getElementById("nav-tab-my-bookings");
  const navTabSchedule = document.getElementById("nav-tab-schedule");
  const navTabApprovals = document.getElementById("nav-tab-approvals");
  const navTabAudit = document.getElementById("nav-tab-audit");
  const navTabDatabase = document.getElementById("nav-tab-database");
  const navTabSuperAdmin = document.getElementById("nav-tab-super-admin");
  const linkSadminPortal = document.getElementById("link-sadmin-portal");
  const modalSadminLogin = document.getElementById("modal-sadmin-login");
  const btnCloseSadminModal = document.getElementById("btn-close-sadmin-modal");
  const formSadminSignin = document.getElementById("form-sadmin-signin");
  const btnDemoSadminLogin = document.getElementById("btn-demo-sadmin-login");
  const modalSadminUser = document.getElementById("modal-sadmin-user");
  const btnCloseSadminUserModal = document.getElementById("btn-close-sadmin-user-modal");
  const formSadminUser = document.getElementById("form-sadmin-user");
  const btnCancelSadminUser = document.getElementById("btn-cancel-sadmin-user");
  const navItems = document.querySelectorAll(".nav-item");
  const tabPanes = document.querySelectorAll(".tab-pane");

  const viewTitle = document.getElementById("view-title");
  const viewSubtitle = document.getElementById("view-subtitle");
  const statAuthRole = document.getElementById("stat-auth-role");
  const statAuthDesc = document.getElementById("stat-auth-desc");

  // Catalog Elements
  const catalogGrid = document.getElementById("catalog-grid");
  const catalogSearch = document.getElementById("catalog-search");
  const categoryPills = document.querySelectorAll(".category-pill");
  const btnOpenAddAssetModal = document.getElementById("btn-open-add-asset-modal");

  // Tables
  const myBookingsTbody = document.getElementById("my-bookings-tbody");
  const myBookingsHeaderTitle = document.getElementById("my-bookings-header-title");
  const deptScheduleTbody = document.getElementById("dept-schedule-tbody");
  const approvalQueueTbody = document.getElementById("approval-queue-tbody");
  const auditTableTbody = document.getElementById("audit-table-tbody");
  const approvalStrategySelector = document.getElementById("approval-strategy-selector"); // Deprecated in favor of .btn-strategy-option

  // JSON Database Engine Elements
  const btnDownloadTableJson = document.querySelectorAll(".btn-download-table-json");
  const btnImportTableJson = document.querySelectorAll(".btn-import-table-json");
  const btnViewTableJson = document.querySelectorAll(".btn-view-table-json");
  const jsonViewerTitle = document.getElementById("json-viewer-title");
  const jsonViewerOutput = document.getElementById("json-viewer-output");

  // Booking Modal
  const facilityModal = document.getElementById("facility-modal");
  const btnModalClose = document.getElementById("btn-modal-close");
  const btnCancelModal = document.getElementById("btn-cancel-modal");
  const reservationDialogForm = document.getElementById("reservation-dialog-form");
  const modalHeadingName = document.getElementById("modal-heading-name");
  const modalSubheadingLoc = document.getElementById("modal-subheading-loc");
  const modalComputedCost = document.getElementById("modal-computed-cost");
  const modalDecorDesc = document.getElementById("modal-decor-desc");
  const chkAmenities = document.querySelectorAll(".chk-amenity");

  // Auth Modal
  const authModal = document.getElementById("auth-modal");
  const btnCloseAuthModal = document.getElementById("btn-close-auth-modal");
  const tabBtnSignin = document.getElementById("tab-btn-signin");
  const tabBtnSignup = document.getElementById("tab-btn-signup");
  const formSignin = document.getElementById("form-signin");
  const formSignup = document.getElementById("form-signup");
  const demoLoginBtns = document.querySelectorAll(".btn-demo-login");

  // Add Asset Modal
  const addAssetModal = document.getElementById("add-asset-modal");
  const btnCloseAddAssetModal = document.getElementById("btn-close-add-asset-modal");
  const btnCancelAddAsset = document.getElementById("btn-cancel-add-asset");
  const formAddAsset = document.getElementById("form-add-asset");

  // Receipt Modal
  const receiptModal = document.getElementById("receipt-modal");
  const btnCloseReceiptModal = document.getElementById("btn-close-receipt-modal");
  const btnPrintVoucher = document.getElementById("btn-print-voucher");

  // Telemetry Drawer Elements
  const architectureDrawer = document.getElementById("architecture-drawer");
  const btnToggleTelemetry = document.getElementById("toggle-telemetry-btn");
  const btnCloseDrawer = document.getElementById("btn-close-drawer");
  const btnClearTelemetry = document.getElementById("btn-clear-telemetry");
  const telemetryEventList = document.getElementById("telemetry-event-list");
  const btnResetDatabase = document.getElementById("btn-reset-database");

  // 1. Initialize Singleton DatabaseManager
  const db = window.DatabaseManager.getInstance();
  recordTelemetry("Singleton", "DatabaseManager connected. Initialized state with JSON relational schema.", "chip-singleton");

  // 2. Initialize Observer Subject and Register Observers
  const subject = new window.BookingSubject();
  const toastObserver = new window.ToastNotificationObserver();
  const auditObserver = new window.AuditLogObserver();

  subject.subscribe(toastObserver);
  subject.subscribe(auditObserver);
  recordTelemetry("Observer", "BookingSubject initialized with ToastNotificationObserver and AuditLogObserver.", "chip-observer");

  // 3. Initialize Proxy & Real Service
  const realService = new window.RealBookingService(subject);
  const bookingProxy = new window.SecureBookingProxy(realService);
  recordTelemetry("Proxy", "SecureBookingProxy initialized as gatekeeper for RealBookingService.", "chip-proxy");

  // 4. Initialize Strategy Context
  const scheduler = new window.SchedulerContext(new window.FCFSStrategy());
  recordTelemetry("Strategy", "SchedulerContext initialized with default First-Come, First-Served policy.", "chip-strategy");

  // Current User Session State (Strict Zero-Trust Authentication Guard)
  let currentUser = db.getCurrentUser();
  const urlRole = new URLSearchParams(window.location.search).get("role");
  if (urlRole && !currentUser) {
    if (urlRole === "STUDENT") currentUser = db.authenticateUser("student1@northsouth.edu", "password123");
    else if (urlRole === "FACULTY") currentUser = db.authenticateUser("faculty1@northsouth.edu", "password123");
    else if (urlRole === "OFFICER") currentUser = db.authenticateUser("officer1@northsouth.edu", "password123");
    else if (urlRole === "ADMIN") currentUser = db.authenticateUser("admin@northsouth.edu", "admin123");
  }

  let selectedAssetForBooking = null;
  let activeFilter = "ALL";

  // Table Search and Filter States
  let myBookingsSearchQuery = "";
  let myBookingsStatusFilter = "ALL";
  let scheduleSearchQuery = "";
  let scheduleTypeFilter = "ALL";
  let approvalsSearchQuery = "";
  let approvalsFilterMode = "PENDING";
  let auditSearchQuery = "";
  let auditEventFilter = "ALL";
  let sadminJurisdictionSearch = "";
  let sadminUsersSearch = "";
  let sadminUsersRoleFilter = "ALL";
  let sadminFacilitiesSearch = "";
  let sadminFacilitiesTypeFilter = "ALL";

  // Bootstrap Application Modules
  updateUserProfileDisplay();
  setupNavigation();
  setupCatalogControls();
  setupModalDialog();
  setupAuthModal();
  setupAuthGate();
  setupAddAssetModal();
  setupReceiptModal();
  setupDatabaseEngine();
  setupTelemetryDrawer();
  setupStrategyControls();
  setupSuperAdminConsole();
  setupTestShortcutsModal();
  setupTableSearchAndFilters();
  checkSadminRoute();
  refreshAllViews();

  // --------------------------------------------------------------------------
  // Strict Role-Based Access Control (RBAC) & Profile Display
  // --------------------------------------------------------------------------
  function updateUserProfileDisplay() {
    const appLayout = document.querySelector(".app-layout");
    const authGate = document.getElementById("auth-gate-screen");

    // Universal Navbar Defense: Admin Console is strictly hidden unless root admin
    if (navTabSuperAdmin) navTabSuperAdmin.style.display = "none";

    if (!currentUser) {
      // STRICT PERIMETER DEFENSE: Nobody can see inside the portal without authenticating!
      if (appLayout) appLayout.style.display = "none";
      if (authGate) authGate.style.display = "flex";
      return;
    }

    // Authenticated: reveal internal application workspace and hide gate
    if (appLayout) appLayout.style.display = "flex";
    if (authGate) authGate.style.display = "none";

    const role = currentUser.role;
    const names = (currentUser.name || "User").split(" ");
    const initials = names.length > 1 ? names[0][0] + names[names.length - 1][0] : names[0].slice(0, 2);

    userAvatarInitials.textContent = initials.toUpperCase();
    userDisplayNameText.textContent = currentUser.name;
    userDisplayRoleBadge.textContent = role === "OFFICER" ? "OFFICER" : (role === "ADMIN" && currentUser.id.startsWith("OFF-") ? "OFFICER" : (role === "SUPER_ADMIN" ? "ADMIN" : role));
    userDisplayRoleBadge.className = `user-role-badge-pill badge-${role.toLowerCase()}`;
    btnSignOut.style.display = "block";
    btnOpenAuthModal.textContent = "Switch Profile";

    // Strict Role-Based Dynamic UI Segmentation
    if (role === "STUDENT") {
      userRolePermissionsDesc.textContent = "Permissions: Hardware & Single Lab Workstations";
      statAuthRole.textContent = "Student Role";
      statAuthRole.style.color = "#1e40af";
      statAuthDesc.textContent = "Hardware kits and single-seat lab workstation reservations";
      myBookingsHeaderTitle.textContent = "My Reservation History & Vouchers";

      // Students CANNOT see Officer, Faculty tabs, or Admin Console
      navTabSchedule.style.display = "none";
      navTabApprovals.style.display = "none";
      navTabAudit.style.display = "none";
      navTabDatabase.style.display = "none";
      if (navTabSuperAdmin) navTabSuperAdmin.style.display = "none";
      btnOpenAddAssetModal.style.display = "none";

      ensureValidActiveTab(["catalog", "my-bookings"]);
    } else if (role === "FACULTY") {
      userRolePermissionsDesc.textContent = "Permissions: Priority Academic Scheduling & Whole Rooms";
      statAuthRole.textContent = "Faculty Priority";
      statAuthRole.style.color = "#92400e";
      statAuthDesc.textContent = "Academic makeup priority slots & departmental facilities";
      myBookingsHeaderTitle.textContent = "Faculty Course & Seminar Bookings";

      // Faculty can view the department schedule, but NOT officer approvals/audit/database or Admin Console
      navTabSchedule.style.display = "flex";
      navTabApprovals.style.display = "none";
      navTabAudit.style.display = "none";
      navTabDatabase.style.display = "none";
      if (navTabSuperAdmin) navTabSuperAdmin.style.display = "none";
      btnOpenAddAssetModal.style.display = "none";

      ensureValidActiveTab(["catalog", "my-bookings", "schedule"]);
    } else if (role === "OFFICER" || (role === "ADMIN" && currentUser.id && currentUser.id.startsWith("OFF-"))) {
      const assignedAsset = db.getAssignedAssetForAdmin(currentUser.id);
      const assignedName = assignedAsset ? assignedAsset.name : "Unassigned";
      userRolePermissionsDesc.textContent = `Assigned Facility: ${assignedName}`;
      statAuthRole.textContent = "Facility Officer";
      statAuthRole.style.color = "#6b21a8";
      statAuthDesc.textContent = assignedAsset ? `Exclusive Manager of ${assignedAsset.name}` : "Awaiting Admin Jurisdiction Mapping";
      myBookingsHeaderTitle.textContent = "My Personal Reservations & Vouchers";

      navTabSchedule.style.display = "flex";
      navTabApprovals.style.display = "flex";
      navTabAudit.style.display = "none";
      navTabDatabase.style.display = "none";
      if (navTabSuperAdmin) navTabSuperAdmin.style.display = "none";
      btnOpenAddAssetModal.style.display = "none";

      ensureValidActiveTab(["catalog", "my-bookings", "schedule", "approvals"]);
    } else if (role === "ADMIN" || role === "SUPER_ADMIN") {
      userRolePermissionsDesc.textContent = "Permissions: Global Administration & Officer Assignments";
      statAuthRole.textContent = "System Administrator";
      statAuthRole.style.color = "#4f46e5";
      statAuthDesc.textContent = "Root CRUD on Users, Resources & Officer Jurisdictions";
      myBookingsHeaderTitle.textContent = "My Administrative Bookings & Vouchers";

      navTabSchedule.style.display = "flex";
      navTabApprovals.style.display = "flex";
      navTabAudit.style.display = "flex";
      navTabDatabase.style.display = "flex";
      if (navTabSuperAdmin) {
        navTabSuperAdmin.style.display = "flex";
        const pendingList = db.getPendingUsers ? db.getPendingUsers() : [];
        const badge = navTabSuperAdmin.querySelector(".nav-badge");
        if (badge) {
          if (pendingList.length > 0) {
            badge.textContent = `${pendingList.length} PENDING`;
            badge.style.background = "#f59e0b";
            badge.style.color = "#ffffff";
          } else {
            badge.textContent = "ADMIN";
            badge.style.background = "";
            badge.style.color = "";
          }
        }
      }
      btnOpenAddAssetModal.style.display = "inline-flex";
    }
  }

  function ensureValidActiveTab(allowedTabs) {
    const activeItem = document.querySelector(".nav-item.active");
    if (!activeItem) return;
    const currentTabKey = activeItem.dataset.tab;

    if (!allowedTabs.includes(currentTabKey)) {
      // Auto-navigate to catalog
      switchTab("catalog");
    }
  }

  function getAllowedTabsForRole(role) {
    switch (role) {
      case "SUPER_ADMIN":
        return ["catalog", "my-bookings", "schedule", "approvals", "audit", "database-engine", "super-admin"];
      case "ADMIN":
        if (currentUser && currentUser.id && currentUser.id.startsWith("OFF-")) {
          return ["catalog", "my-bookings", "schedule", "approvals"];
        }
        return ["catalog", "my-bookings", "schedule", "approvals", "audit", "database-engine", "super-admin"];
      case "OFFICER":
        return ["catalog", "my-bookings", "schedule", "approvals"];
      case "FACULTY":
        return ["catalog", "my-bookings", "schedule"];
      case "STUDENT":
        return ["catalog", "my-bookings"];
      default:
        return ["catalog", "my-bookings"];
    }
  }

  function switchTab(tabKey) {
    const activeUser = db.getCurrentUser() || currentUser;
    const currentRole = activeUser ? activeUser.role : "GUEST";
    const allowed = getAllowedTabsForRole(currentRole);

    if (!allowed.includes(tabKey)) {
      const friendlyName = tabKey.replace("-", " ").toUpperCase();
      const userDesc = activeUser ? `${activeUser.name} (${activeUser.role})` : "Guest Visitor";
      
      db.logAudit(
        "SECURITY_VIOLATION",
        activeUser || "Guest Visitor",
        `Blocked attempt to navigate to restricted '${friendlyName}' portal.`
      );
      recordTelemetry(
        "Proxy",
        `BLOCKED: ${userDesc} attempted unauthorized access to '${tabKey}'. Enforcing RBAC restriction.`,
        "chip-proxy"
      );
      showToast(`Access Denied: Your account role does not have permission to view '${friendlyName}'.`);
      
      // Force return to catalog
      tabKey = "catalog";
    }

    document.querySelectorAll(".nav-item").forEach((i) => i.classList.remove("active"));
    document.querySelectorAll(".tab-pane").forEach((p) => p.classList.remove("active"));

    const btn = document.querySelector(`.nav-item[data-tab="${tabKey}"]`);
    if (btn) btn.classList.add("active");

    const targetPane = document.getElementById(`pane-${tabKey}`);
    if (targetPane) targetPane.classList.add("active");

    updateViewHeadlines(tabKey);
  }

  function updateViewHeadlines(tabKey) {
    if (tabKey === "catalog") {
      viewTitle.textContent = "Campus Facilities & Equipment";
      viewSubtitle.textContent = "Browse and schedule verified departmental labs, lecture spaces, and hardware kits.";
    } else if (tabKey === "my-bookings") {
      viewTitle.textContent = "My Bookings";
      viewSubtitle.textContent = "Review your personal scheduled sessions, inspect official institutional vouchers, or cancel pending requests.";
    } else if (tabKey === "schedule") {
      viewTitle.textContent = "Department Master Schedule";
      viewSubtitle.textContent = "Verified room allocations across North South University facilities to prevent collisions.";
    } else if (tabKey === "approvals") {
      viewTitle.textContent = "Department Approval Desk";
      viewSubtitle.textContent = "Review, prioritize, and process facility reservation requests.";
    } else if (tabKey === "audit") {
      viewTitle.textContent = "Audit & Security Log";
      viewSubtitle.textContent = "Verifiable transaction records and security violation audit trail.";
    } else if (tabKey === "database-engine") {
      viewTitle.textContent = "JSON Relational Database Engine";
      viewSubtitle.textContent = "Directly maintain, export, and inspect raw database tables as structured JSON files (RFC 8259).";
    } else if (tabKey === "super-admin") {
      viewTitle.textContent = "Admin Console";
      viewSubtitle.textContent = "Administrative management of facility-officer jurisdictions, institutional user directory, and campus inventory.";
    }
  }

  // --------------------------------------------------------------------------
  // Tab Navigation
  // --------------------------------------------------------------------------
  function setupNavigation() {
    document.querySelectorAll(".nav-item").forEach((btn) => {
      btn.addEventListener("click", () => {
        const tabKey = btn.dataset.tab;
        switchTab(tabKey);
      });
    });
  }

  // --------------------------------------------------------------------------
  // Authentication Modal (Sign In / Register / Demo)
  // --------------------------------------------------------------------------
  function setupAuthModal() {
    btnOpenAuthModal.addEventListener("click", () => {
      authModal.style.display = "flex";
    });

    btnCloseAuthModal.addEventListener("click", () => {
      authModal.style.display = "none";
    });

    authModal.addEventListener("click", (e) => {
      if (e.target === authModal) authModal.style.display = "none";
    });

    // Tab toggle: Sign In vs Sign Up
    tabBtnSignin.addEventListener("click", () => {
      tabBtnSignin.classList.add("active");
      tabBtnSignup.classList.remove("active");
      formSignin.style.display = "block";
      formSignup.style.display = "none";
    });

    tabBtnSignup.addEventListener("click", () => {
      tabBtnSignup.classList.add("active");
      tabBtnSignin.classList.remove("active");
      formSignup.style.display = "block";
      formSignin.style.display = "none";
    });

    // One-Click Demo Logins
    demoLoginBtns.forEach((btn) => {
      btn.addEventListener("click", () => {
        const email = btn.dataset.email;
        const pass = btn.dataset.pass;
        try {
          currentUser = db.authenticateUser(email, pass);
          updateUserProfileDisplay();
          authModal.style.display = "none";
          recordTelemetry("Proxy", `Switched active actor to ${currentUser.name} [Role: ${currentUser.role}].`, "chip-proxy");
          showToast(`Logged in as ${currentUser.name} (${currentUser.role})`);
          refreshAllViews();
        } catch (err) {
          alert(err.message);
        }
      });
    });

    // Sign In Form Submit
    formSignin.addEventListener("submit", (e) => {
      e.preventDefault();
      const email = document.getElementById("signin-email").value;
      const pass = document.getElementById("signin-password").value;

      try {
        currentUser = db.authenticateUser(email, pass);
        updateUserProfileDisplay();
        authModal.style.display = "none";
        formSignin.reset();
        recordTelemetry("Proxy", `User signed in: ${currentUser.name} [Role: ${currentUser.role}].`, "chip-proxy");
        showToast(`Welcome back, ${currentUser.name}!`);
        refreshAllViews();
      } catch (err) {
        alert(err.message);
      }
    });

    // Sign Up Form Submit (Account Approval Gate)
    formSignup.addEventListener("submit", (e) => {
      e.preventDefault();
      const name = document.getElementById("signup-name").value.trim();
      const nsuId = document.getElementById("signup-nsuid").value.trim();
      const role = document.getElementById("signup-role").value;
      const dept = document.getElementById("signup-dept").value.trim();
      const email = document.getElementById("signup-email").value.trim();
      const password = document.getElementById("signup-password").value;

      try {
        const regUser = db.registerUser({ name, email, password, role, dept, nsuId });
        formSignup.reset();
        
        // Switch dialog back to Sign In tab
        tabBtnSignin.click();
        const signinEmailInput = document.getElementById("signin-email");
        if (signinEmailInput) signinEmailInput.value = email;

        recordTelemetry("Proxy", `Registration submitted for ${name} (${email}, Role: ${role}) [PENDING_APPROVAL].`, "chip-proxy");
        showToast(`Registration submitted for ${name}. Awaiting Administrator approval.`);
        alert(`Registration Submitted Successfully!\n\nYour institutional account registration for "${name}" (${role}) has been recorded.\n\nInstitutional Security Policy:\nIn accordance with university access guidelines, newly created accounts require verification and approval by a Department Administrator before direct login is permitted.\n\nYour registration is now pending review in the Administrator Console.`);
        refreshAllViews();
      } catch (err) {
        alert(err.message);
      }
    });

    // Sign Out
    btnSignOut.addEventListener("click", () => {
      db.clearCurrentUser();
      currentUser = null;
      updateUserProfileDisplay();
      recordTelemetry("Proxy", "User signed out. Session cleared.", "chip-proxy");
      showToast("Signed out successfully.");
      refreshAllViews();
    });
  }

  // --------------------------------------------------------------------------
  // Catalog Rendering & Admin Decommission (Factory Pattern + Proxy)
  // --------------------------------------------------------------------------
  function setupCatalogControls() {
    categoryPills.forEach((pill) => {
      pill.addEventListener("click", () => {
        categoryPills.forEach((p) => p.classList.remove("active"));
        pill.classList.add("active");
        activeFilter = pill.dataset.filter;
        renderCatalog();
      });
    });

    catalogSearch.addEventListener("input", () => {
      renderCatalog();
    });
  }

  function renderCatalog() {
    catalogGrid.innerHTML = "";
    if (!currentUser) return; // Zero-Trust: Never render facilities into DOM if unauthenticated
    const rawAssets = db.getAssets();

    const query = (catalogSearch.value || "").toLowerCase().trim();
    const assignments = db.getAssignments ? db.getAssignments() : [];
    const assignedAssetIds = new Set(assignments.map((a) => a.assetId));
    const isStudent = currentUser && currentUser.role === "STUDENT";

    const filtered = rawAssets.filter((asset) => {
      // RULE: If resource is not assigned to any active officer/admin, do not show it to book
      if (!assignedAssetIds.has(asset.id)) return false;

      // RULE: Students can only see hardware kits and lab workstations (never seminar rooms)
      if (isStudent && asset.type === "SEMINAR") return false;

      const matchCat = activeFilter === "ALL" || asset.type === activeFilter;
      const matchQuery =
        !query ||
        asset.name.toLowerCase().includes(query) ||
        asset.location.toLowerCase().includes(query) ||
        asset.specs.toLowerCase().includes(query);
      return matchCat && matchQuery;
    });

    if (filtered.length === 0) {
      catalogGrid.innerHTML = `
        <div style="grid-column: 1 / -1; padding: 40px; text-align: center; color: var(--text-muted); background: #fff; border: 1px dashed var(--border-hairline); border-radius: var(--radius-md);">
          No facility matching your criteria was found. Try clearing your search query.
        </div>
      `;
      return;
    }

    const isAdmin = currentUser && currentUser.role === "ADMIN";

    filtered.forEach((raw) => {
      let domainAsset;
      try {
        domainAsset = window.AssetFactory.createAsset(raw.type, raw);
      } catch (err) {
        domainAsset = raw;
      }

      const assignedAdmin = db.getAssignedAdminForAsset(raw.id);
      const isAssignedOfficer = currentUser && currentUser.role === "ADMIN" && assignedAdmin && assignedAdmin.id === currentUser.id;
      const isSuper = currentUser && currentUser.role === "SUPER_ADMIN";
      const canManageFacility = isSuper || isAssignedOfficer;
      const isOffline = raw.status === "MAINTENANCE";

      const card = document.createElement("div");
      card.className = "asset-box";
      if (isOffline) {
        card.style.borderColor = "#fcd34d";
        card.style.background = "#fffdfa";
      }

      // Decommission button ONLY rendered for Super Admin
      const decommissionBtnHtml = isSuper
        ? `<button class="btn-decommission btn-decommission-asset" data-id="${raw.id}" title="Decommission asset from catalog">Decommission</button>`
        : "";

      // Toggle Maintenance button rendered for Assigned Admin or Super Admin
      const toggleMaintBtnHtml = canManageFacility
        ? `<button type="button" class="btn-action btn-outline-action btn-toggle-maint" data-id="${raw.id}" style="font-size:11px; padding:3px 8px; border-color:${isOffline ? '#16a34a' : '#d97706'}; color:${isOffline ? '#16a34a' : '#d97706'};">${isOffline ? 'Set Online' : 'Set Offline'}</button>`
        : "";

      // Booking button with icon
      const reserveBtnHtml = isOffline
        ? `<button type="button" class="btn-action btn-outline-action" disabled style="opacity:0.55; cursor:not-allowed;" title="Facility temporarily offline for maintenance">Offline</button>`
        : `<button class="btn-action btn-primary-action btn-request-slot" data-id="${raw.id}"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg> Book Slot</button>`;

      const isLabForStudent = isStudent && raw.type === "LAB";
      const displayName = isLabForStudent ? `${raw.name} (Single Workstation Seat)` : raw.name;
      const displayCapacity = isLabForStudent ? "1" : raw.capacity;
      const displayCapUnit = isLabForStudent ? "workstation seat" : "seats";
      const displayRate = isLabForStudent ? 15 : (raw.baseRate || 80);

      // Category icon and label mapping
      let catIconSvg = "";
      let catLabel = raw.type;
      if (isLabForStudent) {
        catIconSvg = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>`;
        catLabel = "Workstation Seat";
      } else if (raw.type === "LAB") {
        catIconSvg = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>`;
        catLabel = "Computing Lab";
      } else if (raw.type === "SEMINAR") {
        catIconSvg = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 3h20"></path><path d="M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3"></path><path d="m7 21 5-5 5 5"></path></svg>`;
        catLabel = "Seminar Hall";
      } else {
        catIconSvg = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="4" width="16" height="16" rx="2"></rect><rect x="9" y="9" width="6" height="6"></rect></svg>`;
        catLabel = "Hardware Kit";
      }

      // Feature tags from specs string
      const specItems = (raw.specs || "")
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean)
        .slice(0, 4);
      const specChipsHtml = specItems
        .map((s) => `<span class="spec-chip">${escapeHtml(s)}</span>`)
        .join("");

      // Status live beacon
      const statusBeaconHtml = isOffline
        ? `<span class="status-live-pill status-live-offline" role="status" aria-label="Facility status: Under Maintenance"><span class="live-dot pulse-amber" aria-hidden="true"></span>Maintenance</span>`
        : `<span class="status-live-pill status-live-available" role="status" aria-label="Facility status: Available for booking"><span class="live-dot pulse-emerald" aria-hidden="true"></span>Available</span>`;

      // Officer initials
      const officerInitials = assignedAdmin
        ? assignedAdmin.name.split(" ").map((w) => w[0]).slice(0, 2).join("")
        : "?";

      card.innerHTML = `
        <div>
          <div class="asset-meta-row">
            <span class="tag-category tag-${raw.type.toLowerCase()}">${catIconSvg} ${catLabel}</span>
            <div style="display:flex; align-items:center; gap:6px;">
              <span class="room-pill"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg> ${raw.location}</span>
              ${statusBeaconHtml}
            </div>
          </div>
          <h3 class="asset-name-heading">${displayName}</h3>
          <div class="specs-chips-row">${specChipsHtml}</div>
          <div class="officer-card-strip">
            <div class="mini-avatar">${officerInitials}</div>
            <div class="officer-meta">
              <span class="officer-label">Reviewing Officer</span>
              <span class="officer-name">${assignedAdmin ? assignedAdmin.name : "Unassigned (Awaiting Admin)"}</span>
            </div>
          </div>
        </div>
        <div class="asset-card-bottom">
          <div>
            <div class="capacity-pill"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg> <strong>${displayCapacity}</strong> ${displayCapUnit}</div>
            <div class="rate-badge"><span class="rate-amount">$${displayRate}</span><span class="rate-period">/hour</span></div>
          </div>
          <div style="display:flex; gap:6px; align-items:center; flex-wrap:wrap;">
            ${decommissionBtnHtml}
            ${toggleMaintBtnHtml}
            ${reserveBtnHtml}
          </div>
        </div>
      `;

      const reqBtn = card.querySelector(".btn-request-slot");
      if (reqBtn) {
        reqBtn.addEventListener("click", () => {
          openBookingDialog(raw);
        });
      }

      const maintBtn = card.querySelector(".btn-toggle-maint");
      if (maintBtn) {
        maintBtn.addEventListener("click", () => {
          const reason = prompt(`Specify reason for toggling status of '${raw.name}':`, isOffline ? "Servicing completed" : "Hardware inspection / repair");
          if (reason === null) return;
          try {
            bookingProxy.toggleAssetStatus(raw.id, currentUser, reason);
            showToast(`Facility '${raw.name}' status toggled.`);
            recordTelemetry("Proxy", `Facility #${raw.id} status toggled by ${currentUser.name}.`, "chip-proxy");
            refreshAllViews();
          } catch (err) {
            alert(err.message);
          }
        });
      }

      if (isSuper) {
        const decomBtn = card.querySelector(".btn-decommission-asset");
        if (decomBtn) {
          decomBtn.addEventListener("click", () => {
            handleDecommissionAsset(raw);
          });
        }
      }

      catalogGrid.appendChild(card);
    });

    recordTelemetry("Factory", `AssetFactory instantiated ${filtered.length} domain objects for view.`, "chip-factory");
  }

  function handleDecommissionAsset(asset) {
    if (!confirm(`Are you sure you want to decommission '${asset.name}' (#${asset.id}) from the campus catalog?`)) {
      return;
    }

    try {
      bookingProxy.deleteAsset(asset.id, currentUser);
      recordTelemetry("Proxy", `Authorized Admin decommission of asset #${asset.id}. Delegated to database.`, "chip-proxy");
      showToast(`Asset #${asset.id} decommissioned successfully.`);
      refreshAllViews();
    } catch (err) {
      alert(err.message);
      recordTelemetry("Proxy", `SECURITY REJECTION: ${err.message}`, "chip-proxy");
    }
  }

  // --------------------------------------------------------------------------
  // Admin Add New Facility Modal (Factory Pattern via Proxy)
  // --------------------------------------------------------------------------
  // --------------------------------------------------------------------------
  // Institutional Authentication Gate (Zero Unauthenticated Access)
  // --------------------------------------------------------------------------
  function setupAuthGate() {
    const gateScreen = document.getElementById("auth-gate-screen");
    const gateTabSignin = document.getElementById("gate-tab-signin");
    const gateTabSignup = document.getElementById("gate-tab-signup");
    const gateFormSignin = document.getElementById("gate-form-signin");
    const gateFormSignup = document.getElementById("gate-form-signup");
    const gateDemoBtns = document.querySelectorAll(".btn-gate-demo");

    if (!gateScreen) return;

    if (gateTabSignin && gateTabSignup) {
      gateTabSignin.addEventListener("click", () => {
        gateTabSignin.classList.add("active");
        gateTabSignup.classList.remove("active");
        if (gateFormSignin) gateFormSignin.style.display = "block";
        if (gateFormSignup) gateFormSignup.style.display = "none";
      });

      gateTabSignup.addEventListener("click", () => {
        gateTabSignup.classList.add("active");
        gateTabSignin.classList.remove("active");
        if (gateFormSignup) gateFormSignup.style.display = "block";
        if (gateFormSignin) gateFormSignin.style.display = "none";
      });
    }

    gateDemoBtns.forEach((btn) => {
      btn.addEventListener("click", () => {
        const email = btn.dataset.email;
        const pass = btn.dataset.pass;
        try {
          currentUser = db.authenticateUser(email, pass);
          updateUserProfileDisplay();
          recordTelemetry("Proxy", `Authenticated actor: ${currentUser.name} [Role: ${currentUser.role}].`, "chip-proxy");
          showToast(`Authenticated as ${currentUser.name} (${currentUser.role})`);
          refreshAllViews();
        } catch (err) {
          alert(err.message);
        }
      });
    });

    if (gateFormSignin) {
      gateFormSignin.addEventListener("submit", (e) => {
        e.preventDefault();
        const email = document.getElementById("gate-signin-email").value;
        const pass = document.getElementById("gate-signin-password").value;
        try {
          currentUser = db.authenticateUser(email, pass);
          updateUserProfileDisplay();
          gateFormSignin.reset();
          recordTelemetry("Proxy", `Institutional Sign In: ${currentUser.name} [Role: ${currentUser.role}].`, "chip-proxy");
          showToast(`Welcome, ${currentUser.name}!`);
          refreshAllViews();
        } catch (err) {
          alert(err.message);
        }
      });
    }

    if (gateFormSignup) {
      gateFormSignup.addEventListener("submit", (e) => {
        e.preventDefault();
        const name = document.getElementById("gate-signup-name").value.trim();
        const email = document.getElementById("gate-signup-email").value.trim();
        const nsuId = document.getElementById("gate-signup-nsuid").value.trim();
        const role = document.getElementById("gate-signup-role").value;
        const dept = document.getElementById("gate-signup-dept").value.trim();
        const password = document.getElementById("gate-signup-password").value;
        try {
          const regUser = db.registerUser({ name, email, password, role, dept, nsuId });
          gateFormSignup.reset();
          if (gateTabSignin) gateTabSignin.click();
          const gateSigninEmail = document.getElementById("gate-signin-email");
          if (gateSigninEmail) gateSigninEmail.value = email;

          recordTelemetry("Proxy", `New institutional account registration submitted: ${name} [PENDING_APPROVAL].`, "chip-proxy");
          showToast(`Registration submitted for ${name}. Awaiting Administrator approval.`);
          alert(`Registration Submitted Successfully!\n\nYour institutional account registration for "${name}" (${role}) has been recorded.\n\nInstitutional Security Policy:\nIn accordance with university access guidelines, newly created accounts require verification and approval by a Department Administrator before direct login is permitted.\n\nYour registration is now pending review in the Administrator Console.`);
          refreshAllViews();
        } catch (err) {
          alert(err.message);
        }
      });
    }
  }

  function setupAddAssetModal() {
    btnOpenAddAssetModal.addEventListener("click", () => {
      addAssetModal.style.display = "flex";
    });

    btnCloseAddAssetModal.addEventListener("click", () => {
      addAssetModal.style.display = "none";
    });

    btnCancelAddAsset.addEventListener("click", () => {
      addAssetModal.style.display = "none";
    });

    addAssetModal.addEventListener("click", (e) => {
      if (e.target === addAssetModal) addAssetModal.style.display = "none";
    });

    formAddAsset.addEventListener("submit", (e) => {
      e.preventDefault();

      const name = document.getElementById("new-asset-name").value.trim();
      const type = document.getElementById("new-asset-type").value;
      const location = document.getElementById("new-asset-loc").value.trim();
      const capacity = Number(document.getElementById("new-asset-capacity").value);
      const baseRate = Number(document.getElementById("new-asset-baserate").value);
      const specs = document.getElementById("new-asset-specs").value.trim();

      const newAssetId = (type === "LAB" ? "LAB-" : type === "SEMINAR" ? "SEM-" : "KIT-") + String(Date.now()).slice(-3);

      const rawAssetData = {
        id: newAssetId,
        name,
        type,
        location,
        capacity,
        baseRate,
        specs,
        status: "AVAILABLE"
      };

      try {
        // 1. Verify polymorphic instantiation via AssetFactory
        const domainObject = window.AssetFactory.createAsset(type, rawAssetData);
        recordTelemetry("Factory", `AssetFactory validated and created new ${type} domain object.`, "chip-factory");

        // 2. Guard persistence via SecureBookingProxy (Admin check)
        bookingProxy.addAsset(rawAssetData, currentUser);
        recordTelemetry("Proxy", `Authorized Admin registration for new facility #${newAssetId}.`, "chip-proxy");

        addAssetModal.style.display = "none";
        formAddAsset.reset();
        showToast(`New facility '${name}' registered to campus catalog!`);
        refreshAllViews();
      } catch (err) {
        alert(err.message);
        recordTelemetry("Proxy", `Error: ${err.message}`, "chip-proxy");
      }
    });
  }

  // --------------------------------------------------------------------------
  // Booking Dialog & Add-ons (Decorator Pattern) + Dynamic Slot Disabling
  // --------------------------------------------------------------------------
  const DEFAULT_CAMPUS_SLOTS = [
    { value: "08:00 - 10:00 AM", label: "08:00 - 10:00 AM (Morning Session 1)" },
    { value: "10:00 - 12:00 PM", label: "10:00 - 12:00 PM (Morning Session 2)" },
    { value: "12:00 - 02:00 PM", label: "12:00 - 02:00 PM (Midday Session)" },
    { value: "02:00 - 04:00 PM", label: "02:00 - 04:00 PM (Afternoon Session 1)" },
    { value: "04:00 - 06:00 PM", label: "04:00 - 06:00 PM (Afternoon Session 2)" }
  ];

  function setupModalDialog() {
    btnModalClose.addEventListener("click", closeBookingDialog);
    btnCancelModal.addEventListener("click", closeBookingDialog);

    facilityModal.addEventListener("click", (e) => {
      if (e.target === facilityModal) closeBookingDialog();
    });

    const dateInput = document.getElementById("input-reserve-date");
    const slotSelect = document.getElementById("select-reserve-slot");

    dateInput.addEventListener("input", () => {
      updateAvailableTimeSlots();
      renderLabSeatGrid(selectedAssetForBooking);
    });
    dateInput.addEventListener("change", () => {
      updateAvailableTimeSlots();
      renderLabSeatGrid(selectedAssetForBooking);
    });
    slotSelect.addEventListener("change", () => {
      renderLabSeatGrid(selectedAssetForBooking);
    });

    chkAmenities.forEach((chk) => {
      chk.addEventListener("change", updateDecoratorCalculation);
    });

    reservationDialogForm.addEventListener("submit", handleBookingSubmission);
  }

  function updateAvailableTimeSlots() {
    if (!selectedAssetForBooking) return;
    const dateInput = document.getElementById("input-reserve-date");
    const slotSelect = document.getElementById("select-reserve-slot");
    const warningBanner = document.getElementById("slot-collision-warning");
    const submitBtn = reservationDialogForm.querySelector('button[type="submit"]');

    const selectedDate = dateInput.value;
    const allBookings = db.getBookings();

    const isLab = selectedAssetForBooking && selectedAssetForBooking.type === "LAB";
    const labCapacity = (selectedAssetForBooking && selectedAssetForBooking.capacity) || 35;

    // Identify occupied time slots for this facility on the picked date
    const occupiedSlots = new Set();
    DEFAULT_CAMPUS_SLOTS.forEach((slot) => {
      const slotBookings = allBookings.filter(
        (b) =>
          b.assetId === selectedAssetForBooking.id &&
          b.date === selectedDate &&
          b.timeSlot === slot.value &&
          b.status !== "REJECTED" &&
          b.status !== "CANCELLED"
      );

      const hasWholeRoom = slotBookings.some((b) => b.isWholeRoom);
      if (hasWholeRoom) {
        occupiedSlots.add(slot.value);
      } else if (isLab) {
        const bookedSeatCount = slotBookings.filter((b) => b.seatNumber).length;
        if (bookedSeatCount >= labCapacity) {
          occupiedSlots.add(slot.value);
        }
      } else if (slotBookings.length > 0) {
        occupiedSlots.add(slot.value);
      }
    });

    const previouslySelected = slotSelect.value;
    slotSelect.innerHTML = "";
    let firstAvailable = null;

    DEFAULT_CAMPUS_SLOTS.forEach((slot) => {
      const isOccupied = occupiedSlots.has(slot.value);
      const opt = document.createElement("option");
      opt.value = slot.value;

      if (isOccupied) {
        opt.textContent = `${slot.value} - [OCCUPIED / UNAVAILABLE]`;
        opt.disabled = true;
        opt.style.color = "#94a3b8";
        opt.style.backgroundColor = "#f1f5f9";
      } else {
        opt.textContent = `${slot.label} (Available)`;
        opt.disabled = false;
        if (!firstAvailable) firstAvailable = slot.value;
      }

      slotSelect.appendChild(opt);
    });

    // Auto-select first available option if current selection is occupied
    if (occupiedSlots.has(previouslySelected)) {
      if (firstAvailable) {
        slotSelect.value = firstAvailable;
      }
    } else if (previouslySelected) {
      slotSelect.value = previouslySelected;
    } else if (firstAvailable) {
      slotSelect.value = firstAvailable;
    }

    // If all slots on this date are taken, block form submission
    if (occupiedSlots.size >= DEFAULT_CAMPUS_SLOTS.length) {
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.style.opacity = "0.45";
        submitBtn.style.cursor = "not-allowed";
        submitBtn.title = "No time slots available on this date.";
      }
      if (warningBanner) {
        warningBanner.textContent = "All time windows for this facility are fully booked on this date. Please select an alternate date.";
        warningBanner.style.display = "block";
      }
    } else {
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.style.opacity = "1";
        submitBtn.style.cursor = "pointer";
        submitBtn.title = "";
      }
      if (warningBanner) {
        warningBanner.style.display = "none";
      }
    }
  }

  // --------------------------------------------------------------------------
  // Interactive Lab Workstation Seat Grid Engine
  // --------------------------------------------------------------------------
  function renderLabSeatGrid(asset) {
    const labSeatWrapper = document.getElementById("lab-seat-selection-wrapper");
    const labSeatGrid = document.getElementById("lab-seat-grid");
    const inputSelectedSeat = document.getElementById("input-selected-seat");
    const seatSummary = document.getElementById("seat-stat-summary");
    const seatBadge = document.getElementById("seat-stat-active-badge");
    const btnSelectAll = document.getElementById("btn-select-all-seats");

    if (!labSeatWrapper || !labSeatGrid) return;

    const nonLabPanel = document.getElementById("non-lab-info-panel");
    if (!asset || asset.type !== "LAB") {
      labSeatWrapper.style.display = "none";
      if (nonLabPanel) nonLabPanel.style.display = "flex";
      if (inputSelectedSeat) inputSelectedSeat.value = "";
      return;
    }

    labSeatWrapper.style.display = "flex";
    if (nonLabPanel) nonLabPanel.style.display = "none";
    labSeatGrid.innerHTML = "";

    const isStudent = currentUser && currentUser.role === "STUDENT";
    const isStaffOrFaculty = currentUser && (currentUser.role === "FACULTY" || currentUser.role === "ADMIN" || currentUser.role === "OFFICER" || currentUser.role === "SUPER_ADMIN");

    const selectedDate = document.getElementById("input-reserve-date").value;
    const selectedSlot = document.getElementById("select-reserve-slot").value;

    const allBookings = db.getBookings();
    const activeBookings = allBookings.filter(
      (b) =>
        b.assetId === asset.id &&
        b.date === selectedDate &&
        b.timeSlot === selectedSlot &&
        b.status !== "REJECTED" &&
        b.status !== "CANCELLED"
    );

    const isWholeRoomBooked = activeBookings.some((b) => b.isWholeRoom);
    const occupiedSeatsMap = new Map();
    activeBookings.forEach((b) => {
      if (b.seatNumber) {
        String(b.seatNumber).split(",").forEach(s => {
          const cleanSeat = s.trim();
          if (cleanSeat) occupiedSeatsMap.set(cleanSeat, b.userName || "Reserved");
        });
      }
    });

    const capacity = Math.min(35, Math.max(15, asset.capacity || 25));
    const occupiedCount = isWholeRoomBooked ? capacity : occupiedSeatsMap.size;
    const availableCount = Math.max(0, capacity - occupiedCount);

    const monitorSvg = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>`;
    const lockSvg = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>`;

    const selectedSeatsSet = new Set(
      inputSelectedSeat && inputSelectedSeat.value
        ? (inputSelectedSeat.value === "ALL" ? [] : inputSelectedSeat.value.split(",").map(s => s.trim()).filter(Boolean))
        : []
    );
    const isAllWholeSelected = Boolean(inputSelectedSeat && inputSelectedSeat.value === "ALL" && occupiedCount === 0 && !isWholeRoomBooked);

    function updateSelectionState() {
      const selectedBtns = Array.from(document.querySelectorAll("#lab-seat-grid .seat-pod-btn.is-selected"));
      const selectedSeatIds = selectedBtns.map(b => b.dataset.seat).filter(Boolean).sort();
      const count = selectedSeatIds.length;

      const btnSpan = btnSelectAll ? btnSelectAll.querySelector("span") : null;

      if (count === 0) {
        if (inputSelectedSeat) inputSelectedSeat.value = "";
        if (seatBadge) {
          seatBadge.textContent = "No seat selected";
          seatBadge.className = "seat-active-badge";
        }
        if (btnSelectAll) {
          btnSelectAll.classList.remove("is-active");
          if (btnSpan) {
            btnSpan.textContent = occupiedCount > 0 ? `Select All Available (${availableCount})` : "Select All Seats (Whole Lab)";
          }
          btnSelectAll.title = occupiedCount > 0 ? `Select all ${availableCount} available workstations` : "Reserve all 35 workstations";
        }
      } else if (count === availableCount && availableCount > 0) {
        // All available seats selected
        if (occupiedCount === 0) {
          // Whole room
          if (inputSelectedSeat) inputSelectedSeat.value = "ALL";
          if (seatBadge) {
            seatBadge.textContent = `Whole Lab (All ${capacity} Seats)`;
            seatBadge.className = "seat-active-badge is-selected is-all-selected";
          }
          if (btnSelectAll) {
            btnSelectAll.classList.add("is-active");
            if (btnSpan) btnSpan.textContent = "Deselect All";
            btnSelectAll.title = "Click to deselect all workstations";
          }
        } else {
          // All available seats
          if (inputSelectedSeat) inputSelectedSeat.value = selectedSeatIds.join(", ");
          if (seatBadge) {
            seatBadge.textContent = `All Available (${count} Seats)`;
            seatBadge.className = "seat-active-badge is-selected is-all-selected";
          }
          if (btnSelectAll) {
            btnSelectAll.classList.add("is-active");
            if (btnSpan) btnSpan.textContent = `Deselect All (${count})`;
            btnSelectAll.title = "Click to deselect all workstations";
          }
        }
      } else if (count === 1) {
        if (inputSelectedSeat) inputSelectedSeat.value = selectedSeatIds[0];
        if (seatBadge) {
          seatBadge.textContent = `Assigned: ${selectedSeatIds[0]}`;
          seatBadge.className = "seat-active-badge is-selected";
        }
        if (btnSelectAll) {
          btnSelectAll.classList.remove("is-active");
          if (btnSpan) {
            btnSpan.textContent = occupiedCount > 0 ? `Select All Available (${availableCount})` : "Select All Seats (Whole Lab)";
          }
          btnSelectAll.title = occupiedCount > 0 ? `Select all ${availableCount} available workstations` : "Reserve all 35 workstations";
        }
      } else {
        // Multi-seat stacked selection (e.g. 2 to N-1 seats)
        if (inputSelectedSeat) inputSelectedSeat.value = selectedSeatIds.join(", ");
        if (seatBadge) {
          seatBadge.textContent = count <= 3 ? `Selected: ${selectedSeatIds.join(", ")}` : `Selected: ${count} Workstations`;
          seatBadge.className = "seat-active-badge is-selected";
        }
        if (btnSelectAll) {
          btnSelectAll.classList.remove("is-active");
          if (btnSpan) {
            btnSpan.textContent = occupiedCount > 0 ? `Select All Available (${availableCount})` : "Select All Seats (Whole Lab)";
          }
          btnSelectAll.title = occupiedCount > 0 ? `Select all ${availableCount} available workstations` : "Reserve all 35 workstations";
        }
      }
    }

    for (let i = 1; i <= capacity; i++) {
      const seatId = `WS-${String(i).padStart(2, "0")}`;
      const isOccupied = isWholeRoomBooked || occupiedSeatsMap.has(seatId);
      const isSelected = isAllWholeSelected ? !isOccupied : selectedSeatsSet.has(seatId);

      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "seat-pod-btn";
      btn.dataset.seat = seatId;

      btn.setAttribute("role", isStudent ? "radio" : "checkbox");
      btn.setAttribute("aria-checked", isSelected ? "true" : "false");
      btn.setAttribute("aria-disabled", isOccupied ? "true" : "false");
      btn.setAttribute("aria-label", `Workstation ${seatId} - ${isOccupied ? "Occupied" : "Available"}`);

      if (isOccupied) {
        btn.classList.add("is-occupied");
        btn.disabled = true;
        const occUser = isWholeRoomBooked ? "Full Lab Reserved" : occupiedSeatsMap.get(seatId);
        btn.title = `${seatId}: Occupied (${occUser})`;
        btn.innerHTML = `${lockSvg}<span>${seatId}</span>`;
      } else {
        btn.title = `${seatId}: Available - Click to toggle selection`;
        if (isSelected) {
          btn.classList.add("is-selected");
        }
        btn.innerHTML = `${monitorSvg}<span>${seatId}</span>`;

        // Interactive pod click with stackable multi-select for Faculty/Admin, single-select for Student
        btn.addEventListener("click", () => {
          if (isStudent) {
            // Students can only select 1 seat at a time
            const wasSelected = btn.classList.contains("is-selected");
            document.querySelectorAll(".seat-pod-btn").forEach((b) => b.classList.remove("is-selected"));
            if (!wasSelected) {
              btn.classList.add("is-selected");
            }
          } else {
            // Faculty / Admin: Stackable selection!
            // Click to toggle on/off without affecting other seats!
            if (btn.classList.contains("is-selected")) {
              btn.classList.remove("is-selected");
            } else {
              btn.classList.add("is-selected");
            }
          }
          updateSelectionState();
        });
      }

      labSeatGrid.appendChild(btn);
    }

    if (seatSummary) {
      if (isWholeRoomBooked) {
        seatSummary.innerHTML = `<span style="color:#b91c1c; font-weight:700;">Full Lab Reserved &bull; All ${capacity} workstation seats occupied by course session</span>`;
      } else {
        seatSummary.innerHTML = `Workstations: <strong style="color:#15803d;">${availableCount} Available</strong> &bull; <span style="color:#b91c1c;">${occupiedCount} Occupied</span> (${capacity} Total)`;
      }
    }

    // Configure "Select All Seats" button for Faculty and Admin
    if (btnSelectAll) {
      if (isStaffOrFaculty) {
        btnSelectAll.style.display = "inline-flex";
        const btnSpan = btnSelectAll.querySelector("span");

        const currentSelectedCount = document.querySelectorAll("#lab-seat-grid .seat-pod-btn.is-selected").length;
        const isBulkSelected = (currentSelectedCount > 0 && currentSelectedCount === availableCount) || isAllWholeSelected;

        btnSelectAll.classList.toggle("is-active", isBulkSelected);

        if (availableCount === 0) {
          btnSelectAll.disabled = true;
          btnSelectAll.style.opacity = "0.55";
          btnSelectAll.style.cursor = "not-allowed";
          btnSelectAll.title = "All workstations in this laboratory are occupied for this scheduled window.";
          if (btnSpan) btnSpan.textContent = "All Seats Occupied";
        } else {
          btnSelectAll.disabled = false;
          btnSelectAll.style.opacity = "1";
          btnSelectAll.style.cursor = "pointer";

          if (isBulkSelected) {
            if (btnSpan) btnSpan.textContent = occupiedCount > 0 ? `Deselect All (${availableCount})` : "Deselect All";
            btnSelectAll.title = "Click to deselect all workstations";
          } else {
            if (btnSpan) {
              btnSpan.textContent = occupiedCount > 0
                ? `Select All Available (${availableCount})`
                : "Select All Seats (Whole Lab)";
            }
            btnSelectAll.title = occupiedCount > 0
              ? `Select all remaining ${availableCount} available workstations together`
              : "Reserve all 35 workstations for whole-room session";
          }
        }

        btnSelectAll.onclick = () => {
          const isDeselect = btnSelectAll.classList.contains("is-active") ||
            (document.querySelectorAll("#lab-seat-grid .seat-pod-btn.is-selected").length === availableCount && availableCount > 0);

          if (isDeselect) {
            // UNCONDITIONAL DESELECT ALL:
            document.querySelectorAll("#lab-seat-grid .seat-pod-btn").forEach((b) => b.classList.remove("is-selected"));
            updateSelectionState();
            return;
          }

          if (availableCount === 0) {
            alert("All workstations in this laboratory are currently occupied for this scheduled time window.");
            return;
          }

          if (occupiedCount > 0) {
            // Partial occupancy notice
            alert(`Partial Occupancy Notice:
The entire laboratory room cannot be reserved as a whole room because ${occupiedCount} workstation(s) are already occupied.

However, all remaining ${availableCount} available workstations have been selected together for your group!`);

            document.querySelectorAll("#lab-seat-grid .seat-pod-btn:not(.is-occupied)").forEach((b) => {
              b.classList.add("is-selected");
            });
            updateSelectionState();
          } else {
            // 100% Vacant -> Select All 35 seats (Whole Lab)
            document.querySelectorAll("#lab-seat-grid .seat-pod-btn:not(.is-occupied)").forEach((b) => {
              b.classList.add("is-selected");
            });
            if (inputSelectedSeat) inputSelectedSeat.value = "ALL";
            updateSelectionState();
          }
        };
      } else {
        btnSelectAll.style.display = "none";
      }
    }

    // Initial badge synchronization
    updateSelectionState();
  }

  function openBookingDialog(asset) {
    if (!currentUser) {
      alert("Please sign in to submit a facility reservation.");
      authModal.style.display = "flex";
      return;
    }

    const isStudent = currentUser.role === "STUDENT";
    if (isStudent && asset.type === "SEMINAR") {
      alert("Access Denied: Students are not authorized to book Seminar rooms. Seminar rooms are reserved for Faculty and Academic Officers.");
      return;
    }

    const isLabForStudent = isStudent && asset.type === "LAB";
    const displayName = isLabForStudent ? `Reserve Workstation Seat: ${asset.name}` : `Reserve ${asset.name}`;
    const displayCap = isLabForStudent ? "1 Seat (Workstation)" : `${asset.capacity} seats`;
    const displayRate = isLabForStudent ? 15 : (asset.baseRate || 80);

    const modalBox = facilityModal.querySelector(".modal-dialog");
    if (asset.type === "LAB") {
      if (modalBox) modalBox.classList.add("modal-dialog-lab");
    } else {
      if (modalBox) modalBox.classList.remove("modal-dialog-lab");
    }

    selectedAssetForBooking = asset;
    modalHeadingName.textContent = displayName;
    modalSubheadingLoc.textContent = `Location: ${asset.location} | Category: ${isLabForStudent ? "Single Workstation Seat" : asset.type} | Capacity: ${displayCap} | Base: $${displayRate}/hr`;

    const nonLabPanel = document.getElementById("non-lab-info-panel");
    if (nonLabPanel) {
      const specsEl = document.getElementById("non-lab-card-specs");
      const locEl = document.getElementById("non-lab-card-location");
      const officerEl = document.getElementById("non-lab-card-officer");
      const titleEl = document.getElementById("non-lab-card-title");
      if (specsEl) specsEl.textContent = asset.specs || "Standard university configuration";
      if (locEl) locEl.textContent = `${asset.location} (Capacity: ${displayCap})`;
      if (titleEl) titleEl.textContent = `${asset.name} - Specifications & Guidelines`;

      const assignment = db.getAssignments().find((a) => a.assetId === asset.id);
      const officer = assignment ? db.getUsers().find((u) => u.id === assignment.adminId) : null;
      if (officerEl) officerEl.textContent = officer ? `${officer.name} (${officer.department || "ECE"})` : "Assigned Administrative Officer";
    }

    reservationDialogForm.reset();
    document.getElementById("input-reserve-date").value = "2026-11-20";
    document.getElementById("select-reserve-slot").value = "08:00 - 10:00 AM";
    const seatInput = document.getElementById("input-selected-seat");
    if (seatInput) {
      seatInput.value = "";
    }

    updateAvailableTimeSlots();
    renderLabSeatGrid(asset);
    updateDecoratorCalculation();

    facilityModal.style.display = "flex";
  }

  function closeBookingDialog() {
    facilityModal.style.display = "none";
    selectedAssetForBooking = null;
  }

  function updateDecoratorCalculation() {
    if (!selectedAssetForBooking) return;

    const isStudent = currentUser && currentUser.role === "STUDENT";
    const isLabForStudent = isStudent && selectedAssetForBooking.type === "LAB";
    const effectiveBaseRate = isLabForStudent ? 15 : (selectedAssetForBooking.baseRate || 80);

    let item = new window.BaseReservation(selectedAssetForBooking, effectiveBaseRate);

    chkAmenities.forEach((chk) => {
      if (chk.checked) {
        if (chk.value === "PROJECTOR") item = new window.ProjectorDecorator(item);
        if (chk.value === "UPS") item = new window.UPSBackupDecorator(item);
        if (chk.value === "STAFF") item = new window.LabAssistantDecorator(item);
        if (chk.value === "NETWORK") item = new window.GigabitNetworkDecorator(item);
      }
    });

    modalComputedCost.textContent = `$${item.getCost()}`;
    modalDecorDesc.textContent = item.getDescription();
  }

  function handleBookingSubmission(e) {
    e.preventDefault();
    if (!selectedAssetForBooking || !currentUser) return;

    const dateVal = document.getElementById("input-reserve-date").value;
    const slotVal = document.getElementById("select-reserve-slot").value;
    const purposeVal = document.getElementById("input-reserve-purpose").value.trim();

    if (!dateVal || !slotVal || !purposeVal) {
      alert("Please specify date, time slot, and academic purpose.");
      return;
    }

    const existing = db.getBookings();

    // 1. Fair-Use Quota: Maximum 3 active/pending bookings for Students
    if (currentUser.role === "STUDENT") {
      const activeStudentBookings = existing.filter(
        (b) =>
          b.userId === currentUser.id &&
          (b.status === "PENDING" || b.status === "APPROVED")
      );
      if (activeStudentBookings.length >= 3) {
        alert("Fair-Use Quota Limit: Students may hold a maximum of 3 active or pending reservations concurrently to ensure equitable campus access. Please complete or cancel an existing reservation before requesting another.");
        return;
      }
    }

    // 2. Duplicate Pending Request Protection (anti-spam for all users)
    const hasPendingSameAsset = existing.some(
      (b) =>
        b.userId === currentUser.id &&
        b.assetId === selectedAssetForBooking.id &&
        b.status === "PENDING"
    );
    if (hasPendingSameAsset) {
      alert(`Duplicate Request Blocked: You already have a pending reservation request for '${selectedAssetForBooking.name}' awaiting department review. Please await administrative approval before submitting another request for this resource.`);
      return;
    }

    // 3. Same-Day Resource Monopolization Guard
    const hasSameDayBooking = existing.some(
      (b) =>
        b.userId === currentUser.id &&
        b.assetId === selectedAssetForBooking.id &&
        b.date === dateVal &&
        (b.status === "PENDING" || b.status === "APPROVED")
    );
    if (hasSameDayBooking) {
      alert(`Repetitive Booking Guard: You already have an active or pending reservation for '${selectedAssetForBooking.name}' on ${dateVal}. To ensure fair access for all departments, please choose another facility or select an alternate date.`);
      return;
    }

    const isStudent = currentUser && currentUser.role === "STUDENT";
    const isLab = selectedAssetForBooking.type === "LAB";
    const isLabForStudent = isStudent && isLab;

    const seatInput = document.getElementById("input-selected-seat");
    const chosenSeat = seatInput ? seatInput.value.trim() : "";
    const isAllWholeLab = chosenSeat === "ALL";
    const isMultiSeat = chosenSeat.includes(",");
    const isSingleSeat = Boolean(chosenSeat && !isAllWholeLab && !isMultiSeat);

    if (isLab && isStudent) {
      if (!chosenSeat || isAllWholeLab || isMultiSeat) {
        alert("Please select your designated individual workstation seat from the lab grid before submitting.");
        return;
      }
    }

    const isWholeRoom = !isStudent && isAllWholeLab && selectedAssetForBooking.type !== "HARDWARE";
    const effectiveBaseRate = isStudent && isSingleSeat ? 15 : (selectedAssetForBooking.baseRate || 80);

    // 4. Atomic Collision Detection (Double-Booking & Seat Collision Guard)
    const hasCollision = existing.some((b) => {
      if (b.assetId !== selectedAssetForBooking.id || b.date !== dateVal || b.timeSlot !== slotVal) return false;
      if (b.status === "REJECTED" || b.status === "CANCELLED") return false;
      if (isWholeRoom || b.isWholeRoom) return true;
      if (chosenSeat && b.seatNumber) {
        const reqSeats = String(chosenSeat).split(",").map((s) => s.trim());
        const existingSeats = String(b.seatNumber).split(",").map((s) => s.trim());
        return reqSeats.some((s) => existingSeats.includes(s));
      }
      return !chosenSeat && !b.seatNumber;
    });

    if (hasCollision) {
      if (isWholeRoom) {
        alert(`Schedule Collision: Cannot reserve entire ${selectedAssetForBooking.name} on ${dateVal} for ${slotVal} because workstation reservations or course bookings already exist for this time window.`);
      } else if (isSingleSeat) {
        alert(`Seat Collision: Workstation ${chosenSeat} in ${selectedAssetForBooking.name} is already occupied on ${dateVal} for ${slotVal}. Please select an alternate seat from the grid.`);
      } else {
        alert(`Schedule Collision: Some of the selected workstations in ${selectedAssetForBooking.name} are already booked on ${dateVal} for ${slotVal}. Please select available seats.`);
      }
      renderLabSeatGrid(selectedAssetForBooking);
      return;
    }

    // Decorator chain execution
    let decoratorChain = new window.BaseReservation(selectedAssetForBooking, effectiveBaseRate);
    const attachedAddons = [];

    chkAmenities.forEach((chk) => {
      if (chk.checked) {
        if (chk.value === "PROJECTOR") {
          decoratorChain = new window.ProjectorDecorator(decoratorChain);
          attachedAddons.push("HD Laser Projector (+$45)");
        }
        if (chk.value === "UPS") {
          decoratorChain = new window.UPSBackupDecorator(decoratorChain);
          attachedAddons.push("Emergency UPS Power Backup (+$25)");
        }
        if (chk.value === "STAFF") {
          decoratorChain = new window.LabAssistantDecorator(decoratorChain);
          attachedAddons.push("Dedicated Lab Staff Assistant (+$60)");
        }
        if (chk.value === "NETWORK") {
          decoratorChain = new window.GigabitNetworkDecorator(decoratorChain);
          attachedAddons.push("Gigabit Network Priority (+$35)");
        }
      }
    });

    const assignedAdmin = db.getAssignedAdminForAsset(selectedAssetForBooking.id);
    const newBooking = {
      id: "RES-" + String(Date.now()).slice(-4),
      assetId: selectedAssetForBooking.id,
      assetName: isWholeRoom
        ? selectedAssetForBooking.name
        : (isMultiSeat
            ? `${selectedAssetForBooking.name} (${chosenSeat.split(",").length} Workstations)`
            : (isSingleSeat ? `${selectedAssetForBooking.name} (Seat ${chosenSeat})` : (isLabForStudent ? `${selectedAssetForBooking.name} (Single Workstation Seat)` : selectedAssetForBooking.name))),
      assetLocation: selectedAssetForBooking.location,
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      assignedAdminId: assignedAdmin ? assignedAdmin.id : "UNASSIGNED",
      assignedAdminName: assignedAdmin ? assignedAdmin.name : "Department Officer",
      date: dateVal,
      timeSlot: slotVal,
      seatNumber: isWholeRoom ? null : chosenSeat,
      purpose: purposeVal,
      addons: attachedAddons,
      baseRate: effectiveBaseRate,
      totalCost: decoratorChain.getCost(),
      isSingleSeat: Boolean(isSingleSeat || isLabForStudent),
      isWholeRoom: Boolean(isWholeRoom),
      status: "PENDING",
      submittedAt: new Date().toISOString()
    };

    recordTelemetry("Decorator", `Chained add-on decorators. Total calculated: $${newBooking.totalCost}.`, "chip-decorator");

    try {
      bookingProxy.createBooking(newBooking);
      recordTelemetry("Proxy", `SecureBookingProxy submitted reservation #${newBooking.id}.`, "chip-proxy");
      closeBookingDialog();
      refreshAllViews();
      showToast(`Reservation #${newBooking.id} submitted for department approval.`);
    } catch (err) {
      recordTelemetry("Proxy", `Access / Guard violation: ${err.message}`, "chip-proxy");
      alert(err.message);
    }
  }

  // --------------------------------------------------------------------------
  // Receipt / Voucher Modal
  // --------------------------------------------------------------------------
  function setupReceiptModal() {
    btnCloseReceiptModal.addEventListener("click", () => {
      receiptModal.style.display = "none";
    });

    receiptModal.addEventListener("click", (e) => {
      if (e.target === receiptModal) receiptModal.style.display = "none";
    });

    btnPrintVoucher.addEventListener("click", () => {
      window.print();
    });
  }

  function openReceiptModal(booking) {
    document.getElementById("rec-id").textContent = `#${booking.id}`;
    document.getElementById("rec-issued").textContent = new Date().toLocaleDateString();
    document.getElementById("rec-user").textContent = booking.userName;
    document.getElementById("rec-role").textContent = booking.userRole;
    document.getElementById("rec-date").textContent = booking.date;
    document.getElementById("rec-slot").textContent = booking.timeSlot;
    document.getElementById("rec-total").textContent = `$${booking.totalCost}`;

    const seatRow = document.getElementById("rec-seat-row");
    if (seatRow) {
      if (booking.seatNumber) {
        seatRow.style.display = "block";
        document.getElementById("rec-seat").textContent = booking.seatNumber;
      } else {
        seatRow.style.display = "none";
      }
    }

    const itemsContainer = document.getElementById("rec-items-list");
    itemsContainer.innerHTML = `
      <div class="receipt-line-item">
        <span>Base Facility: ${booking.assetName}</span>
        <strong>$${booking.baseRate || 80}</strong>
      </div>
    `;

    if (booking.addons && booking.addons.length > 0) {
      booking.addons.forEach((addon) => {
        itemsContainer.innerHTML += `
          <div class="receipt-line-item" style="color:var(--text-secondary);">
            <span>+ ${addon}</span>
            <span>Included</span>
          </div>
        `;
      });
    }

    const stamp = document.getElementById("rec-status-stamp");
    stamp.textContent = booking.status;
    if (booking.status === "APPROVED") {
      stamp.style.borderColor = "#16a34a";
      stamp.style.color = "#16a34a";
    } else if (booking.status === "PENDING") {
      stamp.style.borderColor = "#d97706";
      stamp.style.color = "#d97706";
    } else {
      stamp.style.borderColor = "#dc2626";
      stamp.style.color = "#dc2626";
    }

    receiptModal.style.display = "flex";
  }

  // --------------------------------------------------------------------------
  // Tables: My Bookings, Department Schedule, Approvals
  // --------------------------------------------------------------------------
  function setupStrategyControls() {
    const strategyButtons = document.querySelectorAll(".btn-strategy-option");
    if (strategyButtons && strategyButtons.length > 0) {
      strategyButtons.forEach((btn) => {
        btn.addEventListener("click", () => {
          const mode = btn.getAttribute("data-strategy");
          strategyButtons.forEach((b) => {
            b.classList.remove("active");
            b.setAttribute("aria-pressed", "false");
          });
          btn.classList.add("active");
          btn.setAttribute("aria-pressed", "true");

          let newStrat;
          if (mode === "FACULTY") {
            newStrat = new window.FacultyPriorityStrategy();
          } else {
            newStrat = new window.FCFSStrategy();
          }

          scheduler.setStrategy(newStrat);
          recordTelemetry(
            "Strategy",
            `Queue prioritization policy updated to: ${newStrat.name} (${mode})`,
            "chip-strategy"
          );
          showToast(`Policy Active: ${newStrat.name}`);
          renderApprovals();
        });
      });
    }
  }

  // --------------------------------------------------------------------------
  // TABLE 1: My Bookings Render Function (with Live Search & Status Filters)
  // --------------------------------------------------------------------------
  function renderMyBookings() {
    const allBookings = db.getBookings();
    let bookingsToShow = currentUser
      ? allBookings.filter((b) => b.userId === currentUser.id)
      : [];

    // Filter by status pill
    if (myBookingsStatusFilter !== "ALL") {
      bookingsToShow = bookingsToShow.filter((b) => b.status === myBookingsStatusFilter);
    }

    // Filter by live search query
    if (myBookingsSearchQuery.trim()) {
      const q = myBookingsSearchQuery.toLowerCase().trim();
      bookingsToShow = bookingsToShow.filter((b) =>
        (b.assetName && b.assetName.toLowerCase().includes(q)) ||
        (b.id && b.id.toLowerCase().includes(q)) ||
        (b.purpose && b.purpose.toLowerCase().includes(q))
      );
    }

    myBookingsTbody.innerHTML = "";
    const countBadge = document.getElementById("my-bookings-count");
    if (countBadge) countBadge.textContent = bookingsToShow.length;
    const countPill = document.getElementById("my-bookings-count-pill");
    if (countPill) countPill.textContent = `${bookingsToShow.length} Records`;

    if (!currentUser) {
      myBookingsTbody.innerHTML = `<tr><td colspan="7"><div class="table-empty-state"><div class="empty-state-icon-box"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg></div><div class="empty-state-title">Not Signed In</div><div class="empty-state-desc">Please switch profile or sign in to inspect your personal reservation ledger.</div></div></td></tr>`;
      return;
    }

    if (bookingsToShow.length === 0) {
      myBookingsTbody.innerHTML = `<tr><td colspan="7"><div class="table-empty-state"><div class="empty-state-icon-box"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg></div><div class="empty-state-title">No Matching Reservations Found</div><div class="empty-state-desc">No active or historical bookings match your current filter criteria. Book a facility from the catalog.</div></div></td></tr>`;
      return;
    }

    bookingsToShow.forEach((b) => {
      const tr = document.createElement("tr");
      const canCancel = b.status === "PENDING" && (b.userId === currentUser.id || currentUser.role === "ADMIN");
      const cancelAction = canCancel
        ? `<button type="button" class="btn-table-action btn-table-cancel btn-cancel-booking" data-id="${b.id}">
             <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
             <span>Cancel</span>
           </button>`
        : ``;

      const addonBadges = b.addons && b.addons.length > 0
        ? b.addons.map((a) => `<span class="addon-chip">${a}</span>`).join(" ")
        : `<span style="color:#94a3b8; font-size:11.5px; font-weight:500;">Standard Base</span>`;

      tr.innerHTML = `
        <td class="cell-nowrap">
          <span class="id-badge" style="font-family:'JetBrains Mono',monospace;">#${b.id}</span>
        </td>
        <td>
          <div class="facility-cell">
            <div class="facility-title">${b.assetName}</div>
            <div class="facility-sub">
              <span>${b.userName}</span>
              <span class="user-role-badge-pill" style="font-size:9px; padding:1px 5px;">${b.userRole}</span>
            </div>
          </div>
        </td>
        <td class="cell-nowrap">
          <div style="display:flex; flex-direction:column; gap:3px;">
            <span class="date-pill-block">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
              ${b.date}
            </span>
            <span class="time-slot-pill">
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
              ${b.timeSlot}
            </span>
          </div>
        </td>
        <td>${addonBadges}</td>
        <td class="cell-nowrap">
          <span style="font-family:'JetBrains Mono',monospace; font-weight:700; color:#0f172a; font-size:13px;">$${b.totalCost}</span>
        </td>
        <td class="cell-nowrap">
          <span class="status-pill status-${(b.status || 'PENDING').toLowerCase()}">
            <span class="status-dot"></span>${b.status || "PENDING"}
          </span>
        </td>
        <td class="cell-nowrap">
          <div style="display:flex; gap:6px;">
            <button type="button" class="btn-table-action btn-table-view btn-view-receipt" data-id="${b.id}" title="Inspect Official Voucher">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg>
              <span>Voucher</span>
            </button>
            ${cancelAction}
          </div>
        </td>
      `;

      tr.querySelector(".btn-view-receipt").addEventListener("click", () => {
        openReceiptModal(b);
      });

      const cancelBtn = tr.querySelector(".btn-cancel-booking");
      if (cancelBtn) {
        cancelBtn.addEventListener("click", () => {
          if (confirm(`Are you sure you want to cancel reservation #${b.id}?`)) {
            db.deleteBooking(b.id);
            subject.notify("BOOKING_CANCELLED", b);
            recordTelemetry("Observer", `Booking #${b.id} cancelled. Observers notified.`, "chip-observer");
            refreshAllViews();
            showToast(`Booking #${b.id} cancelled successfully.`);
          }
        });
      }

      myBookingsTbody.appendChild(tr);
    });
  }

  // --------------------------------------------------------------------------
  // TABLE 2: Department Master Schedule (with Search & Type Filters)
  // --------------------------------------------------------------------------
  function renderDeptSchedule() {
    let allBookings = db.getBookings();

    // Filter by asset type
    if (scheduleTypeFilter !== "ALL") {
      allBookings = allBookings.filter((b) => {
        const asset = db.getAssets().find((a) => a.id === b.assetId);
        return asset && asset.type === scheduleTypeFilter;
      });
    }

    // Filter by live search query
    if (scheduleSearchQuery.trim()) {
      const q = scheduleSearchQuery.toLowerCase().trim();
      allBookings = allBookings.filter((b) =>
        (b.assetName && b.assetName.toLowerCase().includes(q)) ||
        (b.userName && b.userName.toLowerCase().includes(q)) ||
        (b.purpose && b.purpose.toLowerCase().includes(q)) ||
        (b.date && b.date.toLowerCase().includes(q))
      );
    }

    deptScheduleTbody.innerHTML = "";
    const countPill = document.getElementById("schedule-count-pill");
    if (countPill) countPill.textContent = `${allBookings.length} Sessions`;

    if (allBookings.length === 0) {
      deptScheduleTbody.innerHTML = `<tr><td colspan="7"><div class="table-empty-state"><div class="empty-state-icon-box"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg></div><div class="empty-state-title">No Department Sessions Scheduled</div><div class="empty-state-desc">No academic bookings match the selected filters. Use the search bar above to look up other dates or facilities.</div></div></td></tr>`;
      return;
    }

    allBookings.forEach((b) => {
      const asset = db.getAssets().find((a) => a.id === b.assetId);
      const loc = asset ? asset.location : "SAC Wing";
      const tr = document.createElement("tr");

      tr.innerHTML = `
        <td>
          <strong style="color:#0f172a; font-size:13px;">${b.assetName}</strong>
        </td>
        <td class="cell-nowrap">
          <span class="user-role-badge-pill" style="font-size:10px; background:#f1f5f9; color:#475569; border:1px solid #e2e8f0;">${loc}</span>
        </td>
        <td class="cell-nowrap">
          <span class="date-pill-block">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
            ${b.date}
          </span>
        </td>
        <td class="cell-nowrap">
          <span class="time-slot-pill">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
            ${b.timeSlot}
          </span>
        </td>
        <td>
          <div style="display:flex; align-items:center; gap:6px;">
            <span style="font-weight:600; color:#1e293b; font-size:12.5px;">${b.userName}</span>
            <span class="user-role-badge-pill" style="font-size:9.5px; padding:1px 5px;">${b.userRole}</span>
          </div>
        </td>
        <td style="color:#475569; font-size:12px; max-width:240px;">${b.purpose}</td>
        <td class="cell-nowrap">
          <span class="status-pill status-${(b.status || 'PENDING').toLowerCase()}">
            <span class="status-dot"></span>${b.status || "PENDING"}
          </span>
        </td>
      `;
      deptScheduleTbody.appendChild(tr);
    });
  }

  // --------------------------------------------------------------------------
  // TABLE 3: Approval Queue (with Search, Status Filters & Segmented Policy)
  // --------------------------------------------------------------------------
  function renderApprovals() {
    const allBookings = db.getBookings();
    let displayList = approvalsFilterMode === "PENDING"
      ? allBookings.filter((b) => b.status === "PENDING")
      : allBookings;

    const panelTitle = document.getElementById("approvals-panel-title");
    const banner = document.getElementById("approvals-jurisdiction-banner");

    const isOfficer = currentUser && (currentUser.role === "OFFICER" || (currentUser.role === "ADMIN" && currentUser.id && currentUser.id.startsWith("OFF-")));
    const isMasterAdmin = currentUser && ((currentUser.role === "ADMIN" && (!currentUser.id || !currentUser.id.startsWith("OFF-"))) || currentUser.role === "SUPER_ADMIN");

    if (isOfficer) {
      const assignedAsset = db.getAssignedAssetForAdmin(currentUser.id);
      if (!assignedAsset) {
        document.getElementById("pending-approval-badge").textContent = "0";
        document.getElementById("stat-pending-approvals").textContent = "0";
        const countPill = document.getElementById("approvals-count-pill");
        if (countPill) countPill.textContent = "0 Pending";
        if (panelTitle) panelTitle.textContent = "Department Approval Queue: Unassigned Officer";
        if (banner) {
          banner.style.display = "block";
          banner.style.background = "#fffbeb";
          banner.style.color = "#92400e";
          banner.style.border = "1px solid #fde68a";
          banner.innerHTML = `<strong>No Facility Jurisdiction:</strong> Officer '${currentUser.name}' has not been assigned a facility by the Administrator.<br>You cannot review or approve requests until assigned in the Admin Console.`;
        }
        approvalQueueTbody.innerHTML = `<tr><td colspan="7"><div class="table-empty-state"><div class="empty-state-icon-box"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#d97706" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg></div><div class="empty-state-title">No Facility Jurisdiction Assigned</div><div class="empty-state-desc">You are not currently assigned to any university lab or seminar hall. Contact the Administrator via Admin Console to receive exclusive facility jurisdiction.</div></div></td></tr>`;
        return;
      }

      // Filter ONLY requests for this specific assigned asset!
      displayList = displayList.filter((b) => b.assetId === assignedAsset.id);

      if (panelTitle) panelTitle.textContent = `Approval Queue: ${assignedAsset.name} (${assignedAsset.location})`;
      if (banner) {
        banner.style.display = "block";
        banner.style.background = "#f0fdf4";
        banner.style.color = "#166534";
        banner.style.border = "1px solid #bbf7d0";
        banner.innerHTML = `<strong>Exclusive Jurisdiction Active:</strong> Managing <u>${assignedAsset.name}</u>. Requests for other facilities are segregated and routed to their respective officers.`;
      }
    } else if (isMasterAdmin) {
      if (panelTitle) panelTitle.textContent = "Department Approval Queue: Master Overview (Admin)";
      if (banner) {
        banner.style.display = "block";
        banner.style.background = "#eef2ff";
        banner.style.color = "#3730a3";
        banner.style.border = "1px solid #c7d2fe";
        banner.innerHTML = "<strong>System Administrator Root Access:</strong> You have overarching authority to inspect, approve, or override bookings for all campus facilities.";
      }
    } else {
      if (banner) banner.style.display = "none";
    }

    // Apply live search query filter
    if (approvalsSearchQuery.trim()) {
      const q = approvalsSearchQuery.toLowerCase().trim();
      displayList = displayList.filter((b) =>
        (b.assetName && b.assetName.toLowerCase().includes(q)) ||
        (b.userName && b.userName.toLowerCase().includes(q)) ||
        (b.id && b.id.toLowerCase().includes(q)) ||
        (b.purpose && b.purpose.toLowerCase().includes(q))
      );
    }

    const prioritizedQueue = scheduler.execute(displayList);
    const pendingCount = displayList.filter((b) => b.status === "PENDING").length;

    const countBadge = document.getElementById("pending-approval-badge");
    if (countBadge) countBadge.textContent = pendingCount;
    const statPending = document.getElementById("stat-pending-approvals");
    if (statPending) statPending.textContent = pendingCount;
    const countPill = document.getElementById("approvals-count-pill");
    if (countPill) countPill.textContent = `${pendingCount} Pending`;

    approvalQueueTbody.innerHTML = "";

    if (prioritizedQueue.length === 0) {
      approvalQueueTbody.innerHTML = `<tr><td colspan="7"><div class="table-empty-state"><div class="empty-state-icon-box"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg></div><div class="empty-state-title">All Caught Up! Queue is Clear</div><div class="empty-state-desc">No reservation requests require review at this time. New student or faculty requests will appear here automatically.</div></div></td></tr>`;
      return;
    }

    prioritizedQueue.forEach((res, index) => {
      const tr = document.createElement("tr");
      const isPending = res.status === "PENDING";
      const actionButtons = isPending
        ? `<div style="display:flex; gap:6px;">
             <button type="button" class="btn-table-action btn-table-approve btn-approve-booking" data-id="${res.id}">
               <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
               <span>Approve</span>
             </button>
             <button type="button" class="btn-table-action btn-table-reject btn-reject-booking" data-id="${res.id}">
               <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
               <span>Reject</span>
             </button>
           </div>`
        : `<span style="font-size:11px; color:#64748b; font-weight:600;">Decided by ${res.reviewedBy || "Admin"}</span>`;

      tr.innerHTML = `
        <td class="cell-nowrap">
          <span class="priority-tag" style="font-family:'JetBrains Mono',monospace;">#${index + 1}</span>
        </td>
        <td>
          <div class="facility-cell">
            <strong style="color:#0f172a; font-size:13px;">${res.assetName}</strong>
            <div class="facility-sub"><span class="id-badge" style="font-family:'JetBrains Mono',monospace;">#${res.id}</span></div>
          </div>
        </td>
        <td>
          <div style="display:flex; align-items:center; gap:6px;">
            <span style="font-weight:600; color:#1e293b;">${res.userName}</span>
            <span class="user-role-badge-pill" style="font-size:9.5px; padding:1px 5px;">${res.userRole}</span>
          </div>
        </td>
        <td class="cell-nowrap">
          <div style="display:flex; flex-direction:column; gap:3px;">
            <span class="date-pill-block">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
              ${res.date}
            </span>
            <span class="time-slot-pill">
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
              ${res.timeSlot}
            </span>
          </div>
        </td>
        <td style="color:#475569; font-size:12px; max-width:220px;">${res.purpose}</td>
        <td class="cell-nowrap">
          <span class="status-pill status-${res.status.toLowerCase()}">
            <span class="status-dot"></span>${res.status}
          </span>
        </td>
        <td class="cell-nowrap">
          ${actionButtons}
        </td>
      `;

      const btnApprove = tr.querySelector(".btn-approve-booking");
      if (btnApprove) {
        btnApprove.addEventListener("click", () => {
          const remarks = prompt(`Approve reservation #${res.id} for '${res.assetName}'?\nOptional remarks for student/faculty:`, "Approved for departmental academic session");
          if (remarks !== null) {
            try {
              bookingProxy.approveBooking(res.id, currentUser, remarks);
              recordTelemetry("Proxy", `ProtectionProxy granted approval on #${res.id} by ${currentUser.name}.`, "chip-proxy");
              showToast(`Reservation #${res.id} approved successfully!`);
              refreshAllViews();
            } catch (err) {
              recordTelemetry("Proxy", `BLOCKED approval on #${res.id}: ${err.message}`, "chip-proxy");
              alert(err.message);
            }
          }
        });
      }

      const btnReject = tr.querySelector(".btn-reject-booking");
      if (btnReject) {
        btnReject.addEventListener("click", () => {
          const remarks = prompt(`Reject reservation #${res.id} for '${res.assetName}'?\nMandatory reason:`, "Schedule conflict or maintenance priority");
          if (remarks) {
            try {
              bookingProxy.rejectBooking(res.id, currentUser, remarks);
              recordTelemetry("Proxy", `ProtectionProxy rejected reservation #${res.id} by ${currentUser.name}.`, "chip-proxy");
              showToast(`Reservation #${res.id} rejected.`);
              refreshAllViews();
            } catch (err) {
              recordTelemetry("Proxy", `BLOCKED rejection on #${res.id}: ${err.message}`, "chip-proxy");
              alert(err.message);
            }
          }
        });
      }

      approvalQueueTbody.appendChild(tr);
    });
  }

  // --------------------------------------------------------------------------
  // TABLE 4: System Audit Trail (with Search, Event Filter & Export)
  // --------------------------------------------------------------------------
  function renderAuditLogs() {
    let logs = db.getAuditLogs();

    // Filter by event category pill
    if (auditEventFilter !== "ALL") {
      if (auditEventFilter === "SECURITY") {
        logs = logs.filter((l) => l.event.includes("SECURITY") || l.event.includes("VIOLATION") || l.event.includes("BLOCKED"));
      } else if (auditEventFilter === "BOOKING") {
        logs = logs.filter((l) => l.event.includes("BOOKING"));
      } else if (auditEventFilter === "ASSET") {
        logs = logs.filter((l) => l.event.includes("ASSET") || l.event.includes("FACILITY") || l.event.includes("RESOURCE"));
      }
    }

    // Filter by search query
    if (auditSearchQuery.trim()) {
      const q = auditSearchQuery.toLowerCase().trim();
      logs = logs.filter((l) =>
        (l.event && l.event.toLowerCase().includes(q)) ||
        (l.actor && l.actor.toLowerCase().includes(q)) ||
        (l.details && l.details.toLowerCase().includes(q)) ||
        (l.id && l.id.toLowerCase().includes(q))
      );
    }

    auditTableTbody.innerHTML = "";
    const countPill = document.getElementById("audit-count-pill");
    if (countPill) countPill.textContent = `${logs.length} Events`;

    if (logs.length === 0) {
      auditTableTbody.innerHTML = `<tr><td colspan="4"><div class="table-empty-state"><div class="empty-state-icon-box"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="4 17 10 11 4 5"></polyline><line x1="12" y1="19" x2="20" y2="19"></line></svg></div><div class="empty-state-title">No Audit Logs Match Criteria</div><div class="empty-state-desc">No transaction logs match the selected event type or search keyword. Clear search to view complete ledger.</div></div></td></tr>`;
      return;
    }

    logs.slice(0, 30).forEach((log) => {
      const tr = document.createElement("tr");
      let badgeClass = "audit-badge-default";
      if (log.event.includes("SECURITY") || log.event.includes("VIOLATION")) {
        badgeClass = "audit-badge-violation";
      } else if (log.event.includes("APPROVED")) {
        badgeClass = "audit-badge-approved";
      } else if (log.event.includes("REJECTED") || log.event.includes("CANCELLED")) {
        badgeClass = "audit-badge-rejected";
      } else if (log.event.includes("MAINTENANCE") || log.event.includes("FACILITY")) {
        badgeClass = "audit-badge-maintenance";
      } else if (log.event.includes("USER") || log.event.includes("ASSET")) {
        badgeClass = "audit-badge-crud";
      }

      const actorInitials = ((log.actor || "Sys").replace(/[^a-zA-Z]/g, "").slice(0, 2)).toUpperCase() || "SY";

      tr.innerHTML = `
        <td class="cell-nowrap">
          <span style="font-family:'JetBrains Mono',monospace; font-size:11px; color:#475569; display:inline-flex; align-items:center; gap:5px;">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
            ${new Date(log.timestamp).toLocaleTimeString()}
          </span>
        </td>
        <td class="cell-nowrap">
          <span class="audit-badge ${badgeClass}">${log.event}</span>
        </td>
        <td>
          <div style="display:flex; align-items:center; gap:8px;">
            <div class="user-avatar-circle" style="width:24px; height:24px; font-size:10px;">${actorInitials}</div>
            <strong style="color:#1e293b; font-size:12px;">${log.actor}</strong>
          </div>
        </td>
        <td style="color:#334155; font-size:12px; line-height:1.5;">
          ${escapeHtml(log.details)}
          ${log.hash ? `<br><small style="font-family:'JetBrains Mono',monospace; color:#94a3b8; font-size:10px;">SHA: ${log.hash}</small>` : ""}
        </td>
      `;
      auditTableTbody.appendChild(tr);
    });
  }

  // --------------------------------------------------------------------------
  // Setup Unified Table Search and Filter Event Listeners
  // --------------------------------------------------------------------------
  function setupTableSearchAndFilters() {
    // 1. My Bookings Search & Filter
    const myBookingsSearchInput = document.getElementById("my-bookings-search");
    if (myBookingsSearchInput) {
      myBookingsSearchInput.addEventListener("input", (e) => {
        myBookingsSearchQuery = e.target.value;
        renderMyBookings();
      });
    }

    const myBookingsFilterGroup = document.getElementById("my-bookings-status-filter-group");
    if (myBookingsFilterGroup) {
      myBookingsFilterGroup.querySelectorAll(".btn-filter-pill").forEach((btn) => {
        btn.addEventListener("click", () => {
          myBookingsFilterGroup.querySelectorAll(".btn-filter-pill").forEach((b) => b.classList.remove("active"));
          btn.classList.add("active");
          myBookingsStatusFilter = btn.dataset.status;
          renderMyBookings();
        });
      });
    }

    // 2. Schedule Search & Filter
    const scheduleSearchInput = document.getElementById("schedule-search");
    if (scheduleSearchInput) {
      scheduleSearchInput.addEventListener("input", (e) => {
        scheduleSearchQuery = e.target.value;
        renderDeptSchedule();
      });
    }

    const scheduleTypeGroup = document.getElementById("schedule-type-filter-group");
    if (scheduleTypeGroup) {
      scheduleTypeGroup.querySelectorAll(".btn-filter-pill").forEach((btn) => {
        btn.addEventListener("click", () => {
          scheduleTypeGroup.querySelectorAll(".btn-filter-pill").forEach((b) => b.classList.remove("active"));
          btn.classList.add("active");
          scheduleTypeFilter = btn.dataset.type;
          renderDeptSchedule();
        });
      });
    }

    // 3. Approvals Search & Filter
    const approvalsSearchInput = document.getElementById("approvals-search");
    if (approvalsSearchInput) {
      approvalsSearchInput.addEventListener("input", (e) => {
        approvalsSearchQuery = e.target.value;
        renderApprovals();
      });
    }

    const approvalsFilterGroup = document.getElementById("approvals-filter-group");
    if (approvalsFilterGroup) {
      approvalsFilterGroup.querySelectorAll(".btn-filter-pill").forEach((btn) => {
        btn.addEventListener("click", () => {
          approvalsFilterGroup.querySelectorAll(".btn-filter-pill").forEach((b) => b.classList.remove("active"));
          btn.classList.add("active");
          approvalsFilterMode = btn.dataset.filter;
          renderApprovals();
        });
      });
    }

    // 4. Audit Search & Filter & Export
    const auditSearchInput = document.getElementById("audit-search");
    if (auditSearchInput) {
      auditSearchInput.addEventListener("input", (e) => {
        auditSearchQuery = e.target.value;
        renderAuditLogs();
      });
    }

    const auditFilterGroup = document.getElementById("audit-filter-group");
    if (auditFilterGroup) {
      auditFilterGroup.querySelectorAll(".btn-filter-pill").forEach((btn) => {
        btn.addEventListener("click", () => {
          auditFilterGroup.querySelectorAll(".btn-filter-pill").forEach((b) => b.classList.remove("active"));
          btn.classList.add("active");
          auditEventFilter = btn.dataset.event;
          renderAuditLogs();
        });
      });
    }

    const btnExportAuditJson = document.getElementById("btn-export-audit-json");
    if (btnExportAuditJson) {
      btnExportAuditJson.addEventListener("click", () => {
        try {
          db.downloadTableJSON("audit_logs");
          showToast("Exported audit_logs.json successfully.");
        } catch (e) {
          alert(e.message);
        }
      });
    }

    // 5. Super Admin Subpane Search & Filters
    const sadminJurisdictionSearchInput = document.getElementById("sadmin-jurisdiction-search");
    if (sadminJurisdictionSearchInput) {
      sadminJurisdictionSearchInput.addEventListener("input", (e) => {
        sadminJurisdictionSearch = e.target.value;
        renderSuperAdminPanel();
      });
    }

    const sadminUsersSearchInput = document.getElementById("sadmin-users-search");
    if (sadminUsersSearchInput) {
      sadminUsersSearchInput.addEventListener("input", (e) => {
        sadminUsersSearch = e.target.value;
        renderSuperAdminPanel();
      });
    }

    const sadminUserRoleGroup = document.getElementById("sadmin-user-role-filter-group");
    if (sadminUserRoleGroup) {
      sadminUserRoleGroup.querySelectorAll(".btn-filter-pill").forEach((btn) => {
        btn.addEventListener("click", () => {
          sadminUserRoleGroup.querySelectorAll(".btn-filter-pill").forEach((b) => b.classList.remove("active"));
          btn.classList.add("active");
          sadminUsersRoleFilter = btn.dataset.role;
          renderSuperAdminPanel();
        });
      });
    }

    const sadminFacilitiesSearchInput = document.getElementById("sadmin-facilities-search");
    if (sadminFacilitiesSearchInput) {
      sadminFacilitiesSearchInput.addEventListener("input", (e) => {
        sadminFacilitiesSearch = e.target.value;
        renderSuperAdminPanel();
      });
    }

    const sadminFacilityTypeGroup = document.getElementById("sadmin-facility-type-filter-group");
    if (sadminFacilityTypeGroup) {
      sadminFacilityTypeGroup.querySelectorAll(".btn-filter-pill").forEach((btn) => {
        btn.addEventListener("click", () => {
          sadminFacilityTypeGroup.querySelectorAll(".btn-filter-pill").forEach((b) => b.classList.remove("active"));
          btn.classList.add("active");
          sadminFacilitiesTypeFilter = btn.dataset.type;
          renderSuperAdminPanel();
        });
      });
    }
  }

  // --------------------------------------------------------------------------
  // JSON Relational Database Engine (RFC 8259)
  // --------------------------------------------------------------------------
  function setupDatabaseEngine() {
    btnDownloadTableJson.forEach((btn) => {
      btn.addEventListener("click", () => {
        const table = btn.dataset.table;
        try {
          db.downloadTableJSON(table);
          showToast(`Exported ${table}.json successfully.`);
          recordTelemetry("Singleton", `DatabaseManager exported table '${table}.json'.`, "chip-singleton");
        } catch (err) {
          alert(err.message);
        }
      });
    });

    btnImportTableJson.forEach((btn) => {
      btn.addEventListener("click", () => {
        const table = btn.dataset.table;
        const fileInput = document.createElement("input");
        fileInput.type = "file";
        fileInput.accept = ".json";
        fileInput.style.display = "none";

        fileInput.addEventListener("change", (e) => {
          const file = e.target.files[0];
          if (!file) return;

          if (!confirm(`Overwrite current '${table}' records with JSON file '${file.name}'?`)) {
            return;
          }

          const reader = new FileReader();
          reader.onload = (event) => {
            try {
              const jsonContent = event.target.result;
              const parsed = db.importTableJSON(table, jsonContent);
              showToast(`Imported ${parsed.length} records into '${table}.json' successfully!`);
              recordTelemetry(
                "Singleton",
                `Imported ${parsed.length} records into '${table}' from ${file.name}.`,
                "chip-singleton"
              );
              refreshAllViews();

              if (jsonViewerTitle && jsonViewerOutput) {
                jsonViewerTitle.textContent = `Raw JSON Document Viewer: ${table}.json (Imported)`;
                jsonViewerOutput.textContent = db.exportTableJSON(table);
              }
            } catch (err) {
              alert(`JSON Import Failed: ${err.message}`);
              recordTelemetry("Singleton", `JSON Import Error: ${err.message}`, "chip-singleton");
            }
          };
          reader.readAsText(file);
        });

        document.body.appendChild(fileInput);
        fileInput.click();
        document.body.removeChild(fileInput);
      });
    });

    btnViewTableJson.forEach((btn) => {
      btn.addEventListener("click", () => {
        const table = btn.dataset.table;
        try {
          const jsonText = db.exportTableJSON(table);
          if (jsonViewerTitle) jsonViewerTitle.textContent = `Raw JSON Document Viewer: ${table}.json`;
          if (jsonViewerOutput) jsonViewerOutput.textContent = jsonText;
          recordTelemetry("Singleton", `Inspecting raw JSON data for table '${table}.json'.`, "chip-singleton");
        } catch (err) {
          alert(err.message);
        }
      });
    });

    // Full Database Backup & Restore Handlers
    const btnDownloadJson = document.getElementById("btn-download-json-backup");
    const btnImportJson = document.getElementById("btn-import-json-backup");

    if (btnDownloadJson) {
      btnDownloadJson.addEventListener("click", () => {
        try {
          db.downloadJSON();
          showToast("Complete database snapshot exported as JSON!");
          recordTelemetry("Singleton", "DatabaseManager exported full database snapshot to database.json.", "chip-singleton");
        } catch (err) {
          alert(err.message);
        }
      });
    }

    if (btnImportJson) {
      btnImportJson.addEventListener("click", () => {
        const fileInput = document.createElement("input");
        fileInput.type = "file";
        fileInput.accept = ".json";
        fileInput.style.display = "none";

        fileInput.addEventListener("change", (e) => {
          const file = e.target.files[0];
          if (!file) return;

          if (!confirm(`Overwrite complete database with snapshot '${file.name}'? Current inventory, accounts, and reservations will be updated.`)) {
            return;
          }

          const reader = new FileReader();
          reader.onload = (event) => {
            try {
              const jsonContent = event.target.result;
              db.importFromJSON(jsonContent);
              showToast("Institutional database restored successfully from JSON snapshot!");
              recordTelemetry("Singleton", `DatabaseManager restored full state from ${file.name}.`, "chip-singleton");
              refreshAllViews();

              if (jsonViewerTitle && jsonViewerOutput) {
                jsonViewerTitle.textContent = "Raw JSON Document Viewer: Full Database Snapshot";
                jsonViewerOutput.textContent = db.exportToJSON();
              }
            } catch (err) {
              alert(`JSON Restore Failed: ${err.message}`);
              recordTelemetry("Singleton", `JSON Restore Error: ${err.message}`, "chip-singleton");
            }
          };
          reader.readAsText(file);
        });

        document.body.appendChild(fileInput);
        fileInput.click();
        document.body.removeChild(fileInput);
      });
    }
  }

  function _ignoreOldSetup() {
  }

  function refreshAllViews() {
    renderSuperAdminPanel();
    const all = db.getBookings();
    document.getElementById("stat-total-assets").textContent = db.getAssets().length;
    document.getElementById("stat-active-bookings").textContent = all.filter((b) => b.status === "APPROVED").length;

    renderCatalog();
    renderMyBookings();
    renderDeptSchedule();
    renderApprovals();
    renderAuditLogs();
  }

  // --------------------------------------------------------------------------
  // Telemetry & Toast Utilities
  // --------------------------------------------------------------------------
  function setupTelemetryDrawer() {
    if (btnToggleTelemetry && architectureDrawer) {
      btnToggleTelemetry.addEventListener("click", () => {
        architectureDrawer.classList.toggle("open");
      });
    }

    if (btnCloseDrawer && architectureDrawer) {
      btnCloseDrawer.addEventListener("click", () => {
        architectureDrawer.classList.remove("open");
      });
    }

    if (btnClearTelemetry && telemetryEventList) {
      btnClearTelemetry.addEventListener("click", () => {
        telemetryEventList.innerHTML = "";
      });
    }

    if (btnResetDatabase) {
      btnResetDatabase.addEventListener("click", () => {
        if (confirm("Restore default campus facilities, accounts, and sample bookings?")) {
          db.resetToDefaults();
          currentUser = db.getCurrentUser();
          updateUserProfileDisplay();
          showToast("Database restored to default institutional state.");
          refreshAllViews();
        }
      });
    }
  }

  function recordTelemetry(patternName, message, chipClass) {
    if (!telemetryEventList) return;

    const card = document.createElement("div");
    card.className = "event-log-card";
    card.innerHTML = `
      <div class="event-log-top">
        <span class="p-chip ${chipClass}">${patternName}</span>
        <span class="event-time">${new Date().toLocaleTimeString()}</span>
      </div>
      <div style="color:#e2e8f0; font-size:10.5px;">${message}</div>
    `;

    telemetryEventList.prepend(card);
    if (telemetryEventList.children.length > 50) {
      telemetryEventList.removeChild(telemetryEventList.lastChild);
    }
  }

  function showToast(text) {
    const shelf = document.getElementById("toast-shelf");
    if (!shelf) return;

    const pill = document.createElement("div");
    pill.className = "toast-pill";
    pill.textContent = text;
    shelf.appendChild(pill);

    setTimeout(() => {
      pill.style.opacity = "0";
      setTimeout(() => pill.remove(), 350);
    }, 3200);
  }



  // --------------------------------------------------------------------------
  // Super Administrator Master Console & /sadmin Gateway
  // --------------------------------------------------------------------------
  function checkSadminRoute() {
    // 1-Click Role launcher query parameter support
    const params = new URLSearchParams(window.location.search);
    const requestedRole = params.get("role");
    if (requestedRole) {
      const match = db.getUsers().find(u => u.role.toUpperCase() === requestedRole.toUpperCase());
      if (match) {
        currentUser = match;
        db.setCurrentUser(match);
        updateUserProfileDisplay();
        if (match.role === "FACULTY") switchTab("schedule");
        else if (match.role === "ADMIN") switchTab("approvals");
        else if (match.role === "STUDENT") switchTab("catalog");
        else if (match.role === "SUPER_ADMIN") switchTab("super-admin");
      }
    }

    const hash = window.location.hash.toLowerCase();
    const isSadmin = hash === "#sadmin" || hash === "#/sadmin" || window.location.search.toLowerCase().includes("sadmin");
    if (isSadmin) {
      if (currentUser && currentUser.role === "SUPER_ADMIN") {
        switchTab("super-admin");
      } else {
        if (modalSadminLogin) modalSadminLogin.style.display = "flex";
      }
    }
  }

  function setupSuperAdminConsole() {
    window.addEventListener("hashchange", checkSadminRoute);

    if (navTabSuperAdmin) {
      navTabSuperAdmin.addEventListener("click", () => {
        switchTab("super-admin");
      });
    }

    if (linkSadminPortal) {
      linkSadminPortal.addEventListener("click", (e) => {
        e.preventDefault();
        window.location.hash = "#sadmin";
        if (currentUser && currentUser.role === "SUPER_ADMIN") {
          switchTab("super-admin");
        } else {
          modalSadminLogin.style.display = "flex";
        }
      });
    }

    if (btnCloseSadminModal) {
      btnCloseSadminModal.addEventListener("click", () => {
        modalSadminLogin.style.display = "none";
        if (window.location.hash === "#sadmin" || window.location.hash === "#/sadmin") {
          history.replaceState(null, null, " ");
        }
      });
    }

    // Demo Super Admin Login
    if (btnDemoSadminLogin) {
      btnDemoSadminLogin.addEventListener("click", () => {
        try {
          currentUser = db.authenticateUser("superadmin@northsouth.edu", "sadmin123", true);
          updateUserProfileDisplay();
          modalSadminLogin.style.display = "none";
          recordTelemetry("Proxy", `Super Administrator '${currentUser.name}' authenticated via isolated /sadmin gateway.`, "chip-proxy");
          showToast(`Super Admin session initialized: ${currentUser.name}`);
          refreshAllViews();
          switchTab("super-admin");
        } catch (err) {
          alert(err.message);
        }
      });
    }

    // Form Super Admin Sign In
    if (formSadminSignin) {
      formSadminSignin.addEventListener("submit", (e) => {
        e.preventDefault();
        const email = document.getElementById("sadmin-login-email").value;
        const pass = document.getElementById("sadmin-login-password").value;
        try {
          currentUser = db.authenticateUser(email, pass, true);
          updateUserProfileDisplay();
          modalSadminLogin.style.display = "none";
          formSadminSignin.reset();
          recordTelemetry("Proxy", `Super Administrator '${currentUser.name}' authenticated via isolated /sadmin gateway.`, "chip-proxy");
          showToast(`Super Admin session initialized: ${currentUser.name}`);
          refreshAllViews();
          switchTab("super-admin");
        } catch (err) {
          alert(err.message);
        }
      });
    }

    // Sub-tab toggles
    const tabBtnAssign = document.getElementById("sadmin-tab-btn-assign");
    const tabBtnUsers = document.getElementById("sadmin-tab-btn-users");
    const tabBtnFacilities = document.getElementById("sadmin-tab-btn-facilities");
    const paneAssign = document.getElementById("sadmin-subpane-assign");
    const paneUsers = document.getElementById("sadmin-subpane-users");
    const paneFacilities = document.getElementById("sadmin-subpane-facilities");

    if (tabBtnAssign && tabBtnUsers && tabBtnFacilities) {
      tabBtnAssign.addEventListener("click", () => {
        tabBtnAssign.classList.add("active");
        tabBtnUsers.classList.remove("active");
        tabBtnFacilities.classList.remove("active");
        paneAssign.style.display = "block";
        paneUsers.style.display = "none";
        paneFacilities.style.display = "none";
      });
      tabBtnUsers.addEventListener("click", () => {
        tabBtnUsers.classList.add("active");
        tabBtnAssign.classList.remove("active");
        tabBtnFacilities.classList.remove("active");
        paneUsers.style.display = "block";
        paneAssign.style.display = "none";
        paneFacilities.style.display = "none";
      });
      tabBtnFacilities.addEventListener("click", () => {
        tabBtnFacilities.classList.add("active");
        tabBtnAssign.classList.remove("active");
        tabBtnUsers.classList.remove("active");
        paneFacilities.style.display = "block";
        paneAssign.style.display = "none";
        paneUsers.style.display = "none";
      });
    }

    // User CRUD Modal controls
    const btnOpenUserModal = document.getElementById("btn-sadmin-open-user-modal");
    if (btnOpenUserModal) {
      btnOpenUserModal.addEventListener("click", () => {
        document.getElementById("modal-sadmin-user-title").textContent = "Register Institutional User";
        document.getElementById("form-sadmin-user").reset();
        document.getElementById("sadmin-user-id").value = "";
        modalSadminUser.style.display = "flex";
      });
    }

    if (btnCloseSadminUserModal) {
      btnCloseSadminUserModal.addEventListener("click", () => {
        modalSadminUser.style.display = "none";
      });
    }
    if (btnCancelSadminUser) {
      btnCancelSadminUser.addEventListener("click", () => {
        modalSadminUser.style.display = "none";
      });
    }

    if (formSadminUser) {
      formSadminUser.addEventListener("submit", (e) => {
        e.preventDefault();
        const existingId = document.getElementById("sadmin-user-id").value;
        const name = document.getElementById("sadmin-user-name").value.trim();
        const email = document.getElementById("sadmin-user-email").value.trim();
        const password = document.getElementById("sadmin-user-password").value;
        const role = document.getElementById("sadmin-user-role").value;
        const dept = document.getElementById("sadmin-user-dept").value.trim();
        const nsuId = document.getElementById("sadmin-user-nsuid").value.trim();

        const statusEl = document.getElementById("sadmin-user-status");
        const status = statusEl ? statusEl.value : "ACTIVE";

        try {
          if (existingId) {
            bookingProxy.updateUser({ id: existingId, name, email, password, role, dept, nsuId, status }, currentUser);
            showToast(`User '${name}' updated successfully.`);
            recordTelemetry("Proxy", `Super Admin updated user #${existingId} (${name}).`, "chip-proxy");
          } else {
            const created = bookingProxy.createUser({ name, email, password, role, dept, nsuId, status }, currentUser);
            showToast(`User '${created.name}' created with ID #${created.id}.`);
            recordTelemetry("Proxy", `Super Admin created user #${created.id} (${created.name}).`, "chip-proxy");
          }
          modalSadminUser.style.display = "none";
          refreshAllViews();
        } catch (err) {
          alert(err.message);
        }
      });
    }

    const refreshBtn = document.getElementById("btn-sadmin-refresh");
    if (refreshBtn) {
      refreshBtn.addEventListener("click", () => {
        refreshAllViews();
        showToast("Super Admin state refreshed.");
      });
    }

    const roleFilter = document.getElementById("sadmin-user-role-filter");
    if (roleFilter) {
      roleFilter.addEventListener("change", () => {
        renderSuperAdminPanel();
      });
    }
  }

  function renderSuperAdminPanel() {
    if (!currentUser || ((currentUser.role !== "ADMIN" && currentUser.role !== "SUPER_ADMIN") || (currentUser.id && currentUser.id.startsWith("OFF-")))) return;

    const assets = db.getAssets();
    const users = db.getUsers();
    const assignments = db.getAssignments();

    // Update KPI tiles
    const statAssets = document.getElementById("sadmin-stat-assets");
    const statUsers = document.getElementById("sadmin-stat-users");
    const statAssignments = document.getElementById("sadmin-stat-assignments");
    const statUnassigned = document.getElementById("sadmin-stat-unassigned");
    const statUnassignedStatus = document.getElementById("sadmin-stat-unassigned-status");

    const unassignedCount = Math.max(0, assets.length - assignments.length);

    if (statAssets) statAssets.textContent = assets.length;
    if (statUsers) statUsers.textContent = users.length;
    if (statAssignments) statAssignments.textContent = assignments.length;
    if (statUnassigned) statUnassigned.textContent = unassignedCount;
    if (statUnassignedStatus) {
      if (unassignedCount === 0) {
        statUnassignedStatus.textContent = "100% Assigned";
        statUnassignedStatus.className = "sadmin-metric-status is-assigned";
      } else {
        statUnassignedStatus.textContent = `${unassignedCount} Pending`;
        statUnassignedStatus.className = "sadmin-metric-status is-pending";
      }
    }

    // 1. Render 1-to-1 Assignments Table
    const assignTbody = document.getElementById("sadmin-assignments-tbody");
    if (assignTbody) {
      assignTbody.innerHTML = "";
      const adminUsers = users.filter((u) => u.role === "OFFICER" || (u.role === "ADMIN" && u.id.startsWith("OFF-")));

      // Filter assets by search query
      let filteredAssets = assets;
      if (sadminJurisdictionSearch && sadminJurisdictionSearch.trim()) {
        const q = sadminJurisdictionSearch.toLowerCase().trim();
        filteredAssets = assets.filter((a) => {
          const assign = assignments.find((asg) => asg.assetId === a.id);
          const adm = assign ? users.find((u) => u.id === assign.adminId) : null;
          return (
            (a.name && a.name.toLowerCase().includes(q)) ||
            (a.id && a.id.toLowerCase().includes(q)) ||
            (a.location && a.location.toLowerCase().includes(q)) ||
            (adm && adm.name.toLowerCase().includes(q))
          );
        });
      }

      if (filteredAssets.length === 0) {
        assignTbody.innerHTML = `<tr><td colspan="4"><div class="table-empty-state"><div class="empty-state-title">No Matching Facilities</div><div class="empty-state-desc">No campus facility matches '${sadminJurisdictionSearch}'. Clear search to inspect all facilities.</div></div></td></tr>`;
      } else {
        filteredAssets.forEach((asset) => {
          const currentAssign = assignments.find((a) => a.assetId === asset.id);
          const assignedAdmin = currentAssign ? users.find((u) => u.id === currentAssign.adminId) : null;

          const tr = document.createElement("tr");

          let adminStatusHtml = "";
          let actionHtml = "";

          if (assignedAdmin) {
            const initials = assignedAdmin.name.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase() || "AD";
            adminStatusHtml = `
              <div class="user-identity-cell">
                <div class="user-identity-avatar avatar-admin">${initials}</div>
                <div class="user-identity-details">
                  <span class="user-identity-name">${assignedAdmin.name}</span>
                  <span class="user-identity-email">${assignedAdmin.email} &bull; ${assignedAdmin.dept || "Admin"}</span>
                </div>
              </div>
            `;
            actionHtml = `<button type="button" class="btn-revoke-subtle btn-unassign-asset" data-asset-id="${asset.id}">Revoke Jurisdiction</button>`;
          } else {
            adminStatusHtml = `<span style="display:inline-flex; align-items:center; gap:5px; font-size:11.5px; font-weight:700; color:#b45309; background:#fef3c7; padding:3px 9px; border-radius:4px;"><span class="status-beacon-dot beacon-warning"></span>Unassigned</span>`;

            // Dropdown of administrators with 1-to-1 invariant indication
            const options = adminUsers.map((adm) => {
              const alreadyAssigned = assignments.find((a) => a.adminId === adm.id);
              if (alreadyAssigned) {
                const otherAsset = assets.find((a) => a.id === alreadyAssigned.assetId);
                return `<option value="${adm.id}" disabled style="color:#94a3b8;">${adm.name} (Assigned: ${otherAsset ? otherAsset.name : alreadyAssigned.assetId})</option>`;
              }
              return `<option value="${adm.id}">${adm.name} [Available]</option>`;
            }).join("");

            actionHtml = `
              <div class="sadmin-assign-box">
                <select class="sadmin-select-admin select-assign-admin" data-asset-id="${asset.id}">
                  <option value="">Select Officer...</option>
                  ${options}
                </select>
                <button type="button" class="btn-assign-confirm btn-do-assign" data-asset-id="${asset.id}">Assign</button>
              </div>
            `;
          }

          tr.innerHTML = `
            <td><strong>${asset.name}</strong><br><small style="color:#64748b; font-family:var(--font-mono);">${asset.id}</small></td>
            <td><span class="user-role-badge-pill" style="font-size:10px;">${asset.type}</span><br><small style="color:#64748b;">${asset.location} &bull; Cap: ${asset.capacity}</small></td>
            <td>${adminStatusHtml}</td>
            <td>${actionHtml}</td>
          `;

          // Event listeners
          const btnUnassign = tr.querySelector(".btn-unassign-asset");
          if (btnUnassign) {
            btnUnassign.addEventListener("click", () => {
              if (confirm(`Revoke administrative jurisdiction for facility '${asset.name}'?`)) {
                try {
                  bookingProxy.unassignAsset(asset.id, currentUser);
                  recordTelemetry("Proxy", `Super Admin revoked jurisdiction for '${asset.name}'.`, "chip-proxy");
                  showToast(`Jurisdiction revoked for ${asset.name}.`);
                  refreshAllViews();
                } catch (err) {
                  alert(err.message);
                }
              }
            });
          }

          const btnAssign = tr.querySelector(".btn-do-assign");
          if (btnAssign) {
            btnAssign.addEventListener("click", () => {
              const selectEl = tr.querySelector(`.select-assign-admin[data-asset-id="${asset.id}"]`);
              const chosenAdminId = selectEl.value;
              if (!chosenAdminId) {
                alert("Please select an administrator to assign.");
                return;
              }
              try {
                bookingProxy.assignAssetToAdmin(asset.id, chosenAdminId, currentUser);
                recordTelemetry("Proxy", `Super Admin assigned '${asset.name}' exclusively to admin #${chosenAdminId}.`, "chip-proxy");
                showToast(`Facility '${asset.name}' assigned.`);
                refreshAllViews();
              } catch (err) {
                alert(err.message);
              }
            });
          }

          assignTbody.appendChild(tr);
        });
      }
    }

    // Pending Registrations Banner & Counter
    const pendingUsers = users.filter((u) => u.status === "PENDING_APPROVAL" || u.status === "PENDING");
    const pendingCountPill = document.getElementById("sadmin-pending-count-pill");
    const pendingBadgePill = document.getElementById("sadmin-pending-user-count");
    const pendingCard = document.getElementById("sadmin-pending-approvals-card");
    const pendingListContainer = document.getElementById("sadmin-pending-list-container");

    if (pendingBadgePill) {
      if (pendingUsers.length > 0) {
        pendingBadgePill.textContent = pendingUsers.length;
        pendingBadgePill.style.display = "inline-block";
      } else {
        pendingBadgePill.style.display = "none";
      }
    }

    if (pendingCard) {
      if (pendingUsers.length > 0) {
        pendingCard.style.display = "block";
        if (pendingCountPill) pendingCountPill.textContent = `${pendingUsers.length} Pending Approval`;
        if (pendingListContainer) {
          pendingListContainer.innerHTML = "";
          pendingUsers.forEach((pu) => {
            const item = document.createElement("div");
            item.style.cssText = "display: flex; justify-content: space-between; align-items: center; background: #ffffff; border: 1px solid #fde68a; border-radius: 6px; padding: 10px 14px; gap: 12px; flex-wrap: wrap;";
            item.innerHTML = `
              <div>
                <strong style="color: #0f172a; font-size: 13px;">${pu.name}</strong> 
                <span style="background: #f1f5f9; color: #475569; font-size: 11px; padding: 2px 6px; border-radius: 4px; font-weight: 700; margin-left: 6px;">${pu.role}</span>
                <div style="font-size: 11.5px; color: #64748b; margin-top: 2px;">
                  Email: <strong>${pu.email}</strong> &bull; Dept: ${pu.dept || "ECE"} &bull; ID: <code>${pu.nsuId || pu.id}</code>
                </div>
              </div>
              <div style="display: flex; gap: 8px;">
                <button type="button" class="btn-action btn-primary-action btn-banner-approve" data-id="${pu.id}" style="padding: 5px 12px; font-size: 11.5px; background: #059669; border-color: #059669;">
                  ✓ Approve Account
                </button>
                <button type="button" class="btn-action btn-outline-action btn-banner-reject" data-id="${pu.id}" style="padding: 5px 12px; font-size: 11.5px; color: #dc2626; border-color: #fca5a5;">
                  Reject
                </button>
              </div>
            `;
            item.querySelector(".btn-banner-approve").addEventListener("click", () => {
              bookingProxy.approveUser(pu.id, currentUser);
              showToast(`Account approved for ${pu.name}! They can now log in.`);
              renderSuperAdminPanel();
              refreshAllViews();
            });
            item.querySelector(".btn-banner-reject").addEventListener("click", () => {
              bookingProxy.rejectUser(pu.id, currentUser, "Verification failed");
              showToast(`Registration rejected for ${pu.name}.`);
              renderSuperAdminPanel();
              refreshAllViews();
            });
            pendingListContainer.appendChild(item);
          });
        }
      } else {
        pendingCard.style.display = "none";
      }
    }

    // 2. Render Users Table
    const usersTbody = document.getElementById("sadmin-users-tbody");
    if (usersTbody) {
      usersTbody.innerHTML = "";

      let filteredUsers = users;
      if (sadminUsersRoleFilter && sadminUsersRoleFilter !== "ALL") {
        if (sadminUsersRoleFilter === "PENDING") {
          filteredUsers = filteredUsers.filter((u) => u.status === "PENDING_APPROVAL" || u.status === "PENDING");
        } else {
          filteredUsers = filteredUsers.filter((u) => u.role === sadminUsersRoleFilter);
        }
      }

      if (sadminUsersSearch && sadminUsersSearch.trim()) {
        const q = sadminUsersSearch.toLowerCase().trim();
        filteredUsers = filteredUsers.filter((u) => {
          return (
            (u.name && u.name.toLowerCase().includes(q)) ||
            (u.email && u.email.toLowerCase().includes(q)) ||
            (u.dept && u.dept.toLowerCase().includes(q)) ||
            (u.id && u.id.toLowerCase().includes(q)) ||
            (u.nsuId && String(u.nsuId).toLowerCase().includes(q))
          );
        });
      }

      if (filteredUsers.length === 0) {
        usersTbody.innerHTML = `<tr><td colspan="5"><div class="table-empty-state"><div class="empty-state-title">No Matching Users Found</div><div class="empty-state-desc">No registered user matches your active role filter and search query.</div></div></td></tr>`;
      } else {
        filteredUsers.forEach((user) => {
          const tr = document.createElement("tr");

          let jurisdictionDesc = "&mdash;";
          if (user.role === "ADMIN") {
            const assignedAsset = db.getAssignedAssetForAdmin(user.id);
            jurisdictionDesc = assignedAsset
              ? `<span style="color:#059669; font-weight:700; font-size:12px;">Manages: ${assignedAsset.name}</span>`
              : `<span style="color:#d97706; font-size:12px;">Unassigned Pool</span>`;
          } else if (user.role === "SUPER_ADMIN") {
            jurisdictionDesc = `<span style="color:#4f46e5; font-weight:800; font-size:12px;">Root Global Authority</span>`;
          } else {
            jurisdictionDesc = `<span style="color:#64748b; font-size:12px;">Self-Service Portal</span>`;
          }

          const isPending = user.status === "PENDING_APPROVAL" || user.status === "PENDING";
          let statusPillHtml = "";
          if (isPending) {
            statusPillHtml = `<span style="background:#fef3c7; color:#b45309; border:1px solid #fde68a; border-radius:4px; font-size:10.5px; font-weight:700; padding:2px 7px; display:inline-flex; align-items:center; gap:3px;">⏱ Pending Approval</span>`;
          } else if (user.status === "REJECTED") {
            statusPillHtml = `<span style="background:#fee2e2; color:#dc2626; border:1px solid #fecaca; border-radius:4px; font-size:10.5px; font-weight:700; padding:2px 7px;">✕ Rejected</span>`;
          } else {
            statusPillHtml = `<span style="background:#dcfce7; color:#15803d; border:1px solid #bbf7d0; border-radius:4px; font-size:10.5px; font-weight:700; padding:2px 7px;">✓ Active</span>`;
          }

          const roleBadgeClass =
            user.role === "STUDENT"
              ? "badge-student"
              : user.role === "FACULTY"
              ? "badge-faculty"
              : user.role === "ADMIN"
              ? "badge-admin"
              : "sadmin-badge";

          const avatarClass =
            user.role === "STUDENT"
              ? "avatar-student"
              : user.role === "FACULTY"
              ? "avatar-faculty"
              : user.role === "ADMIN"
              ? "avatar-admin"
              : "avatar-sadmin";

          const initials = user.name.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase() || "US";

          let approveActionsHtml = "";
          if (isPending) {
            approveActionsHtml = `
              <button type="button" class="btn-table-action btn-sadmin-approve-user" data-id="${user.id}" style="background:#059669; color:#fff; border:none; padding:4px 9px; border-radius:4px; font-size:11px; font-weight:700; cursor:pointer;" title="Approve Registration">Approve</button>
              <button type="button" class="btn-table-action btn-sadmin-reject-user" data-id="${user.id}" style="background:#dc2626; color:#fff; border:none; padding:4px 9px; border-radius:4px; font-size:11px; font-weight:700; cursor:pointer;" title="Reject Registration">Reject</button>
            `;
          }

          tr.innerHTML = `
            <td>
              <div class="user-identity-cell">
                <div class="user-identity-avatar ${avatarClass}">${initials}</div>
                <div class="user-identity-details">
                  <span class="user-identity-name">${user.name}</span>
                  <span class="user-identity-email">${user.email}</span>
                </div>
              </div>
            </td>
            <td><span class="user-role-badge-pill ${roleBadgeClass}">${user.role}</span><br><small style="color:#64748b; font-family:var(--font-mono);">${user.nsuId || user.id}</small></td>
            <td><span style="font-size:12.5px; color:#334155;">${user.dept || "Institutional"}</span></td>
            <td><div>${statusPillHtml}${jurisdictionDesc !== "&mdash;" ? `<div style="margin-top:4px;">${jurisdictionDesc}</div>` : ""}</div></td>
            <td>
              <div style="display:flex; gap:6px; align-items:center; flex-wrap:wrap;">
                ${approveActionsHtml}
                <button type="button" class="btn-table-edit btn-sadmin-edit-user" data-id="${user.id}">Edit</button>
                ${user.role !== "SUPER_ADMIN" ? `<button type="button" class="btn-table-delete btn-sadmin-delete-user" data-id="${user.id}">Delete</button>` : ""}
              </div>
            </td>
          `;

          const btnRowApprove = tr.querySelector(".btn-sadmin-approve-user");
          if (btnRowApprove) {
            btnRowApprove.addEventListener("click", () => {
              if (confirm(`Approve registration for "${user.name}" (${user.email}, ${user.role})?\n\nOnce approved, user will be able to log in immediately.`)) {
                try {
                  bookingProxy.approveUser(user.id, currentUser);
                  showToast(`Account approved for ${user.name}! They can now log in.`);
                  renderSuperAdminPanel();
                  refreshAllViews();
                } catch (err) {
                  alert(err.message);
                }
              }
            });
          }

          const btnRowReject = tr.querySelector(".btn-sadmin-reject-user");
          if (btnRowReject) {
            btnRowReject.addEventListener("click", () => {
              const reason = prompt(`Reject registration for "${user.name}"? Enter optional reason:`, "Verification failed with registrar");
              if (reason !== null) {
                try {
                  bookingProxy.rejectUser(user.id, currentUser, reason);
                  showToast(`Registration rejected for ${user.name}.`);
                  renderSuperAdminPanel();
                  refreshAllViews();
                } catch (err) {
                  alert(err.message);
                }
              }
            });
          }

          const btnEdit = tr.querySelector(".btn-sadmin-edit-user");
          if (btnEdit) {
            btnEdit.addEventListener("click", () => {
              document.getElementById("modal-sadmin-user-title").textContent = `Edit User Record (${user.id})`;
              document.getElementById("sadmin-user-id").value = user.id;
              document.getElementById("sadmin-user-name").value = user.name;
              document.getElementById("sadmin-user-email").value = user.email;
              document.getElementById("sadmin-user-password").value = user.password || "password123";
              document.getElementById("sadmin-user-role").value = user.role;
              document.getElementById("sadmin-user-dept").value = user.dept;
              document.getElementById("sadmin-user-nsuid").value = user.nsuId || user.id;
              const statusSelect = document.getElementById("sadmin-user-status");
              if (statusSelect) statusSelect.value = user.status || "ACTIVE";
              modalSadminUser.style.display = "flex";
            });
          }

          const btnDelete = tr.querySelector(".btn-sadmin-delete-user");
          if (btnDelete) {
            btnDelete.addEventListener("click", () => {
              if (confirm(`Are you sure you want to delete user account '${user.name}' (#${user.id})?`)) {
                try {
                  bookingProxy.deleteUser(user.id, currentUser);
                  recordTelemetry("Proxy", `Super Admin deleted user #${user.id} (${user.name}).`, "chip-proxy");
                  showToast(`User account '${user.name}' deleted.`);
                  refreshAllViews();
                } catch (err) {
                  alert(err.message);
                }
              }
            });
          }

          usersTbody.appendChild(tr);
        });
      }
    }

    // 3. Render Facilities Table
    const facilitiesTbody = document.getElementById("sadmin-facilities-tbody");
    if (facilitiesTbody) {
      facilitiesTbody.innerHTML = "";

      let filteredFacilities = assets;
      if (sadminFacilitiesTypeFilter && sadminFacilitiesTypeFilter !== "ALL") {
        filteredFacilities = filteredFacilities.filter((a) => a.type === sadminFacilitiesTypeFilter);
      }

      if (sadminFacilitiesSearch && sadminFacilitiesSearch.trim()) {
        const q = sadminFacilitiesSearch.toLowerCase().trim();
        filteredFacilities = filteredFacilities.filter((a) => {
          return (
            (a.name && a.name.toLowerCase().includes(q)) ||
            (a.id && a.id.toLowerCase().includes(q)) ||
            (a.location && a.location.toLowerCase().includes(q)) ||
            (a.specs && a.specs.toLowerCase().includes(q))
          );
        });
      }

      if (filteredFacilities.length === 0) {
        facilitiesTbody.innerHTML = `<tr><td colspan="5"><div class="table-empty-state"><div class="empty-state-title">No Matching Facilities</div><div class="empty-state-desc">No campus facility matches your active category and search query.</div></div></td></tr>`;
      } else {
        filteredFacilities.forEach((asset) => {
          const tr = document.createElement("tr");

          const specsArray = (asset.specs || "Standard facility").split(",").map(s => s.trim()).filter(Boolean);
          const specsHtml = specsArray.map(s => `<span class="spec-chip">${s}</span>`).join("");

          tr.innerHTML = `
            <td><strong>${asset.name}</strong><br><small style="color:#64748b; font-family:var(--font-mono);">${asset.id}</small></td>
            <td><span class="user-role-badge-pill" style="font-size:10px;">${asset.type}</span><br><small style="color:#64748b;">${asset.location}</small></td>
            <td><span style="font-weight:600; font-size:12.5px;">${asset.capacity} Seats</span><br><small style="color:#64748b; font-family:var(--font-mono);">$${asset.baseRate || 80}/hr</small></td>
            <td><div class="spec-chip-list">${specsHtml}</div></td>
            <td>
              <div style="display:flex; gap:6px;">
                <button type="button" class="btn-table-delete btn-sadmin-decom-asset" data-id="${asset.id}">Decommission</button>
              </div>
            </td>
          `;

          const btnDecom = tr.querySelector(".btn-sadmin-decom-asset");
          if (btnDecom) {
            btnDecom.addEventListener("click", () => {
              if (confirm(`Decommission facility '${asset.name}' (#${asset.id})?`)) {
                try {
                  bookingProxy.deleteAsset(asset.id, currentUser);
                  recordTelemetry("Proxy", `Super Admin decommissioned facility #${asset.id} (${asset.name}).`, "chip-proxy");
                  showToast(`Facility '${asset.name}' decommissioned.`);
                  refreshAllViews();
                } catch (err) {
                  alert(err.message);
                }
              }
            });
          }

          facilitiesTbody.appendChild(tr);
        });
      }
    }
  }


  // --------------------------------------------------------------------------
  // Automated Test Suite & Capabilities Index Modal
  // --------------------------------------------------------------------------
  function setupTestShortcutsModal() {
    const modal = document.getElementById("modal-test-index");
    const btnFloating = document.getElementById("btn-floating-test-index");
    const btnHeader = document.getElementById("btn-header-test-index");
    const btnClose = document.getElementById("btn-close-test-index-modal");

    function openModal() {
      if (modal) modal.style.display = "flex";
    }
    function closeModal() {
      if (modal) modal.style.display = "none";
    }

    if (btnFloating) btnFloating.addEventListener("click", openModal);
    if (btnHeader) btnHeader.addEventListener("click", openModal);
    if (btnClose) btnClose.addEventListener("click", closeModal);
    if (modal) {
      modal.addEventListener("click", (e) => {
        if (e.target === modal) closeModal();
      });
    }

    // 1-Click Role Switchers
    const btnSwitchStudent = document.querySelector(".btn-switch-to-student");
    const btnSwitchFaculty = document.querySelector(".btn-switch-to-faculty");
    const btnSwitchAdmin = document.querySelector(".btn-switch-to-admin");
    const btnSwitchSadmin = document.querySelector(".btn-switch-to-sadmin");

    if (btnSwitchStudent) {
      btnSwitchStudent.addEventListener("click", () => {
        try {
          currentUser = db.authenticateUser("student1@northsouth.edu", "password123");
          updateUserProfileDisplay();
          switchTab("catalog");
          refreshAllViews();
          showToast("Switched to Student: Student 1");
        } catch (e) {
          alert(e.message);
        }
      });
    }

    if (btnSwitchFaculty) {
      btnSwitchFaculty.addEventListener("click", () => {
        try {
          currentUser = db.authenticateUser("faculty1@northsouth.edu", "password123");
          updateUserProfileDisplay();
          switchTab("schedule");
          refreshAllViews();
          showToast("Switched to Faculty: Faculty 1");
        } catch (e) {
          alert(e.message);
        }
      });
    }

    if (btnSwitchAdmin) {
      btnSwitchAdmin.addEventListener("click", () => {
        try {
          currentUser = db.authenticateUser("officer1@northsouth.edu", "password123");
          updateUserProfileDisplay();
          switchTab("approvals");
          refreshAllViews();
          showToast("Switched to Officer: Officer 1 (LAB-101)");
        } catch (e) {
          alert(e.message);
        }
      });
    }

    if (btnSwitchSadmin) {
      btnSwitchSadmin.addEventListener("click", () => {
        try {
          currentUser = db.authenticateUser("admin@northsouth.edu", "admin123");
          updateUserProfileDisplay();
          switchTab("super-admin");
          refreshAllViews();
          showToast("Switched to Admin: Admin 1");
        } catch (e) {
          alert(e.message);
        }
      });
    }

    // Test Runner Wiring
    const terminalOutput = document.getElementById("modal-test-terminal-output");
    const progressFill = document.getElementById("modal-test-progress-fill");
    const counterText = document.getElementById("modal-test-counter");

    function updateProgress(passed, total) {
      if (!progressFill || !counterText) return;
      const pct = Math.round((passed / total) * 100);
      progressFill.style.width = pct + "%";
      counterText.textContent = `${passed} / ${total} Tests Passed (${pct}%)`;
    }

    if (window.CFERSTestEngine) {
      window.CFERSTestEngine.addTestListener((entry) => {
        if (!terminalOutput) return;
        const div = document.createElement("div");
        if (entry.level === "ALL_START" || entry.level === "ALL_COMPLETE") {
          div.className = "log-banner";
          div.textContent = entry.title;
        } else if (entry.level === "SUITE_START" || entry.level === "SUITE_COMPLETE") {
          div.className = "log-info";
          div.textContent = `[${entry.role}] ${entry.title}`;
        } else if (entry.level === "ASSERT") {
          div.className = entry.passed ? "log-pass" : "log-fail";
          div.textContent = `[${entry.passed ? "PASS" : "FAIL"}] [${entry.role}] ${entry.title}: ${entry.details}`;
        }
        terminalOutput.appendChild(div);
        terminalOutput.scrollTop = terminalOutput.scrollHeight;
      });
    }

    const btnRunAll = document.getElementById("btn-modal-run-all");
    const btnRunStudent = document.getElementById("btn-modal-run-student");
    const btnRunFaculty = document.getElementById("btn-modal-run-faculty");
    const btnRunAdmin = document.getElementById("btn-modal-run-admin");
    const btnRunSadmin = document.getElementById("btn-modal-run-sadmin");
    const btnClearConsole = document.getElementById("btn-modal-clear-console");
    const btnCopyConsole = document.getElementById("btn-modal-copy-console");

    if (btnRunAll) {
      btnRunAll.addEventListener("click", async () => {
        if (!window.CFERSTestEngine) return;
        terminalOutput.innerHTML = "";
        const summary = await window.CFERSTestEngine.runAllRoleTests(bookingProxy, scheduler);
        updateProgress(summary.passed, summary.total);
      });
    }

    if (btnRunStudent) {
      btnRunStudent.addEventListener("click", async () => {
        if (!window.CFERSTestEngine) return;
        const res = await window.CFERSTestEngine.runStudentTest(bookingProxy, scheduler);
        updateProgress(res.filter(r => r.passed).length, res.length);
      });
    }

    if (btnRunFaculty) {
      btnRunFaculty.addEventListener("click", async () => {
        if (!window.CFERSTestEngine) return;
        const res = await window.CFERSTestEngine.runFacultyTest(bookingProxy, scheduler);
        updateProgress(res.filter(r => r.passed).length, res.length);
      });
    }

    if (btnRunAdmin) {
      btnRunAdmin.addEventListener("click", async () => {
        if (!window.CFERSTestEngine) return;
        const res = await window.CFERSTestEngine.runAdminTest(bookingProxy, scheduler);
        updateProgress(res.filter(r => r.passed).length, res.length);
      });
    }

    if (btnRunSadmin) {
      btnRunSadmin.addEventListener("click", async () => {
        if (!window.CFERSTestEngine) return;
        const res = await window.CFERSTestEngine.runSuperAdminTest(bookingProxy, scheduler);
        updateProgress(res.filter(r => r.passed).length, res.length);
      });
    }

    if (btnClearConsole) {
      btnClearConsole.addEventListener("click", () => {
        if (terminalOutput) {
          terminalOutput.innerHTML = "<div class='log-info'>[CLEARED] Live test console cleared. Ready.</div>";
        }
        updateProgress(0, 42);
      });
    }

    if (btnCopyConsole) {
      btnCopyConsole.addEventListener("click", () => {
        if (!terminalOutput) return;
        navigator.clipboard.writeText(terminalOutput.innerText).then(() => {
          showToast("Test log copied to clipboard.");
        });
      });
    }
  }

  window.CFERS_GET_ALLOWED_TABS = getAllowedTabsForRole;
  window.recordTelemetry = recordTelemetry;
  window.CFERS = {
    db,
    bookingProxy,
    scheduler,
    switchTab,
    refreshAllViews,
    updateUserProfileDisplay,
    get currentUser() { return currentUser; },
    setCurrentUser: (u) => {
      currentUser = u;
      db.setCurrentUser(u);
      updateUserProfileDisplay();
      refreshAllViews();
    }
  };
});

