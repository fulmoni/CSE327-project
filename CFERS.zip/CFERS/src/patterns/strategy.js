/**
 * CSE327 Software Engineering - Strategy Pattern (Lecture 9)
 * AllocationStrategy: Encapsulates interchangeable slot allocation and priority algorithms.
 * SchedulerContext delegates queue sorting to whichever strategy is active.
 */

class AllocationStrategy {
  constructor(name) {
    if (new.target === AllocationStrategy) {
      throw new TypeError("Cannot instantiate abstract AllocationStrategy directly.");
    }
    this.name = name;
  }

  /**
   * Abstract algorithm method
   * @param {Array} requests List of reservation objects
   * @returns {Array} Sorted/prioritized list
   */
  prioritize(requests) {
    throw new Error("Abstract method 'prioritize()' must be implemented by concrete strategy.");
  }
}

/**
 * Strategy 1: Standard First-Come, First-Served (FCFS)
 */
class FCFSStrategy extends AllocationStrategy {
  constructor() {
    super("First-Come, First-Served (FCFS)");
  }

  prioritize(requests) {
    if (!Array.isArray(requests)) return [];
    // Sort chronologically by submission timestamp
    return [...requests].sort((a, b) => {
      const timeA = new Date(a.submittedAt || 0).getTime();
      const timeB = new Date(b.submittedAt || 0).getTime();
      return timeA - timeB;
    });
  }
}

/**
 * Strategy 2: Faculty Priority Allocation
 * Prioritizes faculty bookings ahead of student bookings
 */
class FacultyPriorityStrategy extends AllocationStrategy {
  constructor() {
    super("Faculty Academic Priority");
  }

  prioritize(requests) {
    if (!Array.isArray(requests)) return [];
    return [...requests].sort((a, b) => {
      const isFacultyA = a.userRole === "FACULTY" ? 1 : 0;
      const isFacultyB = b.userRole === "FACULTY" ? 1 : 0;

      // Higher priority comes first
      if (isFacultyB !== isFacultyA) {
        return isFacultyB - isFacultyA;
      }
      // If both are same role, fallback to submission time
      return new Date(a.submittedAt || 0).getTime() - new Date(b.submittedAt || 0).getTime();
    });
  }
}

/**
 * Strategy 3: Emergency Exam Session Allocation
 * Prioritizes reservations with 'Exam' or 'Emergency' in purpose, then faculty, then FCFS
 */
class EmergencyExamStrategy extends AllocationStrategy {
  constructor() {
    super("Emergency Exam & Lab Session Priority");
  }

  prioritize(requests) {
    if (!Array.isArray(requests)) return [];
    const isUrgent = (item) => {
      const txt = (item.purpose || "").toLowerCase();
      return txt.includes("exam") || txt.includes("urgent") || txt.includes("makeup") ? 1 : 0;
    };

    return [...requests].sort((a, b) => {
      const urgentA = isUrgent(a);
      const urgentB = isUrgent(b);
      if (urgentB !== urgentA) return urgentB - urgentA;

      const facultyA = a.userRole === "FACULTY" ? 1 : 0;
      const facultyB = b.userRole === "FACULTY" ? 1 : 0;
      if (facultyB !== facultyA) return facultyB - facultyA;

      return new Date(a.submittedAt || 0).getTime() - new Date(b.submittedAt || 0).getTime();
    });
  }
}

/**
 * Context class maintaining current strategy reference
 */
class SchedulerContext {
  #strategy = null;

  constructor(defaultStrategy = new FCFSStrategy()) {
    this.setStrategy(defaultStrategy);
  }

  setStrategy(strategy) {
    if (!(strategy instanceof AllocationStrategy)) {
      throw new Error("Invalid strategy: Must be an instance of AllocationStrategy.");
    }
    this.#strategy = strategy;
  }

  getStrategyName() {
    return this.#strategy ? this.#strategy.name : "None";
  }

  execute(requests) {
    if (!this.#strategy) {
      throw new Error("No allocation strategy configured.");
    }
    return this.#strategy.prioritize(requests);
  }
}

window.AllocationStrategy = AllocationStrategy;
window.FCFSStrategy = FCFSStrategy;
window.FacultyPriorityStrategy = FacultyPriorityStrategy;
window.EmergencyExamStrategy = EmergencyExamStrategy;
window.SchedulerContext = SchedulerContext;
