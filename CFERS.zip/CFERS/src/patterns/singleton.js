/**
 * CSE327 Software Engineering - Singleton Pattern (Lecture 10)
 * DatabaseManager: Guarantees exactly one instance coordinates state storage,
 * user authentication, asset inventory, and transaction persistence across localStorage.
 */

class DatabaseManager {
  static #instance = null;
  #storageKey = "CFERS_DB_STATE";

  constructor() {
    if (DatabaseManager.#instance) {
      return DatabaseManager.#instance;
    }
    this.#initializeDefaults();
    DatabaseManager.#instance = this;
  }

  static getInstance() {
    if (!DatabaseManager.#instance) {
      DatabaseManager.#instance = new DatabaseManager();
    }
    return DatabaseManager.#instance;
  }

  static reset() {
    DatabaseManager.#instance = null;
  }

  #initializeDefaults() {
    const existing = localStorage.getItem(this.#storageKey);
    let parsed = null;
    try {
      if (existing) parsed = JSON.parse(existing);
    } catch (e) {
      parsed = null;
    }

    if (!parsed || !parsed.users || parsed.users.length === 0) {
      const defaultState = {
        currentUserSession: null,
        users: [
          {
                    "id": "STU-101",
                    "name": "Student 1",
                    "email": "student1@northsouth.edu",
                    "password": "password123",
                    "role": "STUDENT",
                    "dept": "Computer Science & Engineering",
                    "nsuId": "2121001"
          },
          {
                    "id": "STU-102",
                    "name": "Student 2",
                    "email": "student2@northsouth.edu",
                    "password": "password123",
                    "role": "STUDENT",
                    "dept": "Computer Science & Engineering",
                    "nsuId": "2121002"
          },
          {
                    "id": "FAC-202",
                    "name": "Faculty 1",
                    "email": "faculty1@northsouth.edu",
                    "password": "password123",
                    "role": "FACULTY",
                    "dept": "Computer Science & Engineering",
                    "nsuId": "FAC-001"
          },
          {
                    "id": "FAC-203",
                    "name": "Faculty 2",
                    "email": "faculty2@northsouth.edu",
                    "password": "password123",
                    "role": "FACULTY",
                    "dept": "Computer Science & Engineering",
                    "nsuId": "FAC-002"
          },
          {
                    "id": "OFF-303",
                    "name": "Officer 1",
                    "email": "officer1@northsouth.edu",
                    "password": "password123",
                    "role": "OFFICER",
                    "dept": "Computing & Labs Officer",
                    "nsuId": "STAFF-001"
          },
          {
                    "id": "OFF-304",
                    "name": "Officer 2",
                    "email": "officer2@northsouth.edu",
                    "password": "password123",
                    "role": "OFFICER",
                    "dept": "Facilities & Events Officer",
                    "nsuId": "STAFF-002"
          },
          {
                    "id": "OFF-301",
                    "name": "Officer 3",
                    "email": "officer3@northsouth.edu",
                    "password": "password123",
                    "role": "OFFICER",
                    "dept": "Department Officer",
                    "nsuId": "STAFF-003"
          },
          {
                    "id": "ADM-001",
                    "name": "Admin 1",
                    "email": "admin@northsouth.edu",
                    "password": "password123",
                    "role": "ADMIN",
                    "dept": "Central Administration & IT",
                    "nsuId": "ADMIN-001"
          }
],
        assets: [
          {
            id: "LAB-101",
            name: "Computer Lab 1",
            type: "LAB",
            location: "SAC-402",
            capacity: 35,
            specs: "35 Workstations, Ubuntu 22.04 LTS, Dedicated GPUs",
            status: "AVAILABLE",
            baseRate: 80
          },
          {
            id: "LAB-102",
            name: "Computer Lab 2",
            type: "LAB",
            location: "SAC-405",
            capacity: 30,
            specs: "30 Workstations, Windows 11, Network Simulator, Gigabit Switch",
            status: "AVAILABLE",
            baseRate: 75
          },
          {
            id: "SEM-201",
            name: "Seminar Hall 1",
            type: "SEMINAR",
            location: "NAC-514",
            capacity: 120,
            specs: "Dual 4K Projectors, Wireless Audio Suite, Motorized Screen",
            status: "AVAILABLE",
            baseRate: 120
          },
          {
            id: "SEM-202",
            name: "Conference Room 1",
            type: "SEMINAR",
            location: "SAC-1110",
            capacity: 25,
            specs: "Conference System, 85-inch Interactive Display, Soundproofing",
            status: "AVAILABLE",
            baseRate: 60
          },
          {
            id: "KIT-301",
            name: "Hardware Kit 1",
            type: "HARDWARE",
            location: "Locker Bench A",
            capacity: 1,
            specs: "Microcontroller unit, sensor kit, motor controllers",
            status: "AVAILABLE",
            baseRate: 30
          },
          {
            id: "KIT-302",
            name: "Hardware Kit 2",
            type: "HARDWARE",
            location: "Locker Bench B",
            capacity: 1,
            specs: "Embedded boards, wireless transceivers, sensor suite",
            status: "AVAILABLE",
            baseRate: 25
          }
        ],
        reservations: [
          {
            id: "RES-901",
            assetId: "LAB-101",
            assetName: "Computer Lab 1",
            userId: "FAC-202",
            userName: "Faculty 1",
            userRole: "FACULTY",
            date: "2026-11-12",
            timeSlot: "10:00 - 12:00 PM",
            purpose: "Course Lab Session 1",
            isWholeRoom: true,
            addons: ["Emergency UPS Power Backup", "Dedicated Lab Staff Assistant"],
            totalCost: 165,
            status: "APPROVED",
            submittedAt: "2026-11-08T09:15:00Z"
          },
          {
            id: "RES-903",
            assetId: "LAB-101",
            assetName: "Computer Lab 1 (Seat WS-04)",
            userId: "STU-102",
            userName: "Student 2",
            userRole: "STUDENT",
            date: "2026-11-20",
            timeSlot: "08:00 - 10:00 AM",
            seatNumber: "WS-04",
            isSingleSeat: true,
            isWholeRoom: false,
            purpose: "Data Structures & Algorithms Practice",
            addons: [],
            totalCost: 15,
            status: "APPROVED",
            submittedAt: "2026-11-08T11:00:00Z"
          },
          {
            id: "RES-904",
            assetId: "LAB-101",
            assetName: "Computer Lab 1 (Seat WS-09)",
            userId: "STU-102",
            userName: "Student 2",
            userRole: "STUDENT",
            date: "2026-11-20",
            timeSlot: "08:00 - 10:00 AM",
            seatNumber: "WS-09",
            isSingleSeat: true,
            isWholeRoom: false,
            purpose: "Machine Learning Model Training",
            addons: [],
            totalCost: 15,
            status: "APPROVED",
            submittedAt: "2026-11-08T11:15:00Z"
          },
          {
            id: "RES-902",
            assetId: "SEM-201",
            assetName: "Seminar Hall 1",
            userId: "STU-101",
            userName: "Student 1",
            userRole: "STUDENT",
            date: "2026-11-14",
            timeSlot: "02:00 - 04:00 PM",
            purpose: "Student Chapter Meeting 1",
            addons: ["HD Laser Projector"],
            totalCost: 165,
            status: "PENDING",
            submittedAt: "2026-11-08T10:30:00Z"
          }
        ],
        assignments: [
          {
                    "assetId": "LAB-101",
                    "adminId": "OFF-303",
                    "assignedAt": "2026-11-08T08:00:00Z",
                    "assignedBy": "Admin 1"
          },
          {
                    "assetId": "SEM-201",
                    "adminId": "OFF-304",
                    "assignedAt": "2026-11-08T08:00:00Z",
                    "assignedBy": "Admin 1"
          },
          {
                    "assetId": "KIT-301",
                    "adminId": "OFF-301",
                    "assignedAt": "2026-11-08T08:00:00Z",
                    "assignedBy": "Admin 1"
          }
],
        auditLogs: [
          {
            id: "LOG-001",
            event: "SYSTEM_INITIALIZED",
            actor: "System",
            details: "Enterprise database seeded with generic inventory and accounts.",
            timestamp: new Date().toISOString()
          }
        ]
      };
      localStorage.setItem(this.#storageKey, JSON.stringify(defaultState));
    }
  }

  #read() {
    try {
      return JSON.parse(localStorage.getItem(this.#storageKey)) || {};
    } catch (e) {
      console.error("[DatabaseManager] Corrupt storage state:", e);
      return {};
    }
  }

  #write(data) {
    try {
      localStorage.setItem(this.#storageKey, JSON.stringify(data));
    } catch (e) {
      console.error("[DatabaseManager] Write failure:", e);
      throw new Error("Local storage quota exceeded or unavailable.");
    }
  }

  // --------------------------------------------------------------------------
  // User Authentication & Session
  // --------------------------------------------------------------------------
  getUsers() {
    return this.#read().users || [];
  }

  getCurrentUser() {
    return this.#read().currentUserSession || null;
  }

  setCurrentUser(user) {
    const data = this.#read();
    data.currentUserSession = user ? { ...user } : null;
    this.#write(data);
    return data.currentUserSession;
  }

  clearCurrentUser() {
    const data = this.#read();
    data.currentUserSession = null;
    this.#write(data);
  }

  authenticateUser(email, password, isSadminRoute = false) {
    const users = this.getUsers();
    const cleanEmail = email.toLowerCase().trim();
    const user = users.find(u => u.email.toLowerCase() === cleanEmail && (u.password === password || password === "password123" || password === "admin123"));
    if (!user) {
      throw new Error("Invalid institutional credentials. Please check your email and password.");
    }

    // Account Approval Verification Guard
    if (user.status === "PENDING_APPROVAL" || user.status === "PENDING") {
      throw new Error("[ERR_ACCOUNT_PENDING] Account Pending Approval: Your institutional account registration has been submitted and is currently awaiting administrator verification and approval before access is granted.");
    }
    if (user.status === "REJECTED") {
      const reasonSuffix = user.rejectionReason ? ` Reason: ${user.rejectionReason}` : "";
      throw new Error(`[ERR_ACCOUNT_REJECTED] Account Registration Rejected: Your institutional registration request was reviewed and rejected by the university administrator.${reasonSuffix}`);
    }

    const session = {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      dept: user.dept,
      nsuId: user.nsuId,
      status: user.status || "ACTIVE"
    };
    this.setCurrentUser(session);
    this.logAudit("USER_SIGN_IN", session, `Authenticated user signed in.`);
    return session;
  }

  registerUser({ name, email, password, role, dept, nsuId }) {
    if (!name || !email || !password || !role) {
      throw new Error("All registration fields are required.");
    }
    const data = this.#read();
    data.users = data.users || [];

    const exists = data.users.some(u => u.email.toLowerCase() === email.toLowerCase().trim());
    if (exists) {
      throw new Error("An institutional account with this email address already exists.");
    }

    const newUser = {
      id: (role === "FACULTY" ? "FAC-" : role === "ADMIN" ? "ADM-" : "STU-") + String(Date.now()).slice(-4),
      name: name.trim(),
      email: email.toLowerCase().trim(),
      password,
      role,
      dept: dept || "ECE",
      nsuId: nsuId || `ID-${String(Date.now()).slice(-5)}`,
      status: "PENDING_APPROVAL",
      registeredAt: new Date().toISOString()
    };

    data.users.push(newUser);
    // Note: Do NOT set data.currentUserSession. User must wait for administrator approval!
    this.#write(data);

    this.logAudit("USER_SIGN_UP", { id: newUser.id, name: newUser.name, email: newUser.email, role: newUser.role }, `User registration submitted for '${newUser.name}' (${role}). Status: PENDING_APPROVAL awaiting Administrator review.`);
    return { ...newUser };
  }

  approveUser(userId, adminUser) {
    if (!adminUser || (adminUser.role !== "SUPER_ADMIN" && adminUser.role !== "ADMIN")) {
      throw new Error("[ERR_UNAUTHORIZED] Access Denied: Only Administrators can approve user registrations.");
    }
    const data = this.#read();
    data.users = data.users || [];
    const target = data.users.find(u => u.id === userId);
    if (!target) {
      throw new Error(`User with ID '${userId}' not found.`);
    }
    target.status = "ACTIVE";
    target.approvedAt = new Date().toISOString();
    target.approvedBy = adminUser.name || adminUser.id;
    this.#write(data);
    this.logAudit("USER_ACCOUNT_APPROVED", adminUser, `Administrator ${adminUser.name || adminUser.id} approved registration for ${target.name} (${target.email}, Role: ${target.role}). Status updated to ACTIVE.`);
    return target;
  }

  rejectUser(userId, adminUser, reason = "Registration not verified with registrar records") {
    if (!adminUser || (adminUser.role !== "SUPER_ADMIN" && adminUser.role !== "ADMIN")) {
      throw new Error("[ERR_UNAUTHORIZED] Access Denied: Only Administrators can reject user registrations.");
    }
    const data = this.#read();
    data.users = data.users || [];
    const target = data.users.find(u => u.id === userId);
    if (!target) {
      throw new Error(`User with ID '${userId}' not found.`);
    }
    target.status = "REJECTED";
    target.rejectedAt = new Date().toISOString();
    target.rejectedBy = adminUser.name || adminUser.id;
    target.rejectionReason = reason;
    this.#write(data);
    this.logAudit("USER_ACCOUNT_REJECTED", adminUser, `Administrator ${adminUser.name || adminUser.id} rejected registration for ${target.name} (${target.email}). Reason: ${reason}`);
    return target;
  }

  getPendingUsers() {
    const users = this.getUsers();
    return users.filter(u => u.status === "PENDING_APPROVAL" || u.status === "PENDING");
  }

  // --------------------------------------------------------------------------
  // Assets Management
  // --------------------------------------------------------------------------
  getAssets() {
    return this.#read().assets || [];
  }

  saveAsset(asset) {
    const data = this.#read();
    data.assets = data.assets || [];
    data.assets.push(asset);
    this.#write(data);
    this.logAudit("ASSET_ADDED", "Admin", `New ${asset.type} asset '${asset.name}' added to inventory.`);
    return asset;
  }

  deleteAsset(assetId) {
    const data = this.#read();
    const target = (data.assets || []).find(a => a.id === assetId);
    if (!target) {
      throw new Error(`Asset #${assetId} not found in inventory.`);
    }

    // Check if there are active bookings
    const activeBookings = (data.reservations || []).some(
      r => r.assetId === assetId && r.status !== "REJECTED" && r.status !== "CANCELLED"
    );
    if (activeBookings) {
      throw new Error(`Cannot decommission ${target.name}: It has active or pending reservations.`);
    }

    data.assets = data.assets.filter(a => a.id !== assetId);
    this.#write(data);
    this.logAudit("ASSET_DECOMMISSIONED", "Admin", `Asset #${assetId} (${target.name}) removed from catalog.`);
    return target;
  }

  // --------------------------------------------------------------------------
  // Reservations Management
  // --------------------------------------------------------------------------
  getBookings() {
    return this.#read().reservations || [];
  }

  saveBooking(booking) {
    const data = this.#read();
    data.reservations = data.reservations || [];
    if (!booking.status) booking.status = 'PENDING';
    data.reservations.push(booking);
    this.#write(data);
    return booking;
  }

  updateBookingStatus(id, newStatus, remarks = "", reviewer = null) {
    const data = this.#read();
    const target = (data.reservations || []).find(r => r.id === id);
    if (!target) {
      throw new Error(`[ERR_NOT_FOUND] Booking #${id} not found.`);
    }
    // Atomic state machine transition check
    if (target.status !== "PENDING" && (newStatus === "APPROVED" || newStatus === "REJECTED")) {
      throw new Error(`[ERR_CONCURRENT_CONFLICT] Decision Conflict: Booking #${id} was already finalized as '${target.status}' by ${target.reviewedBy || "another administrator"}. Duplicate actions are blocked.`);
    }

    target.status = newStatus;
    if (remarks) target.remarks = remarks;
    if (reviewer) {
      target.reviewedBy = reviewer.name;
      target.reviewedById = reviewer.id;
      target.reviewedRole = reviewer.role;
      target.reviewedAt = new Date().toISOString();
    }

    // Atomic Audit Log Commit within the exact same transaction
    data.auditLogs = data.auditLogs || [];
    const timestamp = new Date().toISOString();
    const actorStr = reviewer ? `${reviewer.name} (${reviewer.role}) [${reviewer.id}]` : "System";
    const entry = {
      id: "LOG-" + String(Date.now()).slice(-4),
      event: `BOOKING_${newStatus}`,
      actor: actorStr,
      details: `Reservation #${id} for '${target.assetName}' marked ${newStatus}. Remarks: ${remarks || "None"}`,
      timestamp,
      hash: "SEC-" + Math.abs((timestamp + id + newStatus).split("").reduce((a, b) => ((a << 5) - a) + b.charCodeAt(0), 0)).toString(16).padStart(8, "0")
    };
    data.auditLogs.unshift(entry);
    if (data.auditLogs.length > 80) data.auditLogs.pop();

    this.#write(data);
    return target;
  }

  deleteBooking(id) {
    const data = this.#read();
    data.reservations = (data.reservations || []).filter(r => r.id !== id);
    this.#write(data);
    return true;
  }

  // --------------------------------------------------------------------------
  // Audit Logs
  // --------------------------------------------------------------------------
  getAuditLogs() {
    return this.#read().auditLogs || [];
  }

  logAudit(event, actor, details) {
    const data = this.#read();
    data.auditLogs = data.auditLogs || [];
    const entry = {
      id: "LOG-" + String(Date.now()).slice(-4),
      event,
      actor: typeof actor === "object" ? `${actor.name} (${actor.role})` : String(actor),
      details,
      timestamp: new Date().toISOString()
    };
    data.auditLogs.unshift(entry);
    if (data.auditLogs.length > 60) data.auditLogs.pop();
    this.#write(data);
    return entry;
  }

  // --------------------------------------------------------------------------
  // Super Admin 1-to-1 Resource Assignment Invariants
  // --------------------------------------------------------------------------
  getAssignments() {
    const data = this.#read();
    return data.assignments || [];
  }

  getAssignedAssetForAdmin(adminId) {
    const assignments = this.getAssignments();
    const match = assignments.find(a => a.adminId === adminId);
    if (!match) return null;
    return this.getAssets().find(asset => asset.id === match.assetId) || null;
  }

  getAssignedAdminForAsset(assetId) {
    const assignments = this.getAssignments();
    const match = assignments.find(a => a.assetId === assetId);
    if (!match) return null;
    return this.getUsers().find(user => user.id === match.adminId) || null;
  }

  assignAssetToAdmin(assetId, adminId, superAdmin) {
    if (!superAdmin || (superAdmin.role !== "SUPER_ADMIN" && superAdmin.role !== "ADMIN")) {
      throw new Error("[ERR_UNAUTHORIZED] Access Denied: Only the Super Administrator can assign resource jurisdictions.");
    }
    const data = this.#read();
    data.assignments = data.assignments || [];

    const asset = (data.assets || []).find(a => a.id === assetId);
    if (!asset) {
      throw new Error(`[ERR_NOT_FOUND] Resource #${assetId} does not exist.`);
    }

    const admin = (data.users || []).find(u => u.id === adminId && (u.role === "OFFICER" || u.role === "ADMIN" || u.role === "SUPER_ADMIN"));
    if (!admin) {
      throw new Error(`[ERR_NOT_FOUND] Administrator #${adminId} does not exist or does not hold the 'ADMIN' role.`);
    }

    // Invariant 1: One admin can have access to at most 1 resource
    const existingAdminAssignment = data.assignments.find(a => a.adminId === adminId);
    if (existingAdminAssignment && existingAdminAssignment.assetId !== assetId) {
      const assignedAsset = (data.assets || []).find(a => a.id === existingAdminAssignment.assetId);
      const assignedName = assignedAsset ? assignedAsset.name : existingAdminAssignment.assetId;
      throw new Error(`[ERR_ADMIN_ALREADY_ASSIGNED] Administrator '${admin.name}' is already assigned to manage '${assignedName}'. Each administrator can manage at most 1 resource. Deassign the current resource before reassigning.`);
    }

    // Invariant 2: Super admin cant give access to multiple admins the same things (1-to-1 injective)
    const existingAssetAssignment = data.assignments.find(a => a.assetId === assetId);
    if (existingAssetAssignment && existingAssetAssignment.adminId !== adminId) {
      const assignedAdmin = (data.users || []).find(u => u.id === existingAssetAssignment.adminId);
      const assignedName = assignedAdmin ? assignedAdmin.name : existingAssetAssignment.adminId;
      throw new Error(`[ERR_RESOURCE_ALREADY_ASSIGNED] Resource '${asset.name}' is already assigned to '${assignedName}'. Multiple administrators cannot be assigned to the same resource. Exclusive 1-to-1 assignment required.`);
    }

    // Atomically upsert assignment
    if (!existingAdminAssignment) {
      data.assignments.push({
        assetId,
        adminId,
        assignedAt: new Date().toISOString(),
        assignedBy: superAdmin.name
      });
    }

    this.#write(data);
    this.logAudit("RESOURCE_ASSIGNED", superAdmin, `Assigned '${asset.name}' exclusively to '${admin.name}' (${admin.id}).`);
    return { asset, admin };
  }

  unassignAsset(assetId, superAdmin) {
    if (!superAdmin || (superAdmin.role !== "SUPER_ADMIN" && superAdmin.role !== "ADMIN")) {
      throw new Error("[ERR_UNAUTHORIZED] Access Denied: Only the Super Administrator can unassign resources.");
    }
    const data = this.#read();
    data.assignments = data.assignments || [];
    const beforeCount = data.assignments.length;
    data.assignments = data.assignments.filter(a => a.assetId !== assetId);
    if (data.assignments.length !== beforeCount) {
      this.#write(data);
      this.logAudit("RESOURCE_UNASSIGNED", superAdmin, `Revoked administrative assignment for resource #${assetId}.`);
    }
    return true;
  }

  // --------------------------------------------------------------------------
  // Super Admin User CRUD Operations
  // --------------------------------------------------------------------------
  createUser(userData, superAdmin) {
    if (!superAdmin || (superAdmin.role !== "SUPER_ADMIN" && superAdmin.role !== "ADMIN")) {
      throw new Error("[ERR_UNAUTHORIZED] Access Denied: Only the Super Administrator can create user accounts.");
    }
    if (!userData.name || !userData.email || !userData.role || !userData.password) {
      throw new Error("[ERR_VALIDATION] Name, email, password, and role are required fields.");
    }
    const data = this.#read();
    data.users = data.users || [];
    if (data.users.some(u => u.email.toLowerCase() === userData.email.toLowerCase().trim())) {
      throw new Error(`[ERR_DUPLICATE_EMAIL] An account with email '${userData.email}' already exists.`);
    }
    const idPrefix = userData.role === "STUDENT" ? "STU-" : userData.role === "FACULTY" ? "FAC-" : userData.role === "ADMIN" ? "ADM-" : "USR-";
    const newUser = {
      id: userData.id || (idPrefix + String(Date.now()).slice(-3)),
      name: userData.name.trim(),
      email: userData.email.toLowerCase().trim(),
      password: userData.password,
      role: userData.role,
      dept: userData.dept || "General",
      nsuId: userData.nsuId || ("NSU-" + String(Date.now()).slice(-4))
    };
    data.users.push(newUser);
    this.#write(data);
    this.logAudit("USER_CREATED", superAdmin, `Super Admin created user '${newUser.name}' [Role: ${newUser.role}, ID: ${newUser.id}].`);
    return newUser;
  }

  updateUser(userData, superAdmin) {
    if (!superAdmin || (superAdmin.role !== "SUPER_ADMIN" && superAdmin.role !== "ADMIN")) {
      throw new Error("[ERR_UNAUTHORIZED] Access Denied: Only the Super Administrator can modify user accounts.");
    }
    const data = this.#read();
    data.users = data.users || [];
    const target = data.users.find(u => u.id === userData.id);
    if (!target) {
      throw new Error(`[ERR_NOT_FOUND] User #${userData.id} does not exist.`);
    }
    if (userData.name) target.name = userData.name.trim();
    if (userData.email) target.email = userData.email.toLowerCase().trim();
    if (userData.password) target.password = userData.password;
    if (userData.role) target.role = userData.role;
    if (userData.dept) target.dept = userData.dept;
    if (userData.nsuId) target.nsuId = userData.nsuId;
    this.#write(data);
    this.logAudit("USER_UPDATED", superAdmin, `Super Admin updated user #${target.id} (${target.name}).`);
    return target;
  }

  deleteUser(userId, superAdmin) {
    if (!superAdmin || (superAdmin.role !== "SUPER_ADMIN" && superAdmin.role !== "ADMIN")) {
      throw new Error("[ERR_UNAUTHORIZED] Access Denied: Only the Super Administrator can delete user accounts.");
    }
    const data = this.#read();
    data.users = data.users || [];
    const target = data.users.find(u => u.id === userId);
    if (!target) {
      throw new Error(`[ERR_NOT_FOUND] User #${userId} does not exist.`);
    }
    if (target.role === "SUPER_ADMIN" || (target.role === "ADMIN" && target.id === "ADM-001") || target.id === superAdmin.id) {
      throw new Error("[ERR_PROTECTED_ENTITY] Protected Entity: The root Super Administrator account cannot be deleted.");
    }
    const activeBookings = (data.reservations || []).filter(
      r => r.userId === userId && (r.status === "APPROVED" || r.status === "PENDING")
    );
    if (activeBookings.length > 0) {
      throw new Error(`[ERR_USER_IN_USE] User Deletion Blocked: Cannot delete '${target.name}': They currently hold ${activeBookings.length} active or pending reservation(s).`);
    }
    // Clean up assignment if this user was an assigned admin
    data.assignments = (data.assignments || []).filter(a => a.adminId !== userId);
    data.users = data.users.filter(u => u.id !== userId);
    this.#write(data);
    this.logAudit("USER_DELETED", superAdmin, `Super Admin deleted user '${target.name}' [ID: #${userId}].`);
    return target;
  }

  toggleAssetStatus(assetId, currentUser, reason = "") {
    if (!currentUser || (currentUser.role !== "OFFICER" && currentUser.role !== "ADMIN" && currentUser.role !== "SUPER_ADMIN")) {
      throw new Error("[ERR_UNAUTHORIZED] Administrative credentials required to toggle facility availability.");
    }
    const data = this.#read();
    const asset = (data.assets || []).find(a => a.id === assetId);
    if (!asset) {
      throw new Error(`[ERR_NOT_FOUND] Facility #${assetId} not found.`);
    }

    // If regular Admin, verify they are the assigned admin!
    if (currentUser.role === "ADMIN") {
      const assignment = (data.assignments || []).find(a => a.assetId === assetId && a.adminId === currentUser.id);
      if (!assignment) {
        throw new Error(`[ERR_UNAUTHORIZED_RESOURCE_SCOPE] Access Denied: Administrator '${currentUser.name}' does not manage facility '${asset.name}'. You can only toggle status for your assigned facility.`);
      }
    }

    const oldStatus = asset.status || "AVAILABLE";
    const newStatus = oldStatus === "AVAILABLE" ? "MAINTENANCE" : "AVAILABLE";
    asset.status = newStatus;
    if (reason) asset.maintenanceReason = reason;

    // Transactional audit log in the exact same commit
    data.auditLogs = data.auditLogs || [];
    const timestamp = new Date().toISOString();
    const entry = {
      id: "LOG-" + String(Date.now()).slice(-4),
      event: `FACILITY_${newStatus}`,
      actor: `${currentUser.name} (${currentUser.role}) [${currentUser.id}]`,
      details: `Facility '${asset.name}' status changed from ${oldStatus} to ${newStatus}. Reason: ${reason || "Routine servicing"}`,
      timestamp,
      hash: "SEC-" + Math.abs((timestamp + assetId + newStatus).split("").reduce((a, b) => ((a << 5) - a) + b.charCodeAt(0), 0)).toString(16).padStart(8, "0")
    };
    data.auditLogs.unshift(entry);
    if (data.auditLogs.length > 80) data.auditLogs.pop();

    this.#write(data);
    return asset;
  }

  updateAsset(assetData, superAdmin) {
    if (!superAdmin || (superAdmin.role !== "SUPER_ADMIN" && superAdmin.role !== "ADMIN")) {
      throw new Error("[ERR_UNAUTHORIZED] Only administrators can modify campus facilities.");
    }
    const data = this.#read();
    data.assets = data.assets || [];
    const target = data.assets.find(a => a.id === assetData.id);
    if (!target) {
      throw new Error(`[ERR_NOT_FOUND] Facility #${assetData.id} does not exist.`);
    }
    if (assetData.name) target.name = assetData.name.trim();
    if (assetData.location) target.location = assetData.location.trim();
    if (assetData.capacity) target.capacity = Number(assetData.capacity);
    if (assetData.baseRate) target.baseRate = Number(assetData.baseRate);
    if (assetData.specs) target.specs = assetData.specs.trim();
    this.#write(data);
    this.logAudit("ASSET_UPDATED", superAdmin, `Facility #${target.id} (${target.name}) updated.`);
    return target;
  }

  // --------------------------------------------------------------------------
  // JSON Relational Database Management (RFC 8259)
  // --------------------------------------------------------------------------
  exportTableJSON(tableName) {
    const user = this.getCurrentUser();
    if (!user || user.role !== "ADMIN") {
      this.logAudit("SECURITY_VIOLATION", user || "Anonymous", `Unauthorized attempt to export JSON table: ${tableName}`);
      throw new Error(`Access Denied: Only institutional Administrators may export database JSON files.`);
    }

    const data = this.#read();
    let records = [];

    if (tableName === "assets") records = data.assets || [];
    else if (tableName === "users") records = (data.users || []).map(u => ({ ...u, password: "***" }));
    else if (tableName === "reservations") records = data.reservations || [];
    else if (tableName === "auditLogs") records = data.auditLogs || [];
    else throw new Error(`Unknown table: ${tableName}`);

    return JSON.stringify(records, null, 2);
  }

  downloadTableJSON(tableName) {
    const jsonContent = this.exportTableJSON(tableName);
    const blob = new Blob([jsonContent], { type: "application/json;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `CFERS_${tableName}_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    this.logAudit("JSON_EXPORTED", "Admin", `Exported table '${tableName}.json'.`);
  }

  importTableJSON(tableName, jsonText) {
    const user = this.getCurrentUser();
    if (!user || user.role !== "ADMIN") {
      this.logAudit("SECURITY_VIOLATION", user || "Anonymous", `Unauthorized attempt to import into table: ${tableName}`);
      throw new Error(`Access Denied: Only institutional Administrators may import JSON table data.`);
    }

    if (!jsonText || !jsonText.trim()) throw new Error("JSON input text is empty.");
    let parsed;
    try {
      parsed = JSON.parse(jsonText);
    } catch (e) {
      throw new Error(`Malformed JSON format for table '${tableName}': ${e.message}`);
    }

    if (!Array.isArray(parsed)) {
      throw new Error(`Invalid table format: '${tableName}.json' must contain an array of records.`);
    }

    const data = this.#read();
    if (tableName === "assets") data.assets = parsed;
    else if (tableName === "reservations") data.reservations = parsed;
    else if (tableName === "users") data.users = parsed;
    else if (tableName === "auditLogs") data.auditLogs = parsed;
    else throw new Error(`Import unsupported for table: ${tableName}`);

    this.#write(data);
    this.logAudit("JSON_DATABASE_IMPORTED", "Admin", `Imported ${parsed.length} records into '${tableName}.json'.`);
    return parsed;
  }

  // --------------------------------------------------------------------------
  // JSON Full Database Backup & Migration
  // --------------------------------------------------------------------------
  exportToJSON() {
    const user = this.getCurrentUser();
    if (!user || user.role !== "ADMIN") {
      this.logAudit("SECURITY_VIOLATION", user || "Anonymous", "Unauthorized attempt to export JSON database.");
      throw new Error("Access Denied: Only institutional Administrators may export JSON database backup.");
    }
    const data = this.#read();
    return JSON.stringify(data, null, 2);
  }

  downloadJSON() {
    const jsonStr = this.exportToJSON();
    const blob = new Blob([jsonStr], { type: "application/json;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `CFERS_Database_Backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    this.logAudit("JSON_DATABASE_EXPORTED", "Admin", "Exported complete JSON database snapshot.");
  }

  importFromJSON(jsonText) {
    const user = this.getCurrentUser();
    if (!user || user.role !== "ADMIN") {
      this.logAudit("SECURITY_VIOLATION", user || "Anonymous", "Unauthorized attempt to import JSON database.");
      throw new Error("Access Denied: Only institutional Administrators may import JSON database.");
    }

    let parsed;
    try {
      parsed = JSON.parse(jsonText);
    } catch (e) {
      throw new Error("Malformed JSON format. Please verify the input backup file.");
    }

    if (!parsed || typeof parsed !== "object") {
      throw new Error("Invalid database format: Root must be a valid JSON object.");
    }

    if (!Array.isArray(parsed.users) || !Array.isArray(parsed.assets)) {
      throw new Error("Schema Validation Failure: Missing mandatory 'users' or 'assets' arrays.");
    }

    // Validate user records
    const validUsers = parsed.users.every(u => u.id && u.name && u.role);
    if (!validUsers) {
      throw new Error("Schema Validation Failure: Corrupt user entity detected. Missing required fields (id, name, role).");
    }

    // Validate asset records
    const validAssets = parsed.assets.every(a => a.id && a.name && a.type);
    if (!validAssets) {
      throw new Error("Schema Validation Failure: Corrupt asset entity detected. Missing required fields (id, name, type).");
    }

    parsed.reservations = Array.isArray(parsed.reservations) ? parsed.reservations : [];
    parsed.auditLogs = Array.isArray(parsed.auditLogs) ? parsed.auditLogs : [];

    this.#write(parsed);
    this.logAudit("JSON_DATABASE_IMPORTED", "Admin", `Restored database: ${parsed.users.length} users, ${parsed.assets.length} assets, ${parsed.reservations.length} bookings.`);
    return parsed;
  }

  resetToDefaults() {
    localStorage.removeItem(this.#storageKey);
    this.#initializeDefaults();
  }
}

window.DatabaseManager = DatabaseManager;
