/**
 * CSE327 Software Engineering - Proxy Pattern (Lecture 13)
 * SecureBookingProxy: Protection proxy enforcing Role-Based Access Control (RBAC).
 * Guards administrative actions: approval, rejection, adding new assets, and decommissioning assets.
 */

class IBookingService {
  approveBooking(bookingId, currentUser, remarks) {
    throw new Error("Method 'approveBooking()' must be implemented.");
  }

  rejectBooking(bookingId, currentUser, remarks) {
    throw new Error("Method 'rejectBooking()' must be implemented.");
  }

  createBooking(bookingData) {
    throw new Error("Method 'createBooking()' must be implemented.");
  }

  addAsset(assetData, currentUser) {
    throw new Error("Method 'addAsset()' must be implemented.");
  }

  deleteAsset(assetId, currentUser) {
    throw new Error("Method 'deleteAsset()' must be implemented.");
  }

  approveUser(userId, currentUser) {
    throw new Error("Method 'approveUser()' must be implemented.");
  }

  rejectUser(userId, currentUser, reason) {
    throw new Error("Method 'rejectUser()' must be implemented.");
  }
}

/**
 * Real Subject: Interacts directly with database and broadcasts events to observers
 */
class RealBookingService extends IBookingService {
  #db;
  #subject;

  constructor(subject) {
    super();
    this.#db = window.DatabaseManager.getInstance();
    this.#subject = subject;
  }

  createBooking(bookingData) {
    const saved = this.#db.saveBooking(bookingData);
    if (this.#subject) {
      this.#subject.notify("BOOKING_CREATED", saved);
    }
    return saved;
  }

  approveBooking(bookingId, currentUser, remarks = "") {
    const updated = this.#db.updateBookingStatus(bookingId, "APPROVED", remarks, currentUser);
    if (this.#subject) {
      this.#subject.notify("BOOKING_APPROVED", updated);
    }
    return updated;
  }

  rejectBooking(bookingId, currentUser, remarks = "") {
    const updated = this.#db.updateBookingStatus(bookingId, "REJECTED", remarks, currentUser);
    if (this.#subject) {
      this.#subject.notify("BOOKING_REJECTED", updated);
    }
    return updated;
  }

  addAsset(assetData) {
    const saved = this.#db.saveAsset(assetData);
    if (this.#subject) {
      this.#subject.notify("ASSET_ADDED", saved);
    }
    return saved;
  }

  deleteAsset(assetId) {
    const deleted = this.#db.deleteAsset(assetId);
    if (this.#subject) {
      this.#subject.notify("ASSET_DELETED", deleted);
    }
    return deleted;
  }

  approveUser(userId, currentUser) {
    const updated = this.#db.approveUser(userId, currentUser);
    if (this.#subject) {
      this.#subject.notify("USER_APPROVED", updated);
    }
    return updated;
  }

  rejectUser(userId, currentUser, reason) {
    const updated = this.#db.rejectUser(userId, currentUser, reason);
    if (this.#subject) {
      this.#subject.notify("USER_REJECTED", updated);
    }
    return updated;
  }
}

/**
 * Protection Proxy: Intercepts requests, validates user credentials, logs audit trails
 */
class SecureBookingProxy extends IBookingService {
  #realService;
  #db;

  constructor(realService) {
    super();
    if (!realService || !(realService instanceof IBookingService)) {
      throw new Error("SecureBookingProxy requires a valid IBookingService instance.");
    }
    this.#realService = realService;
    this.#db = window.DatabaseManager.getInstance();
  }

  createBooking(bookingData) {
    if (!bookingData || !bookingData.userId || !bookingData.assetId || !bookingData.date || !bookingData.timeSlot) {
      throw new Error("[ERR_INVALID_PAYLOAD] Incomplete booking parameters provided.");
    }

    const existing = this.#db.getBookings();

    // 0a. Unassigned Facility Guard: If resource is not assigned to any admin/officer, reject booking
    const assignments = this.#db.getAssignments();
    const isAssigned = assignments.some((a) => a.assetId === bookingData.assetId);
    if (!isAssigned) {
      throw new Error(`[ERR_FACILITY_UNASSIGNED] Facility Unavailable: '${bookingData.assetName || "This facility"}' is currently unassigned to an administrative officer and cannot accept bookings.`);
    }

    // 0b. Student Booking Scope Guard: Students can only book hardware and single seat of labs
    if (bookingData.userRole === "STUDENT") {
      const targetAsset = this.#db.getAssets().find((a) => a.id === bookingData.assetId);
      if (targetAsset) {
        if (targetAsset.type === "SEMINAR") {
          throw new Error("[ERR_STUDENT_RESTRICTED] Restricted Facility: Students cannot reserve seminar rooms or conference halls. Seminar bookings are restricted to Faculty.");
        }
        if (targetAsset.type === "LAB") {
          if (bookingData.isWholeRoom) {
            throw new Error("[ERR_STUDENT_RESTRICTED] Restricted Facility: Students cannot reserve entire lab rooms. Students can only book individual workstation seats.");
          }
          if (bookingData.seatNumber) {
            const seats = String(bookingData.seatNumber).split(",").map((s) => s.trim()).filter(Boolean);
            if (seats.length > 1) {
              throw new Error("[ERR_STUDENT_RESTRICTED] Restricted Facility: Students are strictly permitted to reserve only 1 individual workstation seat at a time.");
            }
          }
        }
      }
    }

    // 0. Maintenance Pre-Flight Guard
    const asset = this.#db.getAssets().find((a) => a.id === bookingData.assetId);
    if (asset && asset.status === "MAINTENANCE") {
      throw new Error(`[ERR_FACILITY_OFFLINE] Facility Offline: '${asset.name}' is currently offline for maintenance/repairs by its assigned officer. Bookings are temporarily paused.`);
    }

    // 1. Quota Check: Students limited to max 3 active/pending bookings
    if (bookingData.userRole === "STUDENT") {
      const activeCount = existing.filter(
        (b) => b.userId === bookingData.userId && (b.status === "PENDING" || b.status === "APPROVED")
      ).length;
      if (activeCount >= 3) {
        throw new Error("[ERR_QUOTA_EXCEEDED] Fair-Use Quota Limit: Students may hold a maximum of 3 active or pending reservations concurrently to ensure equitable campus access.");
      }
    }

    // 2. Duplicate Pending Check: Prevent spamming multiple pending requests for the same asset
    const hasPending = existing.some(
      (b) => b.userId === bookingData.userId && b.assetId === bookingData.assetId && b.status === "PENDING"
    );
    if (hasPending) {
      throw new Error(`[ERR_DUPLICATE_PENDING] Duplicate Request Blocked: You already have a pending reservation request for '${bookingData.assetName || "this facility"}' awaiting review.`);
    }

    // 3. Same-Day Monopolization Guard: Prevent same user booking the same facility multiple times on the same date
    const hasSameDay = existing.some(
      (b) => b.userId === bookingData.userId && b.assetId === bookingData.assetId && b.date === bookingData.date && (b.status === "PENDING" || b.status === "APPROVED")
    );
    if (hasSameDay) {
      throw new Error(`[ERR_SAME_DAY_MONOPOLIZATION] Repetitive Booking Guard: You already hold a reservation for this facility on ${bookingData.date}. Please select a different date or another facility.`);
    }

    // 4. Atomic Collision Guard (Facility, Date, Slot, and Seat Level)
    const hasCollision = existing.some((b) => {
      if (b.assetId !== bookingData.assetId || b.date !== bookingData.date || b.timeSlot !== bookingData.timeSlot) {
        return false;
      }
      if (b.status === "REJECTED" || b.status === "CANCELLED") {
        return false;
      }

      // If either reservation is for the whole facility, it collides with all requests in that slot
      if (bookingData.isWholeRoom || b.isWholeRoom) {
        return true;
      }

      // If seat-specific workstation bookings in a lab (handles single or multi-seat groups):
      if (bookingData.seatNumber && b.seatNumber) {
        const reqSeats = String(bookingData.seatNumber).split(",").map((s) => s.trim()).filter(Boolean);
        const existingSeats = String(b.seatNumber).split(",").map((s) => s.trim()).filter(Boolean);
        return reqSeats.some((s) => existingSeats.includes(s));
      }

      return true;
    });

    if (hasCollision) {
      if (bookingData.seatNumber) {
        throw new Error(`[ERR_SEAT_OCCUPIED] Workstation Collision: Seat ${bookingData.seatNumber} in ${bookingData.assetName || "this facility"} is already occupied for ${bookingData.timeSlot} on ${bookingData.date}. Please select an available seat from the grid.`);
      }
      throw new Error(`[ERR_SLOT_COLLISION] Slot Unavailable: The selected time slot (${bookingData.timeSlot}) on ${bookingData.date} is already occupied.`);
    }

    return this.#realService.createBooking(bookingData);
  }

  approveBooking(bookingId, currentUser, remarks = "") {
    this.#assertAdminOrSuperAdmin(currentUser, `attempting to approve reservation #${bookingId}`);

    const target = this.#db.getBookings().find((b) => b.id === bookingId);
    if (!target) {
      throw new Error(`[ERR_NOT_FOUND] Reservation #${bookingId} does not exist.`);
    }

    // 1-to-1 Resource Scope Invariant for regular Admins:
    if (currentUser.role === "OFFICER" || (currentUser.role === "ADMIN" && this.#db.getAssignedAssetForAdmin(currentUser.id))) {
      const assignedAsset = this.#db.getAssignedAssetForAdmin(currentUser.id);
      if (!assignedAsset) {
        throw new Error(`[ERR_UNAUTHORIZED_RESOURCE_SCOPE] Access Denied: Administrator '${currentUser.name}' has not been assigned to manage any campus facility. Contact the Super Administrator via the /sadmin portal to receive facility jurisdiction.`);
      }
      if (assignedAsset.id !== target.assetId) {
        throw new Error(`[ERR_UNAUTHORIZED_RESOURCE_SCOPE] Access Denied: Administrator '${currentUser.name}' is assigned exclusively to manage '${assignedAsset.name}' (#${assignedAsset.id}). You do not have jurisdictional authority to approve reservations for '${target.assetName}'.`);
      }
    }

    // Concurrency Lock: Terminal state protection
    if (target.status !== "PENDING") {
      throw new Error(`[ERR_CONCURRENT_CONFLICT] Decision Conflict: Reservation #${bookingId} was already finalized as '${target.status}' by ${target.reviewedBy || "another administrator"}. Duplicate administrative actions are prohibited.`);
    }

    // Segregation of Duties: Prevent self-approval conflict of interest
    if (target.userId === currentUser.id) {
      throw new Error(`[ERR_SELF_APPROVAL_PROHIBITED] Conflict of Interest: Administrator '${currentUser.name}' cannot approve their own personal reservation request. A peer administrator or department chair must review this booking.`);
    }

    return this.#realService.approveBooking(bookingId, currentUser, remarks);
  }

  rejectBooking(bookingId, currentUser, remarks = "") {
    this.#assertAdminOrSuperAdmin(currentUser, `attempting to reject reservation #${bookingId}`);

    const target = this.#db.getBookings().find((b) => b.id === bookingId);
    if (!target) {
      throw new Error(`[ERR_NOT_FOUND] Reservation #${bookingId} does not exist.`);
    }

    // 1-to-1 Resource Scope Invariant for regular Admins:
    if (currentUser.role === "OFFICER" || (currentUser.role === "ADMIN" && this.#db.getAssignedAssetForAdmin(currentUser.id))) {
      const assignedAsset = this.#db.getAssignedAssetForAdmin(currentUser.id);
      if (!assignedAsset) {
        throw new Error(`[ERR_UNAUTHORIZED_RESOURCE_SCOPE] Access Denied: Administrator '${currentUser.name}' has not been assigned to manage any campus facility.`);
      }
      if (assignedAsset.id !== target.assetId) {
        throw new Error(`[ERR_UNAUTHORIZED_RESOURCE_SCOPE] Access Denied: Administrator '${currentUser.name}' is assigned exclusively to manage '${assignedAsset.name}' (#${assignedAsset.id}). You cannot reject reservations for '${target.assetName}'.`);
      }
    }

    if (target.status !== "PENDING") {
      throw new Error(`[ERR_CONCURRENT_CONFLICT] Decision Conflict: Reservation #${bookingId} was already finalized as '${target.status}' by ${target.reviewedBy || "another administrator"}. Duplicate administrative actions are prohibited.`);
    }

    if (target.userId === currentUser.id) {
      throw new Error(`[ERR_SELF_APPROVAL_PROHIBITED] Conflict of Interest: You cannot review your own personal reservation request from the Approval Desk. Please cancel it from 'My Bookings'.`);
    }

    return this.#realService.rejectBooking(bookingId, currentUser, remarks);
  }

  addAsset(assetData, currentUser) {
    this.#assertAdminOrSuperAdmin(currentUser, `attempting to register new asset '${assetData.name}'`);
    return this.#realService.addAsset(assetData);
  }

  deleteAsset(assetId, currentUser) {
    this.#assertAdminOrSuperAdmin(currentUser, `attempting to decommission asset #${assetId}`);

    const asset = this.#db.getAssets().find((a) => a.id === assetId);
    if (!asset) {
      throw new Error(`[ERR_NOT_FOUND] Facility #${assetId} does not exist.`);
    }

    // Active bookings invariant
    const activeBookings = this.#db.getBookings().filter(
      (b) => b.assetId === assetId && (b.status === "APPROVED" || b.status === "PENDING")
    );
    if (activeBookings.length > 0) {
      throw new Error(`[ERR_ASSET_IN_USE] Decommission Blocked: Cannot decommission '${asset.name}' (#${assetId}) because it has ${activeBookings.length} active or pending reservation(s). Cancel or reschedule these bookings first.`);
    }

    return this.#realService.deleteAsset(assetId);
  }

  // Super Admin Specific Proxy Delegations
  assignAssetToOfficer(assetId, officerId, currentUser) {
    return this.assignAssetToAdmin(assetId, officerId, currentUser);
  }

  assignAssetToAdmin(assetId, adminId, currentUser) {
    this.#assertSuperAdmin(currentUser, `attempting to assign facility #${assetId} to admin #${adminId}`);
    return this.#db.assignAssetToAdmin(assetId, adminId, currentUser);
  }

  unassignAsset(assetId, currentUser) {
    this.#assertSuperAdmin(currentUser, `attempting to unassign facility #${assetId}`);
    return this.#db.unassignAsset(assetId, currentUser);
  }

  createUser(userData, currentUser) {
    this.#assertSuperAdmin(currentUser, `attempting to create user '${userData.name}'`);
    return this.#db.createUser(userData, currentUser);
  }

  updateUser(userData, currentUser) {
    this.#assertSuperAdmin(currentUser, `attempting to update user #${userData.id}`);
    return this.#db.updateUser(userData, currentUser);
  }

  deleteUser(userId, currentUser) {
    this.#assertSuperAdmin(currentUser, `attempting to delete user #${userId}`);
    return this.#db.deleteUser(userId, currentUser);
  }

  approveUser(userId, currentUser) {
    this.#assertSuperAdmin(currentUser, `attempting to approve user registration #${userId}`);
    return this.#realService.approveUser(userId, currentUser);
  }

  rejectUser(userId, currentUser, reason) {
    this.#assertSuperAdmin(currentUser, `attempting to reject user registration #${userId}`);
    return this.#realService.rejectUser(userId, currentUser, reason);
  }

  toggleAssetStatus(assetId, currentUser, reason = "") {
    this.#assertAdminOrSuperAdmin(currentUser, `attempting to toggle maintenance for facility #${assetId}`);
    return this.#db.toggleAssetStatus(assetId, currentUser, reason);
  }

  updateAsset(assetData, currentUser) {
    this.#assertAdminOrSuperAdmin(currentUser, `attempting to modify facility #${assetData.id}`);
    return this.#db.updateAsset(assetData, currentUser);
  }

  #assertOfficerOrAdmin(currentUser, actionDescription) {
    if (!currentUser || (currentUser.role !== "OFFICER" && currentUser.role !== "ADMIN" && currentUser.role !== "SUPER_ADMIN")) {
      const actorDesc = currentUser ? `${currentUser.name} (${currentUser.role})` : "Anonymous Visitor";
      const errMsg = `Access Denied: Officer or Administrator authority required. User '${actorDesc}' cannot execute: ${actionDescription}.`;
      this.#db.logAudit("SECURITY_VIOLATION", currentUser || "Unauthorized User", `Blocked attempt: ${actionDescription}`);
      throw new Error(errMsg);
    }
  }

  #assertAdminOrSuperAdmin(currentUser, actionDescription) {
    this.#assertOfficerOrAdmin(currentUser, actionDescription);
  }

  #assertAdmin(currentUser, actionDescription) {
    this.#assertOfficerOrAdmin(currentUser, actionDescription);
  }

  #assertSuperAdmin(currentUser, actionDescription) {
    // Only Root/Central Admin has root authority (role ADMIN or SUPER_ADMIN)
    if (!currentUser || (currentUser.role !== "ADMIN" && currentUser.role !== "SUPER_ADMIN")) {
      const actorDesc = currentUser ? `${currentUser.name} (${currentUser.role})` : "Anonymous Visitor";
      const errMsg = `Access Denied: Administrator privilege required. User '${actorDesc}' cannot execute: ${actionDescription}.`;
      this.#db.logAudit("SECURITY_VIOLATION", currentUser || "Unauthorized User", `Blocked Admin operation: ${actionDescription}`);
      throw new Error(errMsg);
    }
  }
}

window.IBookingService = IBookingService;
window.RealBookingService = RealBookingService;
window.SecureBookingProxy = SecureBookingProxy;
