/**
 * CSE327 Software Engineering - Factory Method Pattern (Lecture 12)
 * AssetFactory: Centralizes creation of polymorphic campus assets (Labs, Rooms, Hardware).
 * Includes a dynamic registry map for frictionless live viva extensions.
 */

class Asset {
  constructor(id, name, location, capacity, specs, baseRate = 80) {
    if (new.target === Asset) {
      throw new TypeError("Cannot instantiate abstract class Asset directly.");
    }
    if (!id || !name || !location) {
      throw new Error("Asset validation failed: id, name, and location are required.");
    }
    this.id = id;
    this.name = name;
    this.location = location;
    this.capacity = Number(capacity) || 1;
    this.specs = specs || "Standard facility specifications.";
    this.status = "AVAILABLE";
    this.baseRate = Number(baseRate) || 80;
  }

  getCategory() {
    throw new Error("Abstract method 'getCategory()' must be implemented by subclass.");
  }

  getDetails() {
    return `[${this.getCategory()}] ${this.name} (${this.location}) - Capacity: ${this.capacity}`;
  }
}

class LabRoom extends Asset {
  constructor(id, name, location, capacity, specs, baseRate = 80) {
    super(id, name, location, capacity, specs, baseRate);
    this.type = "LAB";
  }

  getCategory() {
    return "Computer Laboratory";
  }
}

class SeminarHall extends Asset {
  constructor(id, name, location, capacity, specs, baseRate = 120) {
    super(id, name, location, capacity, specs, baseRate);
    this.type = "SEMINAR";
  }

  getCategory() {
    return "Seminar & Auditorium";
  }
}

class HardwareKit extends Asset {
  constructor(id, name, location, capacity, specs, baseRate = 30) {
    super(id, name, location, capacity || 1, specs, baseRate);
    this.type = "HARDWARE";
  }

  getCategory() {
    return "Portable Hardware Kit";
  }
}

class AssetFactory {
  // Registry map enabling Open-Closed Principle and easy live modification
  static #registry = new Map([
    ["LAB", LabRoom],
    ["SEMINAR", SeminarHall],
    ["HARDWARE", HardwareKit]
  ]);

  /**
   * Register a new concrete asset type at runtime without modifying this class.
   * Perfect for live oral defense tasks (e.g., adding VR_KIT or DRONE_LAB).
   */
  static register(typeKey, assetClass) {
    if (!(assetClass.prototype instanceof Asset)) {
      throw new Error(`Registration failed: ${assetClass.name} must extend Asset.`);
    }
    AssetFactory.#registry.set(typeKey.toUpperCase(), assetClass);
  }

  /**
   * Instantiates an asset based on registered type
   * @param {string} type
   * @param {object} params { id, name, location, capacity, specs, baseRate }
   * @returns {Asset}
   */
  static createAsset(type, { id, name, location, capacity, specs, baseRate }) {
    const key = (type || "").toUpperCase();
    const ConcreteClass = AssetFactory.#registry.get(key);

    if (!ConcreteClass) {
      const registeredKeys = Array.from(AssetFactory.#registry.keys()).join(", ");
      throw new Error(`AssetFactory error: Unknown type '${type}'. Available types: [${registeredKeys}]`);
    }

    const instance = new ConcreteClass(id, name, location, capacity, specs, baseRate);
    return instance;
  }
}

window.Asset = Asset;
window.LabRoom = LabRoom;
window.SeminarHall = SeminarHall;
window.HardwareKit = HardwareKit;
window.AssetFactory = AssetFactory;
