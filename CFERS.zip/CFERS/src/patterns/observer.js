/**
 * CSE327 Software Engineering - Observer Pattern (Lecture 8)
 * BookingSubject: Maintains subscriber list and broadcasts state change events
 * to all registered observers (Toast notification, Email simulator, and Audit logger).
 */

class BookingSubject {
  #observers = [];

  /**
   * Subscribe an observer
   * @param {object} observer Object with an update(event, data) method
   * @returns {function} Unsubscribe token function
   */
  subscribe(observer) {
    if (!observer || typeof observer.update !== "function") {
      throw new Error("Observer must implement an update(event, data) function.");
    }
    if (!this.#observers.includes(observer)) {
      this.#observers.push(observer);
    }
    // Return unsubscribe callback
    return () => this.unsubscribe(observer);
  }

  unsubscribe(observer) {
    this.#observers = this.#observers.filter(obs => obs !== observer);
  }

  /**
   * Broadcast event to all observers safely
   * @param {string} event e.g., 'BOOKING_CREATED', 'BOOKING_APPROVED', 'BOOKING_REJECTED'
   * @param {object} data Context data
   */
  notify(event, data) {
    this.#observers.forEach(observer => {
      try {
        observer.update(event, data);
      } catch (err) {
        console.error("[BookingSubject] Error executing observer update:", err);
      }
    });
  }

  getObserverCount() {
    return this.#observers.length;
  }
}

/**
 * Observer 1: Toast Notification Observer (Renders alert banner on DOM)
 */
class ToastNotificationObserver {
  update(event, data) {
    const container = document.getElementById("toast-container");
    if (!container) return;

    const toast = document.createElement("div");
    toast.className = `toast-banner toast-${event.toLowerCase().replace(/_/g, "-")}`;

    let title = "System Notification";
    let message = "";

    if (event === "BOOKING_CREATED") {
      title = "Reservation Submitted";
      message = `Booking #${data.id} for ${data.assetName} submitted. Status: PENDING`;
    } else if (event === "BOOKING_APPROVED") {
      title = "Reservation Approved";
      message = `Booking #${data.id} has been confirmed by Department Admin.`;
    } else if (event === "BOOKING_REJECTED") {
      title = "Reservation Rejected";
      message = `Booking #${data.id} could not be approved.`;
    } else if (event === "BOOKING_CANCELLED") {
      title = "Reservation Cancelled";
      message = `Booking #${data.id} was cancelled and released.`;
    } else {
      message = `Event: ${event}`;
    }

    toast.innerHTML = `
      <strong>${title}</strong>
      <span>${message}</span>
    `;

    container.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = "0";
      setTimeout(() => toast.remove(), 400);
    }, 4000);
  }
}

/**
 * Observer 2: Email Simulation Observer (Logs simulated emails to UI inspection drawer)
 */
class EmailSimulationObserver {
  #sentEmails = [];

  update(event, data) {
    const subjectLine = `[CFERS Update] ${event.replace(/_/g, " ")}: ${data.assetName || "Facility"}`;
    const emailBody = `Dear ${data.userName || "Campus User"},

Your reservation request #${data.id} for ${data.assetName} on ${data.date} (${data.timeSlot}) has an updated status: ${data.status}.
Add-ons: ${(data.addons && data.addons.length > 0) ? data.addons.join(", ") : "None"}
Total Computed Cost: $${data.totalCost || 0}

Regards,
CFERS Automated Dispatch Service
North South University`;

    const record = {
      id: "EML-" + String(Date.now()).slice(-4),
      to: `${(data.userName || "user").toLowerCase().replace(/\s+/g, ".")}@northsouth.edu`,
      subject: subjectLine,
      body: emailBody,
      timestamp: new Date().toLocaleTimeString()
    };

    this.#sentEmails.unshift(record);

    // Update email drawer count if DOM exists
    const badge = document.getElementById("email-badge");
    if (badge) badge.innerText = String(this.#sentEmails.length);

    // Append to simulated inbox list
    const list = document.getElementById("email-inbox-list");
    if (list) {
      const item = document.createElement("div");
      item.className = "email-item";
      item.innerHTML = `
        <div class="email-header">
          <span class="email-to">To: ${record.to}</span>
          <span class="email-time">${record.timestamp}</span>
        </div>
        <div class="email-subject">${record.subject}</div>
        <pre class="email-body">${record.body}</pre>
      `;
      list.prepend(item);
    }
  }

  getSentEmails() {
    return this.#sentEmails;
  }
}

/**
 * Observer 3: Audit Log Observer (Persists event to DatabaseManager)
 */
class AuditLogObserver {
  update(event, data) {
    const db = window.DatabaseManager.getInstance();
    const actor = data.userRole ? `${data.userName} (${data.userRole})` : "System";
    const details = `Booking #${data.id} [${data.assetName || "Asset"}] transitioned to ${data.status || event}.`;
    db.logAudit(event, actor, details);
  }
}

window.BookingSubject = BookingSubject;
window.ToastNotificationObserver = ToastNotificationObserver;
window.EmailSimulationObserver = EmailSimulationObserver;
window.AuditLogObserver = AuditLogObserver;
