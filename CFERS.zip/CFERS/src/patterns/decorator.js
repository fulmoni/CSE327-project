/**
 * CSE327 Software Engineering - Decorator Pattern (Lecture 11)
 * BookingDecorator: Dynamically attaches peripheral equipment & services to a base facility reservation.
 * Mirrors the SandwichOrder / Window examples in Software Engineering lecture slides.
 */

class ReservationItem {
  getCost() {
    throw new Error("Abstract method 'getCost()' must be implemented.");
  }

  getDescription() {
    throw new Error("Abstract method 'getDescription()' must be implemented.");
  }

  getAddonsList() {
    throw new Error("Abstract method 'getAddonsList()' must be implemented.");
  }
}

/**
 * Concrete Component: Base reservation
 */
class BaseReservation extends ReservationItem {
  #asset;
  #baseHourlyRate;

  constructor(asset, baseHourlyRate = null) {
    super();
    if (!asset) throw new Error("BaseReservation requires an asset instance.");
    this.#asset = asset;
    this.#baseHourlyRate = baseHourlyRate !== null ? Number(baseHourlyRate) : (Number(asset.baseRate) || 80);
  }

  getCost() {
    return this.#baseHourlyRate;
  }

  getDescription() {
    return `Base Facility Booking: ${this.#asset.name} (${this.#asset.location})`;
  }

  getAddonsList() {
    return [];
  }
}

/**
 * Abstract Base Decorator maintaining reference to wrapped component
 */
class ReservationDecorator extends ReservationItem {
  #wrapped;
  static #MAX_DEPTH = 10;

  constructor(wrappedItem, depth = 1) {
    super();
    if (!wrappedItem || !(wrappedItem instanceof ReservationItem)) {
      throw new Error("ReservationDecorator requires an instance of ReservationItem to wrap.");
    }
    if (depth > ReservationDecorator.#MAX_DEPTH) {
      throw new Error("Decorator chain recursion depth exceeded limit.");
    }
    this.#wrapped = wrappedItem;
    this.depth = depth;
  }

  getWrapped() {
    return this.#wrapped;
  }

  getCost() {
    return this.#wrapped.getCost();
  }

  getDescription() {
    return this.#wrapped.getDescription();
  }

  getAddonsList() {
    return this.#wrapped.getAddonsList();
  }
}

/**
 * Concrete Decorator 1: High-Definition Laser Projector
 */
class ProjectorDecorator extends ReservationDecorator {
  constructor(item) {
    super(item, (item.depth || 0) + 1);
  }

  getCost() {
    return super.getCost() + 45;
  }

  getDescription() {
    return `${super.getDescription()} + [HD Laser Projector (+$45)]`;
  }

  getAddonsList() {
    return [...super.getAddonsList(), "HD Laser Projector"];
  }
}

/**
 * Concrete Decorator 2: Emergency UPS Power Backup
 */
class UPSBackupDecorator extends ReservationDecorator {
  constructor(item) {
    super(item, (item.depth || 0) + 1);
  }

  getCost() {
    return super.getCost() + 25;
  }

  getDescription() {
    return `${super.getDescription()} + [Emergency UPS Power Backup (+$25)]`;
  }

  getAddonsList() {
    return [...super.getAddonsList(), "Emergency UPS Power Backup"];
  }
}

/**
 * Concrete Decorator 3: Dedicated Lab Staff Technical Assistant
 */
class LabAssistantDecorator extends ReservationDecorator {
  constructor(item) {
    super(item, (item.depth || 0) + 1);
  }

  getCost() {
    return super.getCost() + 60;
  }

  getDescription() {
    return `${super.getDescription()} + [Dedicated Lab Staff Assistant (+$60)]`;
  }

  getAddonsList() {
    return [...super.getAddonsList(), "Dedicated Lab Staff Assistant"];
  }
}

/**
 * Concrete Decorator 4: Dedicated High-Speed Gigabit Switch
 */
class GigabitNetworkDecorator extends ReservationDecorator {
  constructor(item) {
    super(item, (item.depth || 0) + 1);
  }

  getCost() {
    return super.getCost() + 35;
  }

  getDescription() {
    return `${super.getDescription()} + [Gigabit Network Priority (+$35)]`;
  }

  getAddonsList() {
    return [...super.getAddonsList(), "Gigabit Network Priority"];
  }
}

window.ReservationItem = ReservationItem;
window.BaseReservation = BaseReservation;
window.ReservationDecorator = ReservationDecorator;
window.ProjectorDecorator = ProjectorDecorator;
window.UPSBackupDecorator = UPSBackupDecorator;
window.LabAssistantDecorator = LabAssistantDecorator;
window.GigabitNetworkDecorator = GigabitNetworkDecorator;
